import threading
from datetime import datetime
from pathlib import Path
import socket
import os
from qgis.core import QgsApplication


class CnefeLogger:
    """
    Logger simples, seguro e reutilizável para plugins QGIS (CNEFE).
    Nunca levanta exceção para fora.
    """

    _lock = threading.Lock()

    def __init__(self, app_name="cnefe"):
        self.app_name = app_name

        # caminho FIXO e previsível (perfil do QGIS)
        self.base_dir = Path(QgsApplication.qgisSettingsDirPath()) / "cnefe_logs"

        # cria a pasta IMEDIATAMENTE
        self.base_dir.mkdir(parents=True, exist_ok=True)

    # ---------------------------------------------------------
    # Infra
    # ---------------------------------------------------------

    def _log_file_path(self):
        hostname = socket.gethostname()
        user = os.getlogin()
        date_str = datetime.now().strftime("%Y%m%d")
        
        return self.base_dir / f"{self.app_name}_{hostname}_{user}_{date_str}.log"

    def _write(self, level, message, **context):
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ctx = " | ".join(f"{k}={v}" for k, v in context.items())

            line = f"{timestamp} | {level:<5} | {ctx} | msg={message}\n"

            with self._lock:
                with open(self._log_file_path(), "a", encoding="utf-8") as f:
                    f.write(line)

        except Exception:
            pass  # logger nunca quebra o plugin

    # ---------------------------------------------------------
    # API pública
    # ---------------------------------------------------------

    def info(self, message, **context):
        self._write("INFO", message, **context)

    def warning(self, message, **context):
        self._write("WARN", message, **context)

    def error(self, message, **context):
        self._write("ERROR", message, **context)

    def perf(self, message, **context):
        self._write("PERF", message, **context)
