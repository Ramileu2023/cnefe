<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingTol="1" simplifyLocal="1" symbologyReferenceScale="-1" styleCategories="AllStyleCategories" maxScale="0" readOnly="0" simplifyAlgorithm="0" minScale="100000000" hasScaleBasedVisibilityFlag="0" labelsEnabled="0" version="3.28.9-Firenze" simplifyDrawingHints="0" simplifyMaxScale="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal startExpression="" durationUnit="min" startField="" endField="" limitMode="0" endExpression="" accumulate="0" durationField="" fixedDuration="0" enabled="0" mode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusion="0" symbology="Line" type="IndividualFeatures" clamping="Terrain" showMarkerSymbolInSurfacePlots="0" zscale="1" binding="Centroid" respectLayerSymbol="1" extrusionEnabled="0" zoffset="0">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" type="line" frame_rate="10" name="" is_animated="0" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="243,166,178,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.6" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" type="fill" frame_rate="10" name="" is_animated="0" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="243,166,178,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="174,119,127,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" type="marker" frame_rate="10" name="" is_animated="0" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="square" name="cap_style"/>
            <Option type="QString" value="243,166,178,255" name="color"/>
            <Option type="QString" value="1" name="horizontal_anchor_point"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="diamond" name="name"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="174,119,127,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="diameter" name="scale_method"/>
            <Option type="QString" value="3" name="size"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
            <Option type="QString" value="MM" name="size_unit"/>
            <Option type="QString" value="1" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 type="singleSymbol" forceraster="0" referencescale="-1" enableorderby="0" symbollevels="0">
    <symbols>
      <symbol alpha="1" type="marker" frame_rate="10" name="0" is_animated="0" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="square" name="cap_style"/>
            <Option type="QString" value="219,30,42,255" name="color"/>
            <Option type="QString" value="1" name="horizontal_anchor_point"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="circle" name="name"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="128,17,25,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.4" name="outline_width"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="diameter" name="scale_method"/>
            <Option type="QString" value="4" name="size"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
            <Option type="QString" value="MM" name="size_unit"/>
            <Option type="QString" value="1" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <customproperties>
    <Option type="Map">
      <Option type="int" value="0" name="embeddedWidgets/count"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory barWidth="5" sizeType="MM" sizeScale="3x:0,0,0,0,0,0" labelPlacementMethod="XHeight" width="15" lineSizeType="MM" spacing="5" backgroundColor="#ffffff" scaleDependency="Area" penColor="#000000" penAlpha="255" spacingUnit="MM" penWidth="0" scaleBasedVisibility="0" minScaleDenominator="0" direction="0" lineSizeScale="3x:0,0,0,0,0,0" spacingUnitScale="3x:0,0,0,0,0,0" backgroundAlpha="255" diagramOrientation="Up" showAxis="1" height="15" rotationOffset="270" minimumSize="0" maxScaleDenominator="1e+08" enabled="0" opacity="1">
      <fontProperties style="" italic="0" underline="0" strikethrough="0" bold="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0"/>
      <axisSymbol>
        <symbol alpha="1" type="line" frame_rate="10" name="" is_animated="0" clip_to_extent="1" force_rhr="0">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
          <layer class="SimpleLine" pass="0" locked="0" enabled="1">
            <Option type="Map">
              <Option type="QString" value="0" name="align_dash_pattern"/>
              <Option type="QString" value="square" name="capstyle"/>
              <Option type="QString" value="5;2" name="customdash"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
              <Option type="QString" value="MM" name="customdash_unit"/>
              <Option type="QString" value="0" name="dash_pattern_offset"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
              <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
              <Option type="QString" value="0" name="draw_inside_polygon"/>
              <Option type="QString" value="bevel" name="joinstyle"/>
              <Option type="QString" value="35,35,35,255" name="line_color"/>
              <Option type="QString" value="solid" name="line_style"/>
              <Option type="QString" value="0.26" name="line_width"/>
              <Option type="QString" value="MM" name="line_width_unit"/>
              <Option type="QString" value="0" name="offset"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
              <Option type="QString" value="MM" name="offset_unit"/>
              <Option type="QString" value="0" name="ring_filter"/>
              <Option type="QString" value="0" name="trim_distance_end"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
              <Option type="QString" value="MM" name="trim_distance_end_unit"/>
              <Option type="QString" value="0" name="trim_distance_start"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
              <Option type="QString" value="MM" name="trim_distance_start_unit"/>
              <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
              <Option type="QString" value="0" name="use_custom_dash"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings placement="0" zIndex="0" priority="0" showAll="1" linePlacementFlags="18" obstacle="0" dist="0">
    <properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="UV" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PONTO_DE_REFERENCIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="QUADRA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="FACE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CODIGO_DO_ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CEP" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LOCALIDADE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DATA_DE_CONFIRMACAO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LATITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LONGITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="UV" name="" index="0"/>
    <alias field="ENDERECO" name="" index="1"/>
    <alias field="PONTO_DE_REFERENCIA" name="" index="2"/>
    <alias field="QUADRA" name="" index="3"/>
    <alias field="FACE" name="" index="4"/>
    <alias field="CODIGO_DO_ENDERECO" name="" index="5"/>
    <alias field="CEP" name="" index="6"/>
    <alias field="LOCALIDADE" name="" index="7"/>
    <alias field="STATUS" name="" index="8"/>
    <alias field="DATA_DE_CONFIRMACAO" name="" index="9"/>
    <alias field="LATITUDE" name="" index="10"/>
    <alias field="LONGITUDE" name="" index="11"/>
  </aliases>
  <defaults>
    <default expression="" field="UV" applyOnUpdate="0"/>
    <default expression="" field="ENDERECO" applyOnUpdate="0"/>
    <default expression="" field="PONTO_DE_REFERENCIA" applyOnUpdate="0"/>
    <default expression="" field="QUADRA" applyOnUpdate="0"/>
    <default expression="" field="FACE" applyOnUpdate="0"/>
    <default expression="" field="CODIGO_DO_ENDERECO" applyOnUpdate="0"/>
    <default expression="" field="CEP" applyOnUpdate="0"/>
    <default expression="" field="LOCALIDADE" applyOnUpdate="0"/>
    <default expression="" field="STATUS" applyOnUpdate="0"/>
    <default expression="" field="DATA_DE_CONFIRMACAO" applyOnUpdate="0"/>
    <default expression="" field="LATITUDE" applyOnUpdate="0"/>
    <default expression="" field="LONGITUDE" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="UV" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="ENDERECO" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="PONTO_DE_REFERENCIA" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="QUADRA" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="FACE" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="CODIGO_DO_ENDERECO" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="CEP" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="LOCALIDADE" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="STATUS" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="DATA_DE_CONFIRMACAO" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="LATITUDE" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="LONGITUDE" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="UV" desc=""/>
    <constraint exp="" field="ENDERECO" desc=""/>
    <constraint exp="" field="PONTO_DE_REFERENCIA" desc=""/>
    <constraint exp="" field="QUADRA" desc=""/>
    <constraint exp="" field="FACE" desc=""/>
    <constraint exp="" field="CODIGO_DO_ENDERECO" desc=""/>
    <constraint exp="" field="CEP" desc=""/>
    <constraint exp="" field="LOCALIDADE" desc=""/>
    <constraint exp="" field="STATUS" desc=""/>
    <constraint exp="" field="DATA_DE_CONFIRMACAO" desc=""/>
    <constraint exp="" field="LATITUDE" desc=""/>
    <constraint exp="" field="LONGITUDE" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns>
      <column type="field" width="-1" hidden="0" name="UV"/>
      <column type="field" width="-1" hidden="0" name="ENDERECO"/>
      <column type="field" width="-1" hidden="0" name="PONTO_DE_REFERENCIA"/>
      <column type="field" width="-1" hidden="0" name="QUADRA"/>
      <column type="field" width="-1" hidden="0" name="FACE"/>
      <column type="field" width="-1" hidden="0" name="CODIGO_DO_ENDERECO"/>
      <column type="field" width="-1" hidden="0" name="CEP"/>
      <column type="field" width="-1" hidden="0" name="LOCALIDADE"/>
      <column type="field" width="-1" hidden="0" name="STATUS"/>
      <column type="field" width="-1" hidden="0" name="DATA_DE_CONFIRMACAO"/>
      <column type="field" width="-1" hidden="0" name="LATITUDE"/>
      <column type="field" width="-1" hidden="0" name="LONGITUDE"/>
      <column type="actions" width="-1" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="CEP"/>
    <field editable="1" name="CODIGO_DO_ENDERECO"/>
    <field editable="1" name="DATA_DE_CONFIRMACAO"/>
    <field editable="1" name="ENDERECO"/>
    <field editable="1" name="FACE"/>
    <field editable="1" name="LATITUDE"/>
    <field editable="1" name="LOCALIDADE"/>
    <field editable="1" name="LONGITUDE"/>
    <field editable="1" name="PONTO_DE_REFERENCIA"/>
    <field editable="1" name="QUADRA"/>
    <field editable="1" name="STATUS"/>
    <field editable="1" name="UV"/>
  </editable>
  <labelOnTop>
    <field name="CEP" labelOnTop="0"/>
    <field name="CODIGO_DO_ENDERECO" labelOnTop="0"/>
    <field name="DATA_DE_CONFIRMACAO" labelOnTop="0"/>
    <field name="ENDERECO" labelOnTop="0"/>
    <field name="FACE" labelOnTop="0"/>
    <field name="LATITUDE" labelOnTop="0"/>
    <field name="LOCALIDADE" labelOnTop="0"/>
    <field name="LONGITUDE" labelOnTop="0"/>
    <field name="PONTO_DE_REFERENCIA" labelOnTop="0"/>
    <field name="QUADRA" labelOnTop="0"/>
    <field name="STATUS" labelOnTop="0"/>
    <field name="UV" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="CEP"/>
    <field reuseLastValue="0" name="CODIGO_DO_ENDERECO"/>
    <field reuseLastValue="0" name="DATA_DE_CONFIRMACAO"/>
    <field reuseLastValue="0" name="ENDERECO"/>
    <field reuseLastValue="0" name="FACE"/>
    <field reuseLastValue="0" name="LATITUDE"/>
    <field reuseLastValue="0" name="LOCALIDADE"/>
    <field reuseLastValue="0" name="LONGITUDE"/>
    <field reuseLastValue="0" name="PONTO_DE_REFERENCIA"/>
    <field reuseLastValue="0" name="QUADRA"/>
    <field reuseLastValue="0" name="STATUS"/>
    <field reuseLastValue="0" name="UV"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"UV"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
