<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyMaxScale="1" simplifyDrawingHints="0" hasScaleBasedVisibilityFlag="0" symbologyReferenceScale="-1" labelsEnabled="0" simplifyAlgorithm="0" minScale="100000000" simplifyDrawingTol="1" simplifyLocal="1" styleCategories="AllStyleCategories" readOnly="0" version="3.28.9-Firenze" maxScale="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal startField="" startExpression="" endExpression="" enabled="0" durationField="" fixedDuration="0" limitMode="0" durationUnit="min" endField="" accumulate="0" mode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusionEnabled="0" zoffset="0" extrusion="0" clamping="Terrain" symbology="Line" respectLayerSymbol="1" type="IndividualFeatures" zscale="1" binding="Centroid" showMarkerSymbolInSurfacePlots="0">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" frame_rate="10" type="line" force_rhr="0" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="152,125,183,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" frame_rate="10" type="fill" force_rhr="0" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="152,125,183,255" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="109,89,131,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" frame_rate="10" type="marker" force_rhr="0" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="152,125,183,255" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="diamond" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="109,89,131,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="3" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 symbollevels="0" referencescale="-1" enableorderby="0" forceraster="0" type="singleSymbol">
    <symbols>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" frame_rate="10" type="marker" force_rhr="0" name="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer class="SvgMarker" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="35,35,35,255" type="QString" name="color"/>
            <Option value="0" type="QString" name="fixedAspectRatio"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="C:/Users/eulim/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/cnefe/functions/interface/icons/estabelecimentos_nomes.svg" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255" type="QString" name="outline_color"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option name="parameters"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="10" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <customproperties>
    <Option type="Map">
      <Option value="0" type="int" name="embeddedWidgets/count"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory penAlpha="255" height="15" penColor="#000000" lineSizeType="MM" scaleDependency="Area" minScaleDenominator="0" enabled="0" spacingUnit="MM" maxScaleDenominator="1e+08" backgroundAlpha="255" scaleBasedVisibility="0" diagramOrientation="Up" rotationOffset="270" lineSizeScale="3x:0,0,0,0,0,0" labelPlacementMethod="XHeight" direction="0" spacingUnitScale="3x:0,0,0,0,0,0" penWidth="0" width="15" barWidth="5" spacing="5" opacity="1" sizeType="MM" minimumSize="0" showAxis="1" backgroundColor="#ffffff" sizeScale="3x:0,0,0,0,0,0">
      <fontProperties italic="0" underline="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" strikethrough="0"/>
      <axisSymbol>
        <symbol clip_to_extent="1" alpha="1" is_animated="0" frame_rate="10" type="line" force_rhr="0" name="">
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
          <layer class="SimpleLine" enabled="1" locked="0" pass="0">
            <Option type="Map">
              <Option value="0" type="QString" name="align_dash_pattern"/>
              <Option value="square" type="QString" name="capstyle"/>
              <Option value="5;2" type="QString" name="customdash"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
              <Option value="MM" type="QString" name="customdash_unit"/>
              <Option value="0" type="QString" name="dash_pattern_offset"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
              <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
              <Option value="0" type="QString" name="draw_inside_polygon"/>
              <Option value="bevel" type="QString" name="joinstyle"/>
              <Option value="35,35,35,255" type="QString" name="line_color"/>
              <Option value="solid" type="QString" name="line_style"/>
              <Option value="0.26" type="QString" name="line_width"/>
              <Option value="MM" type="QString" name="line_width_unit"/>
              <Option value="0" type="QString" name="offset"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
              <Option value="MM" type="QString" name="offset_unit"/>
              <Option value="0" type="QString" name="ring_filter"/>
              <Option value="0" type="QString" name="trim_distance_end"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
              <Option value="MM" type="QString" name="trim_distance_end_unit"/>
              <Option value="0" type="QString" name="trim_distance_start"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
              <Option value="MM" type="QString" name="trim_distance_start_unit"/>
              <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
              <Option value="0" type="QString" name="use_custom_dash"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings zIndex="0" obstacle="0" showAll="1" priority="0" dist="0" linePlacementFlags="18" placement="0">
    <properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="None" name="CODIGO UNICO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="QUADRA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="FACE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="UV">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="CODIGO ENDERECO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LOGRADOURO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="NUMERO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LOCALIDADE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="PONTO DE REFERENCIA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="CEP">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LATITUDE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LONGITUDE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ESPECIE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="NOME DO RESPONSAVEL">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="TELEFONE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ESTABELECIMENTO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="STATUS DO ENDERECO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="DATA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="SELECIONADO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LAT_DEC">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LON_DEC">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="FALSO POSITIVO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="CODIGO UNICO" index="0" name=""/>
    <alias field="QUADRA" index="1" name=""/>
    <alias field="FACE" index="2" name=""/>
    <alias field="UV" index="3" name=""/>
    <alias field="CODIGO ENDERECO" index="4" name=""/>
    <alias field="LOGRADOURO" index="5" name=""/>
    <alias field="NUMERO" index="6" name=""/>
    <alias field="LOCALIDADE" index="7" name=""/>
    <alias field="PONTO DE REFERENCIA" index="8" name=""/>
    <alias field="CEP" index="9" name=""/>
    <alias field="LATITUDE" index="10" name=""/>
    <alias field="LONGITUDE" index="11" name=""/>
    <alias field="ESPECIE" index="12" name=""/>
    <alias field="NOME DO RESPONSAVEL" index="13" name=""/>
    <alias field="TELEFONE" index="14" name=""/>
    <alias field="ESTABELECIMENTO" index="15" name=""/>
    <alias field="STATUS DO ENDERECO" index="16" name=""/>
    <alias field="DATA" index="17" name=""/>
    <alias field="SELECIONADO" index="18" name=""/>
    <alias field="LAT_DEC" index="19" name=""/>
    <alias field="LON_DEC" index="20" name=""/>
    <alias field="FALSO POSITIVO" index="21" name=""/>
  </aliases>
  <defaults>
    <default field="CODIGO UNICO" expression="" applyOnUpdate="0"/>
    <default field="QUADRA" expression="" applyOnUpdate="0"/>
    <default field="FACE" expression="" applyOnUpdate="0"/>
    <default field="UV" expression="" applyOnUpdate="0"/>
    <default field="CODIGO ENDERECO" expression="" applyOnUpdate="0"/>
    <default field="LOGRADOURO" expression="" applyOnUpdate="0"/>
    <default field="NUMERO" expression="" applyOnUpdate="0"/>
    <default field="LOCALIDADE" expression="" applyOnUpdate="0"/>
    <default field="PONTO DE REFERENCIA" expression="" applyOnUpdate="0"/>
    <default field="CEP" expression="" applyOnUpdate="0"/>
    <default field="LATITUDE" expression="" applyOnUpdate="0"/>
    <default field="LONGITUDE" expression="" applyOnUpdate="0"/>
    <default field="ESPECIE" expression="" applyOnUpdate="0"/>
    <default field="NOME DO RESPONSAVEL" expression="" applyOnUpdate="0"/>
    <default field="TELEFONE" expression="" applyOnUpdate="0"/>
    <default field="ESTABELECIMENTO" expression="" applyOnUpdate="0"/>
    <default field="STATUS DO ENDERECO" expression="" applyOnUpdate="0"/>
    <default field="DATA" expression="" applyOnUpdate="0"/>
    <default field="SELECIONADO" expression="" applyOnUpdate="0"/>
    <default field="LAT_DEC" expression="" applyOnUpdate="0"/>
    <default field="LON_DEC" expression="" applyOnUpdate="0"/>
    <default field="FALSO POSITIVO" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="CODIGO UNICO" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="QUADRA" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="FACE" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="UV" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="CODIGO ENDERECO" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="LOGRADOURO" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="NUMERO" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="LOCALIDADE" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="PONTO DE REFERENCIA" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="CEP" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="LATITUDE" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="LONGITUDE" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="ESPECIE" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="NOME DO RESPONSAVEL" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="TELEFONE" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="ESTABELECIMENTO" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="STATUS DO ENDERECO" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="DATA" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="SELECIONADO" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="LAT_DEC" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="LON_DEC" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
    <constraint field="FALSO POSITIVO" notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="CODIGO UNICO" desc="" exp=""/>
    <constraint field="QUADRA" desc="" exp=""/>
    <constraint field="FACE" desc="" exp=""/>
    <constraint field="UV" desc="" exp=""/>
    <constraint field="CODIGO ENDERECO" desc="" exp=""/>
    <constraint field="LOGRADOURO" desc="" exp=""/>
    <constraint field="NUMERO" desc="" exp=""/>
    <constraint field="LOCALIDADE" desc="" exp=""/>
    <constraint field="PONTO DE REFERENCIA" desc="" exp=""/>
    <constraint field="CEP" desc="" exp=""/>
    <constraint field="LATITUDE" desc="" exp=""/>
    <constraint field="LONGITUDE" desc="" exp=""/>
    <constraint field="ESPECIE" desc="" exp=""/>
    <constraint field="NOME DO RESPONSAVEL" desc="" exp=""/>
    <constraint field="TELEFONE" desc="" exp=""/>
    <constraint field="ESTABELECIMENTO" desc="" exp=""/>
    <constraint field="STATUS DO ENDERECO" desc="" exp=""/>
    <constraint field="DATA" desc="" exp=""/>
    <constraint field="SELECIONADO" desc="" exp=""/>
    <constraint field="LAT_DEC" desc="" exp=""/>
    <constraint field="LON_DEC" desc="" exp=""/>
    <constraint field="FALSO POSITIVO" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns>
      <column width="-1" type="field" hidden="0" name="CODIGO UNICO"/>
      <column width="-1" type="field" hidden="0" name="QUADRA"/>
      <column width="-1" type="field" hidden="0" name="FACE"/>
      <column width="-1" type="field" hidden="0" name="UV"/>
      <column width="-1" type="field" hidden="0" name="CODIGO ENDERECO"/>
      <column width="-1" type="field" hidden="0" name="LOGRADOURO"/>
      <column width="-1" type="field" hidden="0" name="NUMERO"/>
      <column width="-1" type="field" hidden="0" name="LOCALIDADE"/>
      <column width="-1" type="field" hidden="0" name="PONTO DE REFERENCIA"/>
      <column width="-1" type="field" hidden="0" name="CEP"/>
      <column width="-1" type="field" hidden="0" name="LATITUDE"/>
      <column width="-1" type="field" hidden="0" name="LONGITUDE"/>
      <column width="-1" type="field" hidden="0" name="ESPECIE"/>
      <column width="-1" type="field" hidden="0" name="NOME DO RESPONSAVEL"/>
      <column width="-1" type="field" hidden="0" name="TELEFONE"/>
      <column width="-1" type="field" hidden="0" name="ESTABELECIMENTO"/>
      <column width="-1" type="field" hidden="0" name="STATUS DO ENDERECO"/>
      <column width="-1" type="field" hidden="0" name="DATA"/>
      <column width="-1" type="field" hidden="0" name="SELECIONADO"/>
      <column width="-1" type="field" hidden="0" name="LAT_DEC"/>
      <column width="-1" type="field" hidden="0" name="LON_DEC"/>
      <column width="-1" type="field" hidden="0" name="FALSO POSITIVO"/>
      <column width="-1" type="actions" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="CEP"/>
    <field editable="1" name="CODIGO ENDERECO"/>
    <field editable="1" name="CODIGO UNICO"/>
    <field editable="1" name="DATA"/>
    <field editable="1" name="ESPECIE"/>
    <field editable="1" name="ESTABELECIMENTO"/>
    <field editable="1" name="FACE"/>
    <field editable="1" name="FALSO POSITIVO"/>
    <field editable="1" name="LATITUDE"/>
    <field editable="1" name="LAT_DEC"/>
    <field editable="1" name="LOCALIDADE"/>
    <field editable="1" name="LOGRADOURO"/>
    <field editable="1" name="LONGITUDE"/>
    <field editable="1" name="LON_DEC"/>
    <field editable="1" name="NOME DO RESPONSAVEL"/>
    <field editable="1" name="NUMERO"/>
    <field editable="1" name="PONTO DE REFERENCIA"/>
    <field editable="1" name="QUADRA"/>
    <field editable="1" name="SELECIONADO"/>
    <field editable="1" name="STATUS DO ENDERECO"/>
    <field editable="1" name="TELEFONE"/>
    <field editable="1" name="UV"/>
  </editable>
  <labelOnTop>
    <field name="CEP" labelOnTop="0"/>
    <field name="CODIGO ENDERECO" labelOnTop="0"/>
    <field name="CODIGO UNICO" labelOnTop="0"/>
    <field name="DATA" labelOnTop="0"/>
    <field name="ESPECIE" labelOnTop="0"/>
    <field name="ESTABELECIMENTO" labelOnTop="0"/>
    <field name="FACE" labelOnTop="0"/>
    <field name="FALSO POSITIVO" labelOnTop="0"/>
    <field name="LATITUDE" labelOnTop="0"/>
    <field name="LAT_DEC" labelOnTop="0"/>
    <field name="LOCALIDADE" labelOnTop="0"/>
    <field name="LOGRADOURO" labelOnTop="0"/>
    <field name="LONGITUDE" labelOnTop="0"/>
    <field name="LON_DEC" labelOnTop="0"/>
    <field name="NOME DO RESPONSAVEL" labelOnTop="0"/>
    <field name="NUMERO" labelOnTop="0"/>
    <field name="PONTO DE REFERENCIA" labelOnTop="0"/>
    <field name="QUADRA" labelOnTop="0"/>
    <field name="SELECIONADO" labelOnTop="0"/>
    <field name="STATUS DO ENDERECO" labelOnTop="0"/>
    <field name="TELEFONE" labelOnTop="0"/>
    <field name="UV" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CEP" reuseLastValue="0"/>
    <field name="CODIGO ENDERECO" reuseLastValue="0"/>
    <field name="CODIGO UNICO" reuseLastValue="0"/>
    <field name="DATA" reuseLastValue="0"/>
    <field name="ESPECIE" reuseLastValue="0"/>
    <field name="ESTABELECIMENTO" reuseLastValue="0"/>
    <field name="FACE" reuseLastValue="0"/>
    <field name="FALSO POSITIVO" reuseLastValue="0"/>
    <field name="LATITUDE" reuseLastValue="0"/>
    <field name="LAT_DEC" reuseLastValue="0"/>
    <field name="LOCALIDADE" reuseLastValue="0"/>
    <field name="LOGRADOURO" reuseLastValue="0"/>
    <field name="LONGITUDE" reuseLastValue="0"/>
    <field name="LON_DEC" reuseLastValue="0"/>
    <field name="NOME DO RESPONSAVEL" reuseLastValue="0"/>
    <field name="NUMERO" reuseLastValue="0"/>
    <field name="PONTO DE REFERENCIA" reuseLastValue="0"/>
    <field name="QUADRA" reuseLastValue="0"/>
    <field name="SELECIONADO" reuseLastValue="0"/>
    <field name="STATUS DO ENDERECO" reuseLastValue="0"/>
    <field name="TELEFONE" reuseLastValue="0"/>
    <field name="UV" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"NOME DO RESPONSAVEL"</previewExpression>
  <mapTip>&lt;!DOCTYPE html>&#xd;
	&lt;html>&#xd;
	  &lt;head>&#xd;
		&lt;meta http-equiv="content-type" content="text/html; charset=UTF-8">&#xd;
		&lt;style>&#xd;
			table.grey{&#xd;
				border-style: none;&#xd;
				width: auto;&#xd;
				padding: 15px;&#xd;
				border-collapse: collapse;&#xd;
				border-left: 0;&#xd;
				border-right: 0;&#xd;
				border-radius: 10px;&#xd;
				border-spacing: 0px;&#xd;
				overflow:hidden; /* hide overflowing cells */&#xd;
			}&#xd;
		&lt;/style>					&#xd;
	  &lt;/head>&#xd;
	  &lt;body>&#xd;
		&lt;table  class="grey">&#xd;
			&lt;tbody>&#xd;
				&lt;tr style="height: 18px; width: auto;">&#xd;
					&lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">Atributo&lt;/span>&lt;/td>&#xd;
					&lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">valor&lt;/span>&lt;/td>&#xd;
				&lt;/tr>&#xd;
				&lt;tr style="font-size: 12px; width: auto;">&#xd;
					&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">QUADRA&lt;/span>&lt;/td>&#xd;
					&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%QUADRA%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
				&lt;/tr>									&#xd;
				&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
					&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">FACE&lt;/span>&lt;/td>&#xd;
					&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%FACE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
				&lt;/tr>									&#xd;
				&lt;tr style="font-size: 12px; width: auto;">&#xd;
					&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">LOGRADOURO&lt;/span>&lt;/td>&#xd;
					&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%LOGRADOURO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
				&lt;/tr>																		&#xd;
				&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
					&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">NUMERO&lt;/span>&lt;/td>&#xd;
					&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%NUMERO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
				&lt;/tr>&#xd;
				&lt;tr style="font-size: 12px; width: auto;">&#xd;
					&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">LOCALIDADE&lt;/span>&lt;/td>&#xd;
					&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%LOCALIDADE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
				&lt;/tr>&#xd;
				&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
					&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">PONTO DE REFERÊNCIA&lt;/span>&lt;/td>&#xd;
					&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%PONTO_DE_REFERENCIA%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
				&lt;/tr>&#xd;
				&lt;tr style="font-size: 12px; width: auto;">&#xd;
					&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">STATUS DO ENDEREÇO&lt;/span>&lt;/td>&#xd;
					&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%STATUS_DO_ENDERECO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
				&lt;/tr>&#xd;
				&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
					&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">DATA&lt;/span>&lt;/td>&#xd;
					&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%DATA%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
				&lt;/tr>									&#xd;
				&lt;tr style="font-size: 12px; width: auto;">&#xd;
					&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">ESPECIE&lt;/span>&lt;/td>&#xd;
					&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%ESPECIE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
				&lt;/tr>									&#xd;
				&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
					&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">ESTABELECIMENTO&lt;/span>&lt;/td>&#xd;
					&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%ESTABELECIMENTO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
				&lt;/tr>										&#xd;
			&lt;/tbody>&#xd;
		&lt;/table>	&#xd;
	  &lt;/body>&#xd;
	&lt;/html></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
