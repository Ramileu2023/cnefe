<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis hasScaleBasedVisibilityFlag="0" simplifyDrawingTol="1" labelsEnabled="0" styleCategories="AllStyleCategories" simplifyMaxScale="1" version="3.28.9-Firenze" maxScale="0" simplifyDrawingHints="0" readOnly="0" symbologyReferenceScale="-1" minScale="100000000" simplifyAlgorithm="0" simplifyLocal="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal limitMode="0" durationField="" enabled="0" accumulate="0" durationUnit="min" startExpression="" fixedDuration="0" endField="" mode="0" startField="" endExpression="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation clamping="Terrain" binding="Centroid" showMarkerSymbolInSurfacePlots="0" zoffset="0" respectLayerSymbol="1" type="IndividualFeatures" zscale="1" extrusionEnabled="0" symbology="Line" extrusion="0">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol clip_to_extent="1" is_animated="0" name="" force_rhr="0" type="line" frame_rate="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleLine" enabled="1" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="243,166,178,255"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol clip_to_extent="1" is_animated="0" name="" force_rhr="0" type="fill" frame_rate="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleFill" enabled="1" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="243,166,178,255"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="174,119,127,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol clip_to_extent="1" is_animated="0" name="" force_rhr="0" type="marker" frame_rate="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleMarker" enabled="1" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="243,166,178,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="174,119,127,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 type="categorizedSymbol" forceraster="0" enableorderby="0" symbollevels="0" referencescale="-1" attr="LOCALIDADE">
    <categories>
      <category label="PEBA" type="string" render="true" symbol="0" value="PEBA"/>
      <category label="SITIO ALEGRE" type="string" render="true" symbol="1" value="SITIO ALEGRE"/>
      <category label="MENDES" type="string" render="true" symbol="2" value="MENDES"/>
      <category label="JATOBA" type="string" render="true" symbol="3" value="JATOBA"/>
    </categories>
    <symbols>
      <symbol clip_to_extent="1" is_animated="0" name="0" force_rhr="0" type="marker" frame_rate="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleMarker" enabled="1" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="255,0,0,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" is_animated="0" name="1" force_rhr="0" type="marker" frame_rate="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleMarker" enabled="1" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="0,255,0,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" is_animated="0" name="2" force_rhr="0" type="marker" frame_rate="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleMarker" enabled="1" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="0,0,255,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" is_animated="0" name="3" force_rhr="0" type="marker" frame_rate="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleMarker" enabled="1" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="255,255,0,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <customproperties>
    <Option type="Map">
      <Option name="OnConvertFormatRegeneratePrimaryKey" type="bool" value="true"/>
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory spacingUnitScale="3x:0,0,0,0,0,0" rotationOffset="270" sizeType="MM" scaleBasedVisibility="0" width="15" penColor="#000000" lineSizeType="MM" sizeScale="3x:0,0,0,0,0,0" minimumSize="0" lineSizeScale="3x:0,0,0,0,0,0" diagramOrientation="Up" spacingUnit="MM" backgroundAlpha="255" scaleDependency="Area" height="15" maxScaleDenominator="1e+08" direction="0" labelPlacementMethod="XHeight" penWidth="0" backgroundColor="#ffffff" penAlpha="255" barWidth="5" showAxis="1" enabled="0" minScaleDenominator="0" opacity="1" spacing="5">
      <fontProperties italic="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" strikethrough="0" style="" underline="0" bold="0"/>
      <axisSymbol>
        <symbol clip_to_extent="1" is_animated="0" name="" force_rhr="0" type="line" frame_rate="10" alpha="1">
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer locked="0" class="SimpleLine" enabled="1" pass="0">
            <Option type="Map">
              <Option name="align_dash_pattern" type="QString" value="0"/>
              <Option name="capstyle" type="QString" value="square"/>
              <Option name="customdash" type="QString" value="5;2"/>
              <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="customdash_unit" type="QString" value="MM"/>
              <Option name="dash_pattern_offset" type="QString" value="0"/>
              <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
              <Option name="draw_inside_polygon" type="QString" value="0"/>
              <Option name="joinstyle" type="QString" value="bevel"/>
              <Option name="line_color" type="QString" value="35,35,35,255"/>
              <Option name="line_style" type="QString" value="solid"/>
              <Option name="line_width" type="QString" value="0.26"/>
              <Option name="line_width_unit" type="QString" value="MM"/>
              <Option name="offset" type="QString" value="0"/>
              <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offset_unit" type="QString" value="MM"/>
              <Option name="ring_filter" type="QString" value="0"/>
              <Option name="trim_distance_end" type="QString" value="0"/>
              <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_end_unit" type="QString" value="MM"/>
              <Option name="trim_distance_start" type="QString" value="0"/>
              <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_start_unit" type="QString" value="MM"/>
              <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
              <Option name="use_custom_dash" type="QString" value="0"/>
              <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings placement="0" obstacle="0" showAll="1" linePlacementFlags="18" zIndex="0" dist="0" priority="0">
    <properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CODIGO_UNICO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="UV" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CODIGO_DO_ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="QUADRA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="FACE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CEP" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LOCALIDADE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PONTO_DE_REFERENCIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ESPECIES" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="SATELITES" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PDOP" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LATITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LONGITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Logr_N" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Local_N" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Compl_N" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="STATUS" name="" index="0"/>
    <alias field="CODIGO_UNICO" name="" index="1"/>
    <alias field="UV" name="" index="2"/>
    <alias field="CODIGO_DO_ENDERECO" name="" index="3"/>
    <alias field="QUADRA" name="" index="4"/>
    <alias field="FACE" name="" index="5"/>
    <alias field="CEP" name="" index="6"/>
    <alias field="LOCALIDADE" name="" index="7"/>
    <alias field="ENDERECO" name="" index="8"/>
    <alias field="PONTO_DE_REFERENCIA" name="" index="9"/>
    <alias field="ESPECIES" name="" index="10"/>
    <alias field="SATELITES" name="" index="11"/>
    <alias field="PDOP" name="" index="12"/>
    <alias field="LATITUDE" name="" index="13"/>
    <alias field="LONGITUDE" name="" index="14"/>
    <alias field="Logr_N" name="" index="15"/>
    <alias field="Local_N" name="" index="16"/>
    <alias field="Compl_N" name="" index="17"/>
  </aliases>
  <defaults>
    <default field="STATUS" expression="" applyOnUpdate="0"/>
    <default field="CODIGO_UNICO" expression="" applyOnUpdate="0"/>
    <default field="UV" expression="" applyOnUpdate="0"/>
    <default field="CODIGO_DO_ENDERECO" expression="" applyOnUpdate="0"/>
    <default field="QUADRA" expression="" applyOnUpdate="0"/>
    <default field="FACE" expression="" applyOnUpdate="0"/>
    <default field="CEP" expression="" applyOnUpdate="0"/>
    <default field="LOCALIDADE" expression="" applyOnUpdate="0"/>
    <default field="ENDERECO" expression="" applyOnUpdate="0"/>
    <default field="PONTO_DE_REFERENCIA" expression="" applyOnUpdate="0"/>
    <default field="ESPECIES" expression="" applyOnUpdate="0"/>
    <default field="SATELITES" expression="" applyOnUpdate="0"/>
    <default field="PDOP" expression="" applyOnUpdate="0"/>
    <default field="LATITUDE" expression="" applyOnUpdate="0"/>
    <default field="LONGITUDE" expression="" applyOnUpdate="0"/>
    <default field="Logr_N" expression="" applyOnUpdate="0"/>
    <default field="Local_N" expression="" applyOnUpdate="0"/>
    <default field="Compl_N" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="STATUS" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="CODIGO_UNICO" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="UV" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="CODIGO_DO_ENDERECO" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="QUADRA" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="FACE" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="CEP" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="LOCALIDADE" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="ENDERECO" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="PONTO_DE_REFERENCIA" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="ESPECIES" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="SATELITES" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="PDOP" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="LATITUDE" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="LONGITUDE" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="Logr_N" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="Local_N" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="Compl_N" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="STATUS" exp="" desc=""/>
    <constraint field="CODIGO_UNICO" exp="" desc=""/>
    <constraint field="UV" exp="" desc=""/>
    <constraint field="CODIGO_DO_ENDERECO" exp="" desc=""/>
    <constraint field="QUADRA" exp="" desc=""/>
    <constraint field="FACE" exp="" desc=""/>
    <constraint field="CEP" exp="" desc=""/>
    <constraint field="LOCALIDADE" exp="" desc=""/>
    <constraint field="ENDERECO" exp="" desc=""/>
    <constraint field="PONTO_DE_REFERENCIA" exp="" desc=""/>
    <constraint field="ESPECIES" exp="" desc=""/>
    <constraint field="SATELITES" exp="" desc=""/>
    <constraint field="PDOP" exp="" desc=""/>
    <constraint field="LATITUDE" exp="" desc=""/>
    <constraint field="LONGITUDE" exp="" desc=""/>
    <constraint field="Logr_N" exp="" desc=""/>
    <constraint field="Local_N" exp="" desc=""/>
    <constraint field="Compl_N" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortExpression="" actionWidgetStyle="dropDown" sortOrder="0">
    <columns>
      <column name="STATUS" hidden="0" type="field" width="-1"/>
      <column name="CODIGO_UNICO" hidden="0" type="field" width="-1"/>
      <column name="UV" hidden="0" type="field" width="-1"/>
      <column name="CODIGO_DO_ENDERECO" hidden="0" type="field" width="-1"/>
      <column name="QUADRA" hidden="0" type="field" width="-1"/>
      <column name="FACE" hidden="0" type="field" width="-1"/>
      <column name="CEP" hidden="0" type="field" width="-1"/>
      <column name="LOCALIDADE" hidden="0" type="field" width="-1"/>
      <column name="ENDERECO" hidden="0" type="field" width="-1"/>
      <column name="PONTO_DE_REFERENCIA" hidden="0" type="field" width="-1"/>
      <column name="ESPECIES" hidden="0" type="field" width="-1"/>
      <column name="SATELITES" hidden="0" type="field" width="-1"/>
      <column name="PDOP" hidden="0" type="field" width="-1"/>
      <column name="LATITUDE" hidden="0" type="field" width="-1"/>
      <column name="LONGITUDE" hidden="0" type="field" width="-1"/>
      <column name="Logr_N" hidden="0" type="field" width="-1"/>
      <column name="Local_N" hidden="0" type="field" width="-1"/>
      <column name="Compl_N" hidden="0" type="field" width="-1"/>
      <column hidden="1" type="actions" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="CEP" editable="1"/>
    <field name="CODIGO_DO_ENDERECO" editable="1"/>
    <field name="CODIGO_UNICO" editable="1"/>
    <field name="Compl_N" editable="1"/>
    <field name="ENDERECO" editable="1"/>
    <field name="ESPECIES" editable="1"/>
    <field name="FACE" editable="1"/>
    <field name="LATITUDE" editable="1"/>
    <field name="LOCALIDADE" editable="1"/>
    <field name="LONGITUDE" editable="1"/>
    <field name="Local_N" editable="1"/>
    <field name="Logr_N" editable="1"/>
    <field name="PDOP" editable="1"/>
    <field name="PONTO_DE_REFERENCIA" editable="1"/>
    <field name="QUADRA" editable="1"/>
    <field name="SATELITES" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="UV" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="CEP" labelOnTop="0"/>
    <field name="CODIGO_DO_ENDERECO" labelOnTop="0"/>
    <field name="CODIGO_UNICO" labelOnTop="0"/>
    <field name="Compl_N" labelOnTop="0"/>
    <field name="ENDERECO" labelOnTop="0"/>
    <field name="ESPECIES" labelOnTop="0"/>
    <field name="FACE" labelOnTop="0"/>
    <field name="LATITUDE" labelOnTop="0"/>
    <field name="LOCALIDADE" labelOnTop="0"/>
    <field name="LONGITUDE" labelOnTop="0"/>
    <field name="Local_N" labelOnTop="0"/>
    <field name="Logr_N" labelOnTop="0"/>
    <field name="PDOP" labelOnTop="0"/>
    <field name="PONTO_DE_REFERENCIA" labelOnTop="0"/>
    <field name="QUADRA" labelOnTop="0"/>
    <field name="SATELITES" labelOnTop="0"/>
    <field name="STATUS" labelOnTop="0"/>
    <field name="UV" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CEP" reuseLastValue="0"/>
    <field name="CODIGO_DO_ENDERECO" reuseLastValue="0"/>
    <field name="CODIGO_UNICO" reuseLastValue="0"/>
    <field name="Compl_N" reuseLastValue="0"/>
    <field name="ENDERECO" reuseLastValue="0"/>
    <field name="ESPECIES" reuseLastValue="0"/>
    <field name="FACE" reuseLastValue="0"/>
    <field name="LATITUDE" reuseLastValue="0"/>
    <field name="LOCALIDADE" reuseLastValue="0"/>
    <field name="LONGITUDE" reuseLastValue="0"/>
    <field name="Local_N" reuseLastValue="0"/>
    <field name="Logr_N" reuseLastValue="0"/>
    <field name="PDOP" reuseLastValue="0"/>
    <field name="PONTO_DE_REFERENCIA" reuseLastValue="0"/>
    <field name="QUADRA" reuseLastValue="0"/>
    <field name="SATELITES" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="UV" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"STATUS"</previewExpression>
  <mapTip>&lt;!DOCTYPE html>
                                        &lt;html>
                                          &lt;head>
                                            &lt;meta http-equiv="content-type" content="text/html; charset=UTF-8">
                                            &lt;style>
                                                table.grey{
                                                    border-style: none;
                                                    width: auto;
                                                    padding: 15px;
                                                    border-collapse: collapse;
                                                    border-left: 0;
                                                    border-right: 0;
                                                    border-radius: 10px;
                                                    border-spacing: 0px;
                                                    overflow:hidden; /* hide overflowing cells */
                                                }
                                            &lt;/style>                    
                                          &lt;/head>
                                          &lt;body>
                                            &lt;table  class="grey">
                                                &lt;tbody>
                                                    &lt;tr style="height: 18px; width: auto;">
                                                        &lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">Atributo&lt;/span>&lt;/td>
                                                        &lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">valor&lt;/span>&lt;/td>
                                                    &lt;/tr>
                                                    &lt;tr style="font-size: 12px; width: auto;">
                                                        &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">UV&lt;/span>&lt;/td>
                                                        &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%UV%]&lt;/span>&lt;/strong>&lt;/td>
                                                    &lt;/tr>                                   
                                                    &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">
                                                        &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">ENDEREÇO&lt;/span>&lt;/td>
                                                        &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%ENDERECO%]&lt;/span>&lt;/strong>&lt;/td>
                                                    &lt;/tr>                                   
                                                    &lt;tr style="font-size: 12px; width: auto;">
                                                        &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">PONTO DE REFERENCIA&lt;/span>&lt;/td>
                                                        &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%PONTO_DE_REFERENCIA%]&lt;/span>&lt;/strong>&lt;/td>
                                                    &lt;/tr>
                                                    &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">
                                                        &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CÓDIGO DO ENDEREÇO&lt;/span>&lt;/td>
                                                        &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%CODIGO_DO_ENDERECO%]&lt;/span>&lt;/strong>&lt;/td>
                                                    &lt;/tr>                                   
                                                    &lt;tr style="font-size: 12px; width: auto;">
                                                        &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CEP&lt;/span>&lt;/td>
                                                        &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%CEP%]&lt;/span>&lt;/strong>&lt;/td>
                                                    &lt;/tr>
                                                    &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">
                                                        &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">LOCALIDADE&lt;/span>&lt;/td>
                                                        &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%LOCALIDADE%]&lt;/span>&lt;/strong>&lt;/td>
                                                    &lt;/tr>
                                                    &lt;tr style="font-size: 12px; width: auto;">
                                                        &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">STATUS&lt;/span>&lt;/td>
                                                        &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%STATUS%]&lt;/span>&lt;/strong>&lt;/td>
                                                    &lt;/tr>                                  
                                                    
                                                &lt;/tbody>
                                            &lt;/table>    
                                          &lt;/body>
                                        &lt;/html></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
