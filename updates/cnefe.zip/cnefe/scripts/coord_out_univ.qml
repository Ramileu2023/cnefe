<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyAlgorithm="0" version="3.28.15-Firenze" labelsEnabled="0" hasScaleBasedVisibilityFlag="0" maxScale="0" simplifyDrawingTol="1" simplifyMaxScale="1" minScale="100000000" symbologyReferenceScale="-1" simplifyLocal="1" readOnly="0" styleCategories="AllStyleCategories" simplifyDrawingHints="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endField="" fixedDuration="0" enabled="0" limitMode="0" endExpression="" accumulate="0" durationUnit="min" mode="0" startField="" startExpression="" durationField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation type="IndividualFeatures" showMarkerSymbolInSurfacePlots="0" zscale="1" binding="Centroid" symbology="Line" zoffset="0" extrusion="0" clamping="Terrain" respectLayerSymbol="1" extrusionEnabled="0">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" force_rhr="0" clip_to_extent="1" type="line" is_animated="0" frame_rate="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" locked="0" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="183,72,75,255"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" force_rhr="0" clip_to_extent="1" type="fill" is_animated="0" frame_rate="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleFill" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="183,72,75,255"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="131,51,54,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol name="" force_rhr="0" clip_to_extent="1" type="marker" is_animated="0" frame_rate="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleMarker" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="183,72,75,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="131,51,54,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 type="singleSymbol" referencescale="-1" symbollevels="0" enableorderby="0" forceraster="0">
    <symbols>
      <symbol name="0" force_rhr="0" clip_to_extent="1" type="marker" is_animated="0" frame_rate="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleMarker" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="0,255,0,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="0,0,0,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="area"/>
            <Option name="size" type="QString" value="4"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleMarker" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="227,26,28,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="227,26,28,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.4"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="area"/>
            <Option name="size" type="QString" value="0.875"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style previewBkgrdColor="255,255,255,255" forcedBold="0" fontWordSpacing="0" fontStrikeout="0" multilineHeight="1" useSubstitutions="0" fieldName="CODIGO_DO_ENDERECO" multilineHeightUnit="Percentage" namedStyle="Normal" fontSize="12" forcedItalic="0" allowHtml="0" isExpression="0" fontLetterSpacing="0" textColor="0,0,255,255" fontKerning="1" fontWeight="50" fontFamily="Arial Black" legendString="Aa" capitalization="0" fontSizeUnit="Point" fontItalic="0" textOrientation="horizontal" blendMode="0" textOpacity="1" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0">
        <families/>
        <text-buffer bufferNoFill="0" bufferBlendMode="0" bufferJoinStyle="128" bufferSize="1.2" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferColor="250,250,250,255" bufferOpacity="1" bufferDraw="1"/>
        <text-mask maskSize="4.5" maskSizeUnits="MM" maskOpacity="1" maskType="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskedSymbolLayers="" maskEnabled="1" maskJoinStyle="128"/>
        <background shapeRadiiY="0" shapeFillColor="255,255,255,255" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSVGFile="" shapeBorderColor="128,128,128,255" shapeDraw="0" shapeOffsetY="0" shapeRotationType="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeSizeType="0" shapeBorderWidthUnit="Point" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="Point" shapeSizeUnit="Point" shapeOffsetX="0" shapeSizeX="0" shapeRotation="0" shapeType="0" shapeOffsetUnit="Point">
          <symbol name="markerSymbol" force_rhr="0" clip_to_extent="1" type="marker" is_animated="0" frame_rate="10" alpha="1">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" class="SimpleMarker" locked="0" pass="0">
              <Option type="Map">
                <Option name="angle" type="QString" value="0"/>
                <Option name="cap_style" type="QString" value="square"/>
                <Option name="color" type="QString" value="255,158,23,255"/>
                <Option name="horizontal_anchor_point" type="QString" value="1"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="name" type="QString" value="circle"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="35,35,35,255"/>
                <Option name="outline_style" type="QString" value="solid"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="outline_width_unit" type="QString" value="MM"/>
                <Option name="scale_method" type="QString" value="diameter"/>
                <Option name="size" type="QString" value="2"/>
                <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="size_unit" type="QString" value="MM"/>
                <Option name="vertical_anchor_point" type="QString" value="1"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol name="fillSymbol" force_rhr="0" clip_to_extent="1" type="fill" is_animated="0" frame_rate="10" alpha="1">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" class="SimpleFill" locked="0" pass="0">
              <Option type="Map">
                <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="color" type="QString" value="255,255,255,255"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="128,128,128,255"/>
                <Option name="outline_style" type="QString" value="no"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_unit" type="QString" value="Point"/>
                <Option name="style" type="QString" value="solid"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowDraw="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowOffsetUnit="MM" shadowOffsetAngle="135" shadowColor="0,0,0,255" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowBlendMode="6" shadowUnder="0" shadowOffsetDist="1" shadowOffsetGlobal="1"/>
        <dd_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format multilineAlign="3" placeDirectionSymbol="0" reverseDirectionSymbol="0" addDirectionSymbol="0" autoWrapLength="0" wrapChar="" useMaxLineLengthForAutoWrap="1" formatNumbers="0" decimals="3" plussign="0" leftDirectionSymbol="&lt;" rightDirectionSymbol=">"/>
      <placement lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" maxCurvedCharAngleIn="25" repeatDistance="0" priority="5" dist="0" placement="6" xOffset="0" distMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" rotationUnit="AngleDegrees" maxCurvedCharAngleOut="-25" rotationAngle="0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" distUnits="MM" yOffset="0" allowDegraded="0" geometryGeneratorEnabled="0" overlapHandling="PreventOverlap" lineAnchorClipping="0" repeatDistanceUnits="MM" centroidInside="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" overrunDistance="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" offsetType="1" preserveRotation="1" quadOffset="4" centroidWhole="0" polygonPlacementFlags="2" placementFlags="10" lineAnchorType="0" offsetUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0"/>
      <rendering obstacle="1" minFeatureSize="0" mergeLines="0" fontLimitPixelSize="0" fontMaxPixelSize="10000" obstacleFactor="1" scaleVisibility="0" scaleMax="0" drawLabels="1" obstacleType="1" unplacedVisibility="0" fontMinPixelSize="3" scaleMin="0" upsidedownLabels="0" zIndex="0" limitNumLabels="0" labelPerPart="0" maxNumLabels="2000"/>
      <dd_properties>
        <Option type="Map">
          <Option name="name" type="QString" value=""/>
          <Option name="properties"/>
          <Option name="type" type="QString" value="collection"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
          <Option name="blendMode" type="int" value="0"/>
          <Option name="ddProperties" type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
          <Option name="drawToAllParts" type="bool" value="false"/>
          <Option name="enabled" type="QString" value="0"/>
          <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
          <Option name="lineSymbol" type="QString" value="&lt;symbol name=&quot;symbol&quot; force_rhr=&quot;0&quot; clip_to_extent=&quot;1&quot; type=&quot;line&quot; is_animated=&quot;0&quot; frame_rate=&quot;10&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
          <Option name="minLength" type="double" value="0"/>
          <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="minLengthUnit" type="QString" value="MM"/>
          <Option name="offsetFromAnchor" type="double" value="0"/>
          <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
          <Option name="offsetFromLabel" type="double" value="0"/>
          <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option name="OnConvertFormatRegeneratePrimaryKey" type="bool" value="true"/>
      <Option name="dualview/previewExpressions" type="List">
        <Option type="QString" value="&quot;NOM_LOGR&quot;"/>
        <Option type="QString" value="&quot;NOM_TIPO_SEGLOGR&quot;"/>
      </Option>
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory opacity="1" backgroundAlpha="255" penColor="#000000" width="15" spacingUnitScale="3x:0,0,0,0,0,0" spacing="5" lineSizeType="MM" labelPlacementMethod="XHeight" minScaleDenominator="0" penAlpha="255" rotationOffset="270" scaleBasedVisibility="0" sizeType="MM" height="15" enabled="0" sizeScale="3x:0,0,0,0,0,0" penWidth="0" scaleDependency="Area" direction="0" maxScaleDenominator="1e+08" minimumSize="0" showAxis="1" barWidth="5" backgroundColor="#ffffff" diagramOrientation="Up" spacingUnit="MM" lineSizeScale="3x:0,0,0,0,0,0">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" underline="0" style="" bold="0" italic="0" strikethrough="0"/>
      <attribute color="#000000" colorOpacity="1" label="" field=""/>
      <axisSymbol>
        <symbol name="" force_rhr="0" clip_to_extent="1" type="line" is_animated="0" frame_rate="10" alpha="1">
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer enabled="1" class="SimpleLine" locked="0" pass="0">
            <Option type="Map">
              <Option name="align_dash_pattern" type="QString" value="0"/>
              <Option name="capstyle" type="QString" value="square"/>
              <Option name="customdash" type="QString" value="5;2"/>
              <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="customdash_unit" type="QString" value="MM"/>
              <Option name="dash_pattern_offset" type="QString" value="0"/>
              <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
              <Option name="draw_inside_polygon" type="QString" value="0"/>
              <Option name="joinstyle" type="QString" value="bevel"/>
              <Option name="line_color" type="QString" value="35,35,35,255"/>
              <Option name="line_style" type="QString" value="solid"/>
              <Option name="line_width" type="QString" value="0.26"/>
              <Option name="line_width_unit" type="QString" value="MM"/>
              <Option name="offset" type="QString" value="0"/>
              <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offset_unit" type="QString" value="MM"/>
              <Option name="ring_filter" type="QString" value="0"/>
              <Option name="trim_distance_end" type="QString" value="0"/>
              <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_end_unit" type="QString" value="MM"/>
              <Option name="trim_distance_start" type="QString" value="0"/>
              <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_start_unit" type="QString" value="MM"/>
              <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
              <Option name="use_custom_dash" type="QString" value="0"/>
              <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings priority="0" placement="0" obstacle="0" dist="0" showAll="1" linePlacementFlags="18" zIndex="0">
    <properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="COD_SETOR" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NUM_QUADRA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NUM_FACE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_UNICO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TIPO_LOGR" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TITULO_LOGR" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NOM_LOGR" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NUM_END" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MODIF" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COMPL" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CONDOMINIO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LATITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LONGITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="UNIDADES" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DISTANCIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" field="COD_SETOR" index="0"/>
    <alias name="" field="NUM_QUADRA" index="1"/>
    <alias name="" field="NUM_FACE" index="2"/>
    <alias name="" field="COD_ENDERECO" index="3"/>
    <alias name="" field="COD_UNICO" index="4"/>
    <alias name="" field="TIPO_LOGR" index="5"/>
    <alias name="" field="TITULO_LOGR" index="6"/>
    <alias name="" field="NOM_LOGR" index="7"/>
    <alias name="" field="NUM_END" index="8"/>
    <alias name="" field="MODIF" index="9"/>
    <alias name="" field="COMPL" index="10"/>
    <alias name="" field="CONDOMINIO" index="11"/>
    <alias name="" field="LATITUDE" index="12"/>
    <alias name="" field="LONGITUDE" index="13"/>
    <alias name="" field="UNIDADES" index="14"/>
    <alias name="" field="DISTANCIA" index="15"/>
  </aliases>
  <defaults>
    <default expression="" field="COD_SETOR" applyOnUpdate="0"/>
    <default expression="" field="NUM_QUADRA" applyOnUpdate="0"/>
    <default expression="" field="NUM_FACE" applyOnUpdate="0"/>
    <default expression="" field="COD_ENDERECO" applyOnUpdate="0"/>
    <default expression="" field="COD_UNICO" applyOnUpdate="0"/>
    <default expression="" field="TIPO_LOGR" applyOnUpdate="0"/>
    <default expression="" field="TITULO_LOGR" applyOnUpdate="0"/>
    <default expression="" field="NOM_LOGR" applyOnUpdate="0"/>
    <default expression="" field="NUM_END" applyOnUpdate="0"/>
    <default expression="" field="MODIF" applyOnUpdate="0"/>
    <default expression="" field="COMPL" applyOnUpdate="0"/>
    <default expression="" field="CONDOMINIO" applyOnUpdate="0"/>
    <default expression="" field="LATITUDE" applyOnUpdate="0"/>
    <default expression="" field="LONGITUDE" applyOnUpdate="0"/>
    <default expression="" field="UNIDADES" applyOnUpdate="0"/>
    <default expression="" field="DISTANCIA" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="COD_SETOR" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="NUM_QUADRA" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="NUM_FACE" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="COD_ENDERECO" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="COD_UNICO" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="TIPO_LOGR" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="TITULO_LOGR" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="NOM_LOGR" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="NUM_END" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="MODIF" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="COMPL" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="CONDOMINIO" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="LATITUDE" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="LONGITUDE" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="UNIDADES" exp_strength="0"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" field="DISTANCIA" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="COD_SETOR"/>
    <constraint exp="" desc="" field="NUM_QUADRA"/>
    <constraint exp="" desc="" field="NUM_FACE"/>
    <constraint exp="" desc="" field="COD_ENDERECO"/>
    <constraint exp="" desc="" field="COD_UNICO"/>
    <constraint exp="" desc="" field="TIPO_LOGR"/>
    <constraint exp="" desc="" field="TITULO_LOGR"/>
    <constraint exp="" desc="" field="NOM_LOGR"/>
    <constraint exp="" desc="" field="NUM_END"/>
    <constraint exp="" desc="" field="MODIF"/>
    <constraint exp="" desc="" field="COMPL"/>
    <constraint exp="" desc="" field="CONDOMINIO"/>
    <constraint exp="" desc="" field="LATITUDE"/>
    <constraint exp="" desc="" field="LONGITUDE"/>
    <constraint exp="" desc="" field="UNIDADES"/>
    <constraint exp="" desc="" field="DISTANCIA"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" actionWidgetStyle="dropDown" sortExpression="&quot;MODIF&quot;">
    <columns>
      <column name="LATITUDE" type="field" hidden="0" width="-1"/>
      <column name="LONGITUDE" type="field" hidden="0" width="-1"/>
      <column name="COD_SETOR" type="field" hidden="0" width="-1"/>
      <column name="NUM_QUADRA" type="field" hidden="0" width="-1"/>
      <column name="NUM_FACE" type="field" hidden="0" width="-1"/>
      <column name="COD_ENDERECO" type="field" hidden="0" width="-1"/>
      <column name="COD_UNICO" type="field" hidden="0" width="-1"/>
      <column name="TIPO_LOGR" type="field" hidden="0" width="-1"/>
      <column name="TITULO_LOGR" type="field" hidden="0" width="-1"/>
      <column name="NOM_LOGR" type="field" hidden="0" width="-1"/>
      <column name="NUM_END" type="field" hidden="0" width="-1"/>
      <column name="MODIF" type="field" hidden="0" width="-1"/>
      <column name="COMPL" type="field" hidden="0" width="-1"/>
      <column name="CONDOMINIO" type="field" hidden="0" width="-1"/>
      <column name="UNIDADES" type="field" hidden="0" width="-1"/>
      <column name="DISTANCIA" type="field" hidden="0" width="-1"/>
      <column type="actions" hidden="1" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="CEP" editable="1"/>
    <field name="CODIGO_DO_ENDERECO" editable="1"/>
    <field name="CODIGO_UNICO" editable="1"/>
    <field name="COD_DISTRITO" editable="1"/>
    <field name="COD_ENDERECO" editable="1"/>
    <field name="COD_ESPECIE" editable="1"/>
    <field name="COD_INDICADOR_CONST_ENDERECO" editable="1"/>
    <field name="COD_INDICADOR_ESTAB_ENDERECO" editable="1"/>
    <field name="COD_INDICADOR_FINALIDADE_CONST" editable="1"/>
    <field name="COD_MUNICIPIO" editable="1"/>
    <field name="COD_SETOR" editable="1"/>
    <field name="COD_SUBDISTRITO" editable="1"/>
    <field name="COD_TIPO_ESPECI" editable="1"/>
    <field name="COD_UF" editable="1"/>
    <field name="COD_UNICO" editable="1"/>
    <field name="COD_UNICO_ENDERECO" editable="1"/>
    <field name="COMPL" editable="1"/>
    <field name="CONDOMINIO" editable="1"/>
    <field name="DATA_DE_CONFIRMACAO" editable="1"/>
    <field name="DISTANCE" editable="1"/>
    <field name="DISTANCIA" editable="1"/>
    <field name="DSC_ESTABELECIMENTO" editable="1"/>
    <field name="DSC_LOCALIDADE" editable="1"/>
    <field name="DSC_MODIFICADOR" editable="1"/>
    <field name="ENDERECO" editable="1"/>
    <field name="ESPECIES" editable="1"/>
    <field name="FACE" editable="1"/>
    <field name="LATITUDE" editable="1"/>
    <field name="LOCALIDADE" editable="1"/>
    <field name="LONGITUDE" editable="1"/>
    <field name="MODIF" editable="1"/>
    <field name="NOM_COMP_ELEM1" editable="1"/>
    <field name="NOM_COMP_ELEM2" editable="1"/>
    <field name="NOM_COMP_ELEM3" editable="1"/>
    <field name="NOM_COMP_ELEM4" editable="1"/>
    <field name="NOM_COMP_ELEM5" editable="1"/>
    <field name="NOM_LOGR" editable="1"/>
    <field name="NOM_SEGLOGR" editable="1"/>
    <field name="NOM_TIPO_SEGLOGR" editable="1"/>
    <field name="NOM_TITULO_SEGLOGR" editable="1"/>
    <field name="NUM_END" editable="1"/>
    <field name="NUM_ENDERECO" editable="1"/>
    <field name="NUM_FACE" editable="1"/>
    <field name="NUM_QUADRA" editable="1"/>
    <field name="NV_GEO_COORD" editable="1"/>
    <field name="PDOP" editable="1"/>
    <field name="PONTO_DE_REFERENCIA" editable="1"/>
    <field name="QUADRA" editable="1"/>
    <field name="SATELITES" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="TIPO_LOGR" editable="1"/>
    <field name="TITULO_LOGR" editable="1"/>
    <field name="UNIDADES" editable="1"/>
    <field name="UV" editable="1"/>
    <field name="VAL_COMP_ELEM1" editable="1"/>
    <field name="VAL_COMP_ELEM2" editable="1"/>
    <field name="VAL_COMP_ELEM3" editable="1"/>
    <field name="VAL_COMP_ELEM4" editable="1"/>
    <field name="VAL_COMP_ELEM5" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="CEP" labelOnTop="0"/>
    <field name="CODIGO_DO_ENDERECO" labelOnTop="0"/>
    <field name="CODIGO_UNICO" labelOnTop="0"/>
    <field name="COD_DISTRITO" labelOnTop="0"/>
    <field name="COD_ENDERECO" labelOnTop="0"/>
    <field name="COD_ESPECIE" labelOnTop="0"/>
    <field name="COD_INDICADOR_CONST_ENDERECO" labelOnTop="0"/>
    <field name="COD_INDICADOR_ESTAB_ENDERECO" labelOnTop="0"/>
    <field name="COD_INDICADOR_FINALIDADE_CONST" labelOnTop="0"/>
    <field name="COD_MUNICIPIO" labelOnTop="0"/>
    <field name="COD_SETOR" labelOnTop="0"/>
    <field name="COD_SUBDISTRITO" labelOnTop="0"/>
    <field name="COD_TIPO_ESPECI" labelOnTop="0"/>
    <field name="COD_UF" labelOnTop="0"/>
    <field name="COD_UNICO" labelOnTop="0"/>
    <field name="COD_UNICO_ENDERECO" labelOnTop="0"/>
    <field name="COMPL" labelOnTop="0"/>
    <field name="CONDOMINIO" labelOnTop="0"/>
    <field name="DATA_DE_CONFIRMACAO" labelOnTop="0"/>
    <field name="DISTANCE" labelOnTop="0"/>
    <field name="DISTANCIA" labelOnTop="0"/>
    <field name="DSC_ESTABELECIMENTO" labelOnTop="0"/>
    <field name="DSC_LOCALIDADE" labelOnTop="0"/>
    <field name="DSC_MODIFICADOR" labelOnTop="0"/>
    <field name="ENDERECO" labelOnTop="0"/>
    <field name="ESPECIES" labelOnTop="0"/>
    <field name="FACE" labelOnTop="0"/>
    <field name="LATITUDE" labelOnTop="0"/>
    <field name="LOCALIDADE" labelOnTop="0"/>
    <field name="LONGITUDE" labelOnTop="0"/>
    <field name="MODIF" labelOnTop="0"/>
    <field name="NOM_COMP_ELEM1" labelOnTop="0"/>
    <field name="NOM_COMP_ELEM2" labelOnTop="0"/>
    <field name="NOM_COMP_ELEM3" labelOnTop="0"/>
    <field name="NOM_COMP_ELEM4" labelOnTop="0"/>
    <field name="NOM_COMP_ELEM5" labelOnTop="0"/>
    <field name="NOM_LOGR" labelOnTop="0"/>
    <field name="NOM_SEGLOGR" labelOnTop="0"/>
    <field name="NOM_TIPO_SEGLOGR" labelOnTop="0"/>
    <field name="NOM_TITULO_SEGLOGR" labelOnTop="0"/>
    <field name="NUM_END" labelOnTop="0"/>
    <field name="NUM_ENDERECO" labelOnTop="0"/>
    <field name="NUM_FACE" labelOnTop="0"/>
    <field name="NUM_QUADRA" labelOnTop="0"/>
    <field name="NV_GEO_COORD" labelOnTop="0"/>
    <field name="PDOP" labelOnTop="0"/>
    <field name="PONTO_DE_REFERENCIA" labelOnTop="0"/>
    <field name="QUADRA" labelOnTop="0"/>
    <field name="SATELITES" labelOnTop="0"/>
    <field name="STATUS" labelOnTop="0"/>
    <field name="TIPO_LOGR" labelOnTop="0"/>
    <field name="TITULO_LOGR" labelOnTop="0"/>
    <field name="UNIDADES" labelOnTop="0"/>
    <field name="UV" labelOnTop="0"/>
    <field name="VAL_COMP_ELEM1" labelOnTop="0"/>
    <field name="VAL_COMP_ELEM2" labelOnTop="0"/>
    <field name="VAL_COMP_ELEM3" labelOnTop="0"/>
    <field name="VAL_COMP_ELEM4" labelOnTop="0"/>
    <field name="VAL_COMP_ELEM5" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CEP" reuseLastValue="0"/>
    <field name="CODIGO_DO_ENDERECO" reuseLastValue="0"/>
    <field name="CODIGO_UNICO" reuseLastValue="0"/>
    <field name="COD_DISTRITO" reuseLastValue="0"/>
    <field name="COD_ENDERECO" reuseLastValue="0"/>
    <field name="COD_ESPECIE" reuseLastValue="0"/>
    <field name="COD_INDICADOR_CONST_ENDERECO" reuseLastValue="0"/>
    <field name="COD_INDICADOR_ESTAB_ENDERECO" reuseLastValue="0"/>
    <field name="COD_INDICADOR_FINALIDADE_CONST" reuseLastValue="0"/>
    <field name="COD_MUNICIPIO" reuseLastValue="0"/>
    <field name="COD_SETOR" reuseLastValue="0"/>
    <field name="COD_SUBDISTRITO" reuseLastValue="0"/>
    <field name="COD_TIPO_ESPECI" reuseLastValue="0"/>
    <field name="COD_UF" reuseLastValue="0"/>
    <field name="COD_UNICO" reuseLastValue="0"/>
    <field name="COD_UNICO_ENDERECO" reuseLastValue="0"/>
    <field name="COMPL" reuseLastValue="0"/>
    <field name="CONDOMINIO" reuseLastValue="0"/>
    <field name="DATA_DE_CONFIRMACAO" reuseLastValue="0"/>
    <field name="DISTANCE" reuseLastValue="0"/>
    <field name="DISTANCIA" reuseLastValue="0"/>
    <field name="DSC_ESTABELECIMENTO" reuseLastValue="0"/>
    <field name="DSC_LOCALIDADE" reuseLastValue="0"/>
    <field name="DSC_MODIFICADOR" reuseLastValue="0"/>
    <field name="ENDERECO" reuseLastValue="0"/>
    <field name="ESPECIES" reuseLastValue="0"/>
    <field name="FACE" reuseLastValue="0"/>
    <field name="LATITUDE" reuseLastValue="0"/>
    <field name="LOCALIDADE" reuseLastValue="0"/>
    <field name="LONGITUDE" reuseLastValue="0"/>
    <field name="MODIF" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM1" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM2" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM3" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM4" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM5" reuseLastValue="0"/>
    <field name="NOM_LOGR" reuseLastValue="0"/>
    <field name="NOM_SEGLOGR" reuseLastValue="0"/>
    <field name="NOM_TIPO_SEGLOGR" reuseLastValue="0"/>
    <field name="NOM_TITULO_SEGLOGR" reuseLastValue="0"/>
    <field name="NUM_END" reuseLastValue="0"/>
    <field name="NUM_ENDERECO" reuseLastValue="0"/>
    <field name="NUM_FACE" reuseLastValue="0"/>
    <field name="NUM_QUADRA" reuseLastValue="0"/>
    <field name="NV_GEO_COORD" reuseLastValue="0"/>
    <field name="PDOP" reuseLastValue="0"/>
    <field name="PONTO_DE_REFERENCIA" reuseLastValue="0"/>
    <field name="QUADRA" reuseLastValue="0"/>
    <field name="SATELITES" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="TIPO_LOGR" reuseLastValue="0"/>
    <field name="TITULO_LOGR" reuseLastValue="0"/>
    <field name="UNIDADES" reuseLastValue="0"/>
    <field name="UV" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM1" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM2" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM3" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM4" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM5" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip>&lt;!DOCTYPE html>&#xd;
                            &lt;html>&#xd;
                              &lt;head>&#xd;
                                &lt;meta http-equiv="content-type" content="text/html; charset=UTF-8">&#xd;
                                &lt;style>&#xd;
                                    table.grey{&#xd;
                                        border-style: none;&#xd;
                                        width: auto;&#xd;
                                        padding: 15px;&#xd;
                                        border-collapse: collapse;&#xd;
                                        border-left: 0;&#xd;
                                        border-right: 0;&#xd;
                                        border-radius: 10px;&#xd;
                                        border-spacing: 0px;&#xd;
                                        overflow:hidden; /* hide overflowing cells */&#xd;
                                    }&#xd;
                                &lt;/style>					&#xd;
                              &lt;/head>&#xd;
                              &lt;body>&#xd;
                                &lt;table  class="grey">&#xd;
                                    &lt;tbody>                           &#xd;
                                        &lt;tr style="height: 18px; width: auto;">&#xd;
                                            &lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">Atributo&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">valor&lt;/span>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto;">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">SETOR&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%COD_SETOR%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>                             &#xd;
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">QUADRA&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%NUM_QUADRA%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto;">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">FACE&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%NUM_FACE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CÓDIGO DO ENDEREÇO&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%COD_ENDERECO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &#xd;
                                        &lt;tr style="font-size: 12px; width: auto;">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CÓDIGO ÚNICO&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%COD_UNICO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">LOGRADOURO&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%TIPO_LOGR%] [%TITULO_LOGR%] [%NOM_LOGR%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto;">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">NÚMERO&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%NUM_END%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">MODIFICADOR&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%MODIF%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto;">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">COMPLEMENTO&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%COMPL%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CONDOMÍNIO&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%CONDOMINIO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>					&#xd;
                                    &lt;/tbody>&#xd;
                                &lt;/table>	&#xd;
                              &lt;/body>&#xd;
                            &lt;/html></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
