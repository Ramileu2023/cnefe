<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.9-Firenze" minScale="100000000" simplifyDrawingHints="0" simplifyAlgorithm="0" simplifyDrawingTol="1" symbologyReferenceScale="-1" hasScaleBasedVisibilityFlag="0" simplifyMaxScale="1" maxScale="0" styleCategories="AllStyleCategories" labelsEnabled="0" readOnly="0" simplifyLocal="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endField="" startField="" endExpression="" durationUnit="min" limitMode="0" mode="0" accumulate="0" fixedDuration="0" durationField="" enabled="0" startExpression="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation symbology="Line" extrusion="0" zscale="1" zoffset="0" extrusionEnabled="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" clamping="Terrain" binding="Centroid" type="IndividualFeatures">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" force_rhr="0" clip_to_extent="1" frame_rate="10" is_animated="0" type="line" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="183,72,75,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" force_rhr="0" clip_to_extent="1" frame_rate="10" is_animated="0" type="fill" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="183,72,75,255"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="131,51,54,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" force_rhr="0" clip_to_extent="1" frame_rate="10" is_animated="0" type="marker" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="183,72,75,255"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="diamond"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="131,51,54,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="3"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 referencescale="-1" symbollevels="0" enableorderby="0" type="singleSymbol" forceraster="0">
    <symbols>
      <symbol alpha="1" force_rhr="0" clip_to_extent="1" frame_rate="10" is_animated="0" type="marker" name="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="0,255,0,255"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="circle"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="0,0,0,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="area"/>
            <Option type="QString" name="size" value="4"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="227,26,28,255"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="circle"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="227,26,28,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.4"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="area"/>
            <Option type="QString" name="size" value="0.875"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontUnderline="0" forcedBold="0" legendString="Aa" multilineHeightUnit="Percentage" forcedItalic="0" textOpacity="1" fontSizeUnit="Point" isExpression="0" fontSize="12" fontFamily="Arial Black" namedStyle="Normal" allowHtml="0" capitalization="0" previewBkgrdColor="255,255,255,255" fontKerning="1" useSubstitutions="0" fontStrikeout="0" fontLetterSpacing="0" multilineHeight="1" textColor="0,0,255,255" fontWeight="50" fontItalic="0" fontWordSpacing="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textOrientation="horizontal" fieldName="CODIGO_DO_ENDERECO" blendMode="0">
        <families/>
        <text-buffer bufferOpacity="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferBlendMode="0" bufferNoFill="0" bufferJoinStyle="128" bufferColor="250,250,250,255" bufferSizeUnits="MM" bufferDraw="1" bufferSize="1.2"/>
        <text-mask maskSize="4.5" maskSizeUnits="MM" maskType="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskedSymbolLayers="" maskJoinStyle="128" maskOpacity="1" maskEnabled="1"/>
        <background shapeRadiiX="0" shapeBorderWidth="0" shapeSizeX="0" shapeOpacity="1" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRotation="0" shapeBorderColor="128,128,128,255" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="0" shapeBorderWidthUnit="Point" shapeSizeType="0" shapeBlendMode="0" shapeType="0" shapeRadiiY="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="Point" shapeSizeY="0" shapeSizeUnit="Point" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiUnit="Point" shapeOffsetX="0" shapeRotationType="0" shapeSVGFile="" shapeFillColor="255,255,255,255">
          <symbol alpha="1" force_rhr="0" clip_to_extent="1" frame_rate="10" is_animated="0" type="marker" name="markerSymbol">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
              <Option type="Map">
                <Option type="QString" name="angle" value="0"/>
                <Option type="QString" name="cap_style" value="square"/>
                <Option type="QString" name="color" value="255,158,23,255"/>
                <Option type="QString" name="horizontal_anchor_point" value="1"/>
                <Option type="QString" name="joinstyle" value="bevel"/>
                <Option type="QString" name="name" value="circle"/>
                <Option type="QString" name="offset" value="0,0"/>
                <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="outline_color" value="35,35,35,255"/>
                <Option type="QString" name="outline_style" value="solid"/>
                <Option type="QString" name="outline_width" value="0"/>
                <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="outline_width_unit" value="MM"/>
                <Option type="QString" name="scale_method" value="diameter"/>
                <Option type="QString" name="size" value="2"/>
                <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="size_unit" value="MM"/>
                <Option type="QString" name="vertical_anchor_point" value="1"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol alpha="1" force_rhr="0" clip_to_extent="1" frame_rate="10" is_animated="0" type="fill" name="fillSymbol">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer locked="0" pass="0" class="SimpleFill" enabled="1">
              <Option type="Map">
                <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="255,255,255,255"/>
                <Option type="QString" name="joinstyle" value="bevel"/>
                <Option type="QString" name="offset" value="0,0"/>
                <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="outline_color" value="128,128,128,255"/>
                <Option type="QString" name="outline_style" value="no"/>
                <Option type="QString" name="outline_width" value="0"/>
                <Option type="QString" name="outline_width_unit" value="Point"/>
                <Option type="QString" name="style" value="solid"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowOffsetDist="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowScale="100" shadowBlendMode="6" shadowUnder="0" shadowRadiusUnit="MM" shadowOffsetGlobal="1" shadowOpacity="0.69999999999999996" shadowColor="0,0,0,255" shadowDraw="0"/>
        <dd_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format addDirectionSymbol="0" multilineAlign="3" placeDirectionSymbol="0" formatNumbers="0" useMaxLineLengthForAutoWrap="1" wrapChar="" plussign="0" autoWrapLength="0" rightDirectionSymbol=">" leftDirectionSymbol="&lt;" reverseDirectionSymbol="0" decimals="3"/>
      <placement lineAnchorType="0" offsetUnits="MM" maxCurvedCharAngleIn="25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" xOffset="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" overrunDistanceUnit="MM" maxCurvedCharAngleOut="-25" centroidInside="0" yOffset="0" repeatDistanceUnits="MM" rotationUnit="AngleDegrees" distMapUnitScale="3x:0,0,0,0,0,0" placement="6" lineAnchorTextPoint="FollowPlacement" fitInPolygonOnly="0" rotationAngle="0" geometryGenerator="" centroidWhole="0" placementFlags="10" allowDegraded="0" lineAnchorClipping="0" priority="5" polygonPlacementFlags="2" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" dist="0" repeatDistance="0" overlapHandling="PreventOverlap" offsetType="1" layerType="PointGeometry" geometryGeneratorType="PointGeometry" lineAnchorPercent="0.5" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" geometryGeneratorEnabled="0" quadOffset="4"/>
      <rendering obstacleType="1" drawLabels="1" maxNumLabels="2000" obstacleFactor="1" fontLimitPixelSize="0" mergeLines="0" obstacle="1" unplacedVisibility="0" limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" scaleVisibility="0" fontMinPixelSize="3" scaleMax="0" minFeatureSize="0" zIndex="0" scaleMin="0" upsidedownLabels="0"/>
      <dd_properties>
        <Option type="Map">
          <Option type="QString" name="name" value=""/>
          <Option name="properties"/>
          <Option type="QString" name="type" value="collection"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
          <Option type="int" name="blendMode" value="0"/>
          <Option type="Map" name="ddProperties">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
          <Option type="bool" name="drawToAllParts" value="false"/>
          <Option type="QString" name="enabled" value="0"/>
          <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
          <Option type="QString" name="lineSymbol" value="&lt;symbol alpha=&quot;1&quot; force_rhr=&quot;0&quot; clip_to_extent=&quot;1&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; type=&quot;line&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
          <Option type="double" name="minLength" value="0"/>
          <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
          <Option type="QString" name="minLengthUnit" value="MM"/>
          <Option type="double" name="offsetFromAnchor" value="0"/>
          <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
          <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
          <Option type="double" name="offsetFromLabel" value="0"/>
          <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
          <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option type="bool" name="OnConvertFormatRegeneratePrimaryKey" value="true"/>
      <Option type="List" name="dualview/previewExpressions">
        <Option type="QString" value="&quot;NOM_TIPO_SEGLOGR&quot;"/>
      </Option>
      <Option type="int" name="embeddedWidgets/count" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory width="15" scaleBasedVisibility="0" penWidth="0" enabled="0" lineSizeScale="3x:0,0,0,0,0,0" barWidth="5" penAlpha="255" sizeScale="3x:0,0,0,0,0,0" diagramOrientation="Up" rotationOffset="270" minScaleDenominator="0" opacity="1" backgroundColor="#ffffff" scaleDependency="Area" height="15" spacing="5" maxScaleDenominator="1e+08" spacingUnit="MM" sizeType="MM" labelPlacementMethod="XHeight" lineSizeType="MM" penColor="#000000" minimumSize="0" backgroundAlpha="255" showAxis="1" direction="0" spacingUnitScale="3x:0,0,0,0,0,0">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" bold="0" style="" underline="0" strikethrough="0" italic="0"/>
      <attribute color="#000000" field="" colorOpacity="1" label=""/>
      <axisSymbol>
        <symbol alpha="1" force_rhr="0" clip_to_extent="1" frame_rate="10" is_animated="0" type="line" name="">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer locked="0" pass="0" class="SimpleLine" enabled="1">
            <Option type="Map">
              <Option type="QString" name="align_dash_pattern" value="0"/>
              <Option type="QString" name="capstyle" value="square"/>
              <Option type="QString" name="customdash" value="5;2"/>
              <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="customdash_unit" value="MM"/>
              <Option type="QString" name="dash_pattern_offset" value="0"/>
              <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
              <Option type="QString" name="draw_inside_polygon" value="0"/>
              <Option type="QString" name="joinstyle" value="bevel"/>
              <Option type="QString" name="line_color" value="35,35,35,255"/>
              <Option type="QString" name="line_style" value="solid"/>
              <Option type="QString" name="line_width" value="0.26"/>
              <Option type="QString" name="line_width_unit" value="MM"/>
              <Option type="QString" name="offset" value="0"/>
              <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="offset_unit" value="MM"/>
              <Option type="QString" name="ring_filter" value="0"/>
              <Option type="QString" name="trim_distance_end" value="0"/>
              <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_end_unit" value="MM"/>
              <Option type="QString" name="trim_distance_start" value="0"/>
              <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_start_unit" value="MM"/>
              <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
              <Option type="QString" name="use_custom_dash" value="0"/>
              <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings showAll="1" placement="0" linePlacementFlags="18" zIndex="0" priority="0" obstacle="0" dist="0">
    <properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="None" name="COD_SETOR">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="UV">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ENDERECO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="PONTO_DE_REFERENCIA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="QUADRA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="FACE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="CODIGO_DO_ENDERECO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="CODIGO_UNICO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="CEP">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LOCALIDADE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="STATUS">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="DATA_DE_CONFIRMACAO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="SATELITES">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="PDOP">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LATITUDE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LONGITUDE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="VALIDACAO_CEP">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="COD_SETOR" name=""/>
    <alias index="1" field="UV" name=""/>
    <alias index="2" field="ENDERECO" name=""/>
    <alias index="3" field="PONTO_DE_REFERENCIA" name=""/>
    <alias index="4" field="QUADRA" name=""/>
    <alias index="5" field="FACE" name=""/>
    <alias index="6" field="CODIGO_DO_ENDERECO" name=""/>
    <alias index="7" field="CODIGO_UNICO" name=""/>
    <alias index="8" field="CEP" name=""/>
    <alias index="9" field="LOCALIDADE" name=""/>
    <alias index="10" field="STATUS" name=""/>
    <alias index="11" field="DATA_DE_CONFIRMACAO" name=""/>
    <alias index="12" field="SATELITES" name=""/>
    <alias index="13" field="PDOP" name=""/>
    <alias index="14" field="LATITUDE" name=""/>
    <alias index="15" field="LONGITUDE" name=""/>
    <alias index="16" field="VALIDACAO_CEP" name=""/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" field="COD_SETOR" expression=""/>
    <default applyOnUpdate="0" field="UV" expression=""/>
    <default applyOnUpdate="0" field="ENDERECO" expression=""/>
    <default applyOnUpdate="0" field="PONTO_DE_REFERENCIA" expression=""/>
    <default applyOnUpdate="0" field="QUADRA" expression=""/>
    <default applyOnUpdate="0" field="FACE" expression=""/>
    <default applyOnUpdate="0" field="CODIGO_DO_ENDERECO" expression=""/>
    <default applyOnUpdate="0" field="CODIGO_UNICO" expression=""/>
    <default applyOnUpdate="0" field="CEP" expression=""/>
    <default applyOnUpdate="0" field="LOCALIDADE" expression=""/>
    <default applyOnUpdate="0" field="STATUS" expression=""/>
    <default applyOnUpdate="0" field="DATA_DE_CONFIRMACAO" expression=""/>
    <default applyOnUpdate="0" field="SATELITES" expression=""/>
    <default applyOnUpdate="0" field="PDOP" expression=""/>
    <default applyOnUpdate="0" field="LATITUDE" expression=""/>
    <default applyOnUpdate="0" field="LONGITUDE" expression=""/>
    <default applyOnUpdate="0" field="VALIDACAO_CEP" expression=""/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="COD_SETOR" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="UV" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="ENDERECO" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="PONTO_DE_REFERENCIA" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="QUADRA" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="FACE" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="CODIGO_DO_ENDERECO" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="CODIGO_UNICO" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="CEP" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="LOCALIDADE" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="STATUS" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="DATA_DE_CONFIRMACAO" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="SATELITES" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="PDOP" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="LATITUDE" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="LONGITUDE" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="VALIDACAO_CEP" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="COD_SETOR" desc="" exp=""/>
    <constraint field="UV" desc="" exp=""/>
    <constraint field="ENDERECO" desc="" exp=""/>
    <constraint field="PONTO_DE_REFERENCIA" desc="" exp=""/>
    <constraint field="QUADRA" desc="" exp=""/>
    <constraint field="FACE" desc="" exp=""/>
    <constraint field="CODIGO_DO_ENDERECO" desc="" exp=""/>
    <constraint field="CODIGO_UNICO" desc="" exp=""/>
    <constraint field="CEP" desc="" exp=""/>
    <constraint field="LOCALIDADE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="DATA_DE_CONFIRMACAO" desc="" exp=""/>
    <constraint field="SATELITES" desc="" exp=""/>
    <constraint field="PDOP" desc="" exp=""/>
    <constraint field="LATITUDE" desc="" exp=""/>
    <constraint field="LONGITUDE" desc="" exp=""/>
    <constraint field="VALIDACAO_CEP" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" actionWidgetStyle="dropDown" sortExpression="">
    <columns>
      <column width="-1" hidden="0" type="field" name="CEP"/>
      <column width="-1" hidden="0" type="field" name="LATITUDE"/>
      <column width="-1" hidden="0" type="field" name="LONGITUDE"/>
      <column width="-1" hidden="0" type="field" name="UV"/>
      <column width="-1" hidden="0" type="field" name="ENDERECO"/>
      <column width="-1" hidden="0" type="field" name="PONTO_DE_REFERENCIA"/>
      <column width="-1" hidden="0" type="field" name="QUADRA"/>
      <column width="-1" hidden="0" type="field" name="FACE"/>
      <column width="-1" hidden="0" type="field" name="CODIGO_DO_ENDERECO"/>
      <column width="-1" hidden="0" type="field" name="LOCALIDADE"/>
      <column width="-1" hidden="0" type="field" name="STATUS"/>
      <column width="-1" hidden="0" type="field" name="DATA_DE_CONFIRMACAO"/>
      <column width="-1" hidden="0" type="field" name="SATELITES"/>
      <column width="-1" hidden="0" type="field" name="PDOP"/>
      <column width="-1" hidden="0" type="field" name="COD_SETOR"/>
      <column width="-1" hidden="0" type="field" name="CODIGO_UNICO"/>
      <column width="-1" hidden="0" type="field" name="VALIDACAO_CEP"/>
      <column width="-1" hidden="1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="CEP"/>
    <field editable="1" name="CODIGO_DO_ENDERECO"/>
    <field editable="1" name="CODIGO_UNICO"/>
    <field editable="1" name="COD_DISTRITO"/>
    <field editable="1" name="COD_ESPECIE"/>
    <field editable="1" name="COD_INDICADOR_CONST_ENDERECO"/>
    <field editable="1" name="COD_INDICADOR_ESTAB_ENDERECO"/>
    <field editable="1" name="COD_INDICADOR_FINALIDADE_CONST"/>
    <field editable="1" name="COD_MUNICIPIO"/>
    <field editable="1" name="COD_SETOR"/>
    <field editable="1" name="COD_SUBDISTRITO"/>
    <field editable="1" name="COD_TIPO_ESPECI"/>
    <field editable="1" name="COD_UF"/>
    <field editable="1" name="COD_UNICO_ENDERECO"/>
    <field editable="1" name="DATA_DE_CONFIRMACAO"/>
    <field editable="1" name="DISTANCE"/>
    <field editable="1" name="DSC_ESTABELECIMENTO"/>
    <field editable="1" name="DSC_LOCALIDADE"/>
    <field editable="1" name="DSC_MODIFICADOR"/>
    <field editable="1" name="ENDERECO"/>
    <field editable="1" name="FACE"/>
    <field editable="1" name="LATITUDE"/>
    <field editable="1" name="LOCALIDADE"/>
    <field editable="1" name="LONGITUDE"/>
    <field editable="1" name="NOM_COMP_ELEM1"/>
    <field editable="1" name="NOM_COMP_ELEM2"/>
    <field editable="1" name="NOM_COMP_ELEM3"/>
    <field editable="1" name="NOM_COMP_ELEM4"/>
    <field editable="1" name="NOM_COMP_ELEM5"/>
    <field editable="1" name="NOM_SEGLOGR"/>
    <field editable="1" name="NOM_TIPO_SEGLOGR"/>
    <field editable="1" name="NOM_TITULO_SEGLOGR"/>
    <field editable="1" name="NUM_ENDERECO"/>
    <field editable="1" name="NUM_FACE"/>
    <field editable="1" name="NUM_QUADRA"/>
    <field editable="1" name="NV_GEO_COORD"/>
    <field editable="1" name="PDOP"/>
    <field editable="1" name="PONTO_DE_REFERENCIA"/>
    <field editable="1" name="QUADRA"/>
    <field editable="1" name="SATELITES"/>
    <field editable="1" name="STATUS"/>
    <field editable="1" name="UV"/>
    <field editable="1" name="VALIDACAO_CEP"/>
    <field editable="1" name="VAL_COMP_ELEM1"/>
    <field editable="1" name="VAL_COMP_ELEM2"/>
    <field editable="1" name="VAL_COMP_ELEM3"/>
    <field editable="1" name="VAL_COMP_ELEM4"/>
    <field editable="1" name="VAL_COMP_ELEM5"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="CEP"/>
    <field labelOnTop="0" name="CODIGO_DO_ENDERECO"/>
    <field labelOnTop="0" name="CODIGO_UNICO"/>
    <field labelOnTop="0" name="COD_DISTRITO"/>
    <field labelOnTop="0" name="COD_ESPECIE"/>
    <field labelOnTop="0" name="COD_INDICADOR_CONST_ENDERECO"/>
    <field labelOnTop="0" name="COD_INDICADOR_ESTAB_ENDERECO"/>
    <field labelOnTop="0" name="COD_INDICADOR_FINALIDADE_CONST"/>
    <field labelOnTop="0" name="COD_MUNICIPIO"/>
    <field labelOnTop="0" name="COD_SETOR"/>
    <field labelOnTop="0" name="COD_SUBDISTRITO"/>
    <field labelOnTop="0" name="COD_TIPO_ESPECI"/>
    <field labelOnTop="0" name="COD_UF"/>
    <field labelOnTop="0" name="COD_UNICO_ENDERECO"/>
    <field labelOnTop="0" name="DATA_DE_CONFIRMACAO"/>
    <field labelOnTop="0" name="DISTANCE"/>
    <field labelOnTop="0" name="DSC_ESTABELECIMENTO"/>
    <field labelOnTop="0" name="DSC_LOCALIDADE"/>
    <field labelOnTop="0" name="DSC_MODIFICADOR"/>
    <field labelOnTop="0" name="ENDERECO"/>
    <field labelOnTop="0" name="FACE"/>
    <field labelOnTop="0" name="LATITUDE"/>
    <field labelOnTop="0" name="LOCALIDADE"/>
    <field labelOnTop="0" name="LONGITUDE"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM1"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM2"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM3"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM4"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM5"/>
    <field labelOnTop="0" name="NOM_SEGLOGR"/>
    <field labelOnTop="0" name="NOM_TIPO_SEGLOGR"/>
    <field labelOnTop="0" name="NOM_TITULO_SEGLOGR"/>
    <field labelOnTop="0" name="NUM_ENDERECO"/>
    <field labelOnTop="0" name="NUM_FACE"/>
    <field labelOnTop="0" name="NUM_QUADRA"/>
    <field labelOnTop="0" name="NV_GEO_COORD"/>
    <field labelOnTop="0" name="PDOP"/>
    <field labelOnTop="0" name="PONTO_DE_REFERENCIA"/>
    <field labelOnTop="0" name="QUADRA"/>
    <field labelOnTop="0" name="SATELITES"/>
    <field labelOnTop="0" name="STATUS"/>
    <field labelOnTop="0" name="UV"/>
    <field labelOnTop="0" name="VALIDACAO_CEP"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM1"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM2"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM3"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM4"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM5"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="CEP"/>
    <field reuseLastValue="0" name="CODIGO_DO_ENDERECO"/>
    <field reuseLastValue="0" name="CODIGO_UNICO"/>
    <field reuseLastValue="0" name="COD_DISTRITO"/>
    <field reuseLastValue="0" name="COD_ESPECIE"/>
    <field reuseLastValue="0" name="COD_INDICADOR_CONST_ENDERECO"/>
    <field reuseLastValue="0" name="COD_INDICADOR_ESTAB_ENDERECO"/>
    <field reuseLastValue="0" name="COD_INDICADOR_FINALIDADE_CONST"/>
    <field reuseLastValue="0" name="COD_MUNICIPIO"/>
    <field reuseLastValue="0" name="COD_SETOR"/>
    <field reuseLastValue="0" name="COD_SUBDISTRITO"/>
    <field reuseLastValue="0" name="COD_TIPO_ESPECI"/>
    <field reuseLastValue="0" name="COD_UF"/>
    <field reuseLastValue="0" name="COD_UNICO_ENDERECO"/>
    <field reuseLastValue="0" name="DATA_DE_CONFIRMACAO"/>
    <field reuseLastValue="0" name="DISTANCE"/>
    <field reuseLastValue="0" name="DSC_ESTABELECIMENTO"/>
    <field reuseLastValue="0" name="DSC_LOCALIDADE"/>
    <field reuseLastValue="0" name="DSC_MODIFICADOR"/>
    <field reuseLastValue="0" name="ENDERECO"/>
    <field reuseLastValue="0" name="FACE"/>
    <field reuseLastValue="0" name="LATITUDE"/>
    <field reuseLastValue="0" name="LOCALIDADE"/>
    <field reuseLastValue="0" name="LONGITUDE"/>
    <field reuseLastValue="0" name="NOM_COMP_ELEM1"/>
    <field reuseLastValue="0" name="NOM_COMP_ELEM2"/>
    <field reuseLastValue="0" name="NOM_COMP_ELEM3"/>
    <field reuseLastValue="0" name="NOM_COMP_ELEM4"/>
    <field reuseLastValue="0" name="NOM_COMP_ELEM5"/>
    <field reuseLastValue="0" name="NOM_SEGLOGR"/>
    <field reuseLastValue="0" name="NOM_TIPO_SEGLOGR"/>
    <field reuseLastValue="0" name="NOM_TITULO_SEGLOGR"/>
    <field reuseLastValue="0" name="NUM_ENDERECO"/>
    <field reuseLastValue="0" name="NUM_FACE"/>
    <field reuseLastValue="0" name="NUM_QUADRA"/>
    <field reuseLastValue="0" name="NV_GEO_COORD"/>
    <field reuseLastValue="0" name="PDOP"/>
    <field reuseLastValue="0" name="PONTO_DE_REFERENCIA"/>
    <field reuseLastValue="0" name="QUADRA"/>
    <field reuseLastValue="0" name="SATELITES"/>
    <field reuseLastValue="0" name="STATUS"/>
    <field reuseLastValue="0" name="UV"/>
    <field reuseLastValue="0" name="VALIDACAO_CEP"/>
    <field reuseLastValue="0" name="VAL_COMP_ELEM1"/>
    <field reuseLastValue="0" name="VAL_COMP_ELEM2"/>
    <field reuseLastValue="0" name="VAL_COMP_ELEM3"/>
    <field reuseLastValue="0" name="VAL_COMP_ELEM4"/>
    <field reuseLastValue="0" name="VAL_COMP_ELEM5"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"NOM_TIPO_SEGLOGR"</previewExpression>
  <mapTip>&lt;!DOCTYPE html>&#xd;
	&lt;html>&#xd;
		&lt;head>&#xd;
			&lt;meta http-equiv="content-type" content="text/html; charset=UTF-8">&#xd;
			&lt;style>&#xd;
				table.grey{&#xd;
					border-style: none;&#xd;
					width: auto;&#xd;
					padding: 15px;&#xd;
					border-collapse: collapse;&#xd;
					border-left: 0;&#xd;
					border-right: 0;&#xd;
					border-radius: 10px;&#xd;
					border-spacing: 0px;&#xd;
					overflow:hidden; /* hide overflowing cells */&#xd;
				}&#xd;
			&lt;/style>					&#xd;
		&lt;/head>&#xd;
		&lt;body>&#xd;
			&lt;table  class="grey">&#xd;
				&lt;tbody>                           &#xd;
					&lt;tr style="height: 18px; width: auto;">&#xd;
						&lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">Atributo&lt;/span>&lt;/td>&#xd;
						&lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">valor&lt;/span>&lt;/td>&#xd;
					&lt;/tr>&#xd;
					&lt;tr style="font-size: 12px; width: auto;">&#xd;
						&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">SETOR&lt;/span>&lt;/td>&#xd;
						&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">260795005000004&lt;/span>&lt;/strong>&lt;/td>&#xd;
					&lt;/tr>                             &#xd;
					&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
						&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">UV&lt;/span>&lt;/td>&#xd;
						&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%UV%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
					&lt;/tr>&#xd;
					&lt;tr style="font-size: 12px; width: auto;">&#xd;
						&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">ENDEREÇO&lt;/span>&lt;/td>&#xd;
						&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%ENDERECO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
					&lt;/tr>&#xd;
					&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
						&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">PONTO DE REFERÊNCIA&lt;/span>&lt;/td>&#xd;
						&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%PONTO_DE_REFERENCIA%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
					&lt;/tr>&#xd;
					&#xd;
					&lt;tr style="font-size: 12px; width: auto;">&#xd;
						&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">QUADRA&lt;/span>&lt;/td>&#xd;
						&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%QUADRA%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
					&lt;/tr>&#xd;
					&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
						&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">FACE&lt;/span>&lt;/td>&#xd;
						&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%FACE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
					&lt;/tr>&#xd;
					&lt;tr style="font-size: 12px; width: auto;">&#xd;
						&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CÓDIGO DO ENDEREÇO&lt;/span>&lt;/td>&#xd;
						&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%CODIGO_DO_ENDERECO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
					&lt;/tr>&#xd;
					&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
						&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CEP&lt;/span>&lt;/td>&#xd;
						&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%CEP%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
					&lt;/tr>&#xd;
					&lt;tr style="font-size: 12px; width: auto;">&#xd;
						&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">LOCALIDADE&lt;/span>&lt;/td>&#xd;
						&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%LOCALIDADE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
					&lt;/tr>&#xd;
					&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
						&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">STATUS&lt;/span>&lt;/td>&#xd;
						&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%STATUS%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
					&lt;/tr>&#xd;
					&lt;tr style="font-size: 12px; width: auto;">&#xd;
						&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;"> DATA DE CONFIRMAÇÃO&lt;/span>&lt;/td>&#xd;
						&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[% DATA_DE_CONFIRMACAO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
					&lt;/tr>												&#xd;
				&lt;/tbody>&#xd;
			&lt;/table>	&#xd;
		&lt;/body>&#xd;
	&lt;/html>&#xd;
</mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
