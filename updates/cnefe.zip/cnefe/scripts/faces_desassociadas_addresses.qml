<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="1" readOnly="0" maxScale="0" simplifyMaxScale="1" minScale="100000000" simplifyLocal="1" simplifyAlgorithm="0" version="3.28.6-Firenze" hasScaleBasedVisibilityFlag="0" simplifyDrawingHints="0" simplifyDrawingTol="1" styleCategories="AllStyleCategories" symbologyReferenceScale="-1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal accumulate="0" enabled="0" limitMode="0" durationField="" endField="" startExpression="" mode="0" startField="" durationUnit="min" fixedDuration="0" endExpression="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation clamping="Terrain" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" extrusion="0" type="IndividualFeatures" zoffset="0" binding="Centroid" extrusionEnabled="0" zscale="1" symbology="Line">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol is_animated="0" type="line" name="" clip_to_extent="1" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SimpleLine">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="183,72,75,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol is_animated="0" type="fill" name="" clip_to_extent="1" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="183,72,75,255" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="131,51,54,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol is_animated="0" type="marker" name="" clip_to_extent="1" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="183,72,75,255" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="diamond" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="131,51,54,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="3" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 referencescale="-1" type="singleSymbol" symbollevels="0" forceraster="0" enableorderby="0">
    <symbols>
      <symbol is_animated="0" type="marker" name="0" clip_to_extent="1" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="0,255,0,255" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="circle" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0,0,0,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="area" type="QString" name="scale_method"/>
            <Option value="4" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer pass="0" enabled="1" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="227,26,28,255" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="circle" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="227,26,28,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.4" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="area" type="QString" name="scale_method"/>
            <Option value="0.875" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontItalic="0" textOrientation="horizontal" isExpression="1" fontLetterSpacing="0" forcedBold="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="Point" fontUnderline="0" fontWeight="50" fontWordSpacing="0" fontKerning="1" useSubstitutions="0" previewBkgrdColor="255,255,255,255" textOpacity="1" legendString="Aa" blendMode="0" allowHtml="0" fontSize="12" multilineHeight="1" namedStyle="Normal" multilineHeightUnit="Percentage" fontStrikeout="0" fieldName="CODIGO_DO_ENDERECO" fontFamily="Arial Black" capitalization="0" textColor="0,0,255,255" forcedItalic="0">
        <families/>
        <text-buffer bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="0" bufferSizeUnits="MM" bufferOpacity="1" bufferJoinStyle="128" bufferBlendMode="0" bufferSize="1.2" bufferColor="250,250,250,255" bufferDraw="1"/>
        <text-mask maskedSymbolLayers="" maskEnabled="1" maskSize="4.5" maskJoinStyle="128" maskSizeUnits="MM" maskOpacity="1" maskType="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
        <background shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeFillColor="255,255,255,255" shapeJoinStyle="64" shapeType="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeY="0" shapeOffsetUnit="Point" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeDraw="0" shapeSizeType="0" shapeRadiiY="0" shapeOffsetY="0" shapeRotationType="0" shapeOffsetX="0" shapeSVGFile="" shapeBorderColor="128,128,128,255" shapeRadiiX="0" shapeRotation="0" shapeRadiiUnit="Point" shapeSizeUnit="Point" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeBorderWidthUnit="Point" shapeOpacity="1" shapeBlendMode="0">
          <symbol is_animated="0" type="marker" name="markerSymbol" clip_to_extent="1" force_rhr="0" alpha="1" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" enabled="1" locked="0" class="SimpleMarker">
              <Option type="Map">
                <Option value="0" type="QString" name="angle"/>
                <Option value="square" type="QString" name="cap_style"/>
                <Option value="255,158,23,255" type="QString" name="color"/>
                <Option value="1" type="QString" name="horizontal_anchor_point"/>
                <Option value="bevel" type="QString" name="joinstyle"/>
                <Option value="circle" type="QString" name="name"/>
                <Option value="0,0" type="QString" name="offset"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
                <Option value="MM" type="QString" name="offset_unit"/>
                <Option value="35,35,35,255" type="QString" name="outline_color"/>
                <Option value="solid" type="QString" name="outline_style"/>
                <Option value="0" type="QString" name="outline_width"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
                <Option value="MM" type="QString" name="outline_width_unit"/>
                <Option value="diameter" type="QString" name="scale_method"/>
                <Option value="2" type="QString" name="size"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
                <Option value="MM" type="QString" name="size_unit"/>
                <Option value="1" type="QString" name="vertical_anchor_point"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" type="QString" name="name"/>
                  <Option name="properties"/>
                  <Option value="collection" type="QString" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol is_animated="0" type="fill" name="fillSymbol" clip_to_extent="1" force_rhr="0" alpha="1" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" enabled="1" locked="0" class="SimpleFill">
              <Option type="Map">
                <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
                <Option value="255,255,255,255" type="QString" name="color"/>
                <Option value="bevel" type="QString" name="joinstyle"/>
                <Option value="0,0" type="QString" name="offset"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
                <Option value="MM" type="QString" name="offset_unit"/>
                <Option value="128,128,128,255" type="QString" name="outline_color"/>
                <Option value="no" type="QString" name="outline_style"/>
                <Option value="0" type="QString" name="outline_width"/>
                <Option value="Point" type="QString" name="outline_width_unit"/>
                <Option value="solid" type="QString" name="style"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" type="QString" name="name"/>
                  <Option name="properties"/>
                  <Option value="collection" type="QString" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowOffsetUnit="MM" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetAngle="135" shadowRadius="1.5" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowScale="100" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowBlendMode="6"/>
        <dd_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format formatNumbers="0" plussign="0" decimals="3" rightDirectionSymbol=">" leftDirectionSymbol="&lt;" addDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" reverseDirectionSymbol="0" placeDirectionSymbol="0" autoWrapLength="0" wrapChar="" multilineAlign="3"/>
      <placement repeatDistance="0" lineAnchorClipping="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" lineAnchorType="0" offsetUnits="MM" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" maxCurvedCharAngleIn="25" offsetType="1" placementFlags="10" placement="6" distMapUnitScale="3x:0,0,0,0,0,0" priority="5" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overlapHandling="PreventOverlap" fitInPolygonOnly="0" yOffset="0" preserveRotation="1" centroidWhole="0" polygonPlacementFlags="2" overrunDistance="0" lineAnchorTextPoint="FollowPlacement" overrunDistanceUnit="MM" distUnits="MM" geometryGeneratorEnabled="0" centroidInside="0" rotationAngle="0" layerType="PointGeometry" xOffset="0" rotationUnit="AngleDegrees" quadOffset="4" repeatDistanceUnits="MM" allowDegraded="0" dist="0" geometryGenerator="" maxCurvedCharAngleOut="-25" lineAnchorPercent="0.5"/>
      <rendering obstacleType="1" scaleMin="0" fontLimitPixelSize="0" fontMaxPixelSize="10000" obstacle="1" unplacedVisibility="0" upsidedownLabels="0" drawLabels="1" labelPerPart="0" fontMinPixelSize="3" mergeLines="0" minFeatureSize="0" scaleVisibility="0" zIndex="0" obstacleFactor="1" limitNumLabels="0" maxNumLabels="2000" scaleMax="0"/>
      <dd_properties>
        <Option type="Map">
          <Option value="" type="QString" name="name"/>
          <Option name="properties"/>
          <Option value="collection" type="QString" name="type"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option value="pole_of_inaccessibility" type="QString" name="anchorPoint"/>
          <Option value="0" type="int" name="blendMode"/>
          <Option type="Map" name="ddProperties">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
          <Option value="false" type="bool" name="drawToAllParts"/>
          <Option value="0" type="QString" name="enabled"/>
          <Option value="point_on_exterior" type="QString" name="labelAnchorPoint"/>
          <Option value="&lt;symbol is_animated=&quot;0&quot; type=&quot;line&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; alpha=&quot;1&quot; frame_rate=&quot;10&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; type=&quot;QString&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; type=&quot;QString&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot; class=&quot;SimpleLine&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option value=&quot;square&quot; type=&quot;QString&quot; name=&quot;capstyle&quot;/>&lt;Option value=&quot;5;2&quot; type=&quot;QString&quot; name=&quot;customdash&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;customdash_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option value=&quot;bevel&quot; type=&quot;QString&quot; name=&quot;joinstyle&quot;/>&lt;Option value=&quot;60,60,60,255&quot; type=&quot;QString&quot; name=&quot;line_color&quot;/>&lt;Option value=&quot;solid&quot; type=&quot;QString&quot; name=&quot;line_style&quot;/>&lt;Option value=&quot;0.3&quot; type=&quot;QString&quot; name=&quot;line_width&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;line_width_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;offset&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;offset_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;ring_filter&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;trim_distance_end&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;trim_distance_start&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;use_custom_dash&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; type=&quot;QString&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; type=&quot;QString&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString" name="lineSymbol"/>
          <Option value="0" type="double" name="minLength"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="minLengthMapUnitScale"/>
          <Option value="MM" type="QString" name="minLengthUnit"/>
          <Option value="0" type="double" name="offsetFromAnchor"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="offsetFromAnchorMapUnitScale"/>
          <Option value="MM" type="QString" name="offsetFromAnchorUnit"/>
          <Option value="0" type="double" name="offsetFromLabel"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="offsetFromLabelMapUnitScale"/>
          <Option value="MM" type="QString" name="offsetFromLabelUnit"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option value="true" type="bool" name="OnConvertFormatRegeneratePrimaryKey"/>
      <Option type="List" name="dualview/previewExpressions">
        <Option value="&quot;NOM_TIPO_SEGLOGR&quot;" type="QString"/>
      </Option>
      <Option value="0" type="int" name="embeddedWidgets/count"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory enabled="0" sizeType="MM" height="15" width="15" diagramOrientation="Up" spacingUnit="MM" maxScaleDenominator="1e+08" backgroundColor="#ffffff" penWidth="0" labelPlacementMethod="XHeight" penColor="#000000" minScaleDenominator="0" minimumSize="0" opacity="1" barWidth="5" showAxis="1" scaleBasedVisibility="0" spacingUnitScale="3x:0,0,0,0,0,0" direction="0" sizeScale="3x:0,0,0,0,0,0" lineSizeScale="3x:0,0,0,0,0,0" rotationOffset="270" spacing="5" penAlpha="255" backgroundAlpha="255" scaleDependency="Area" lineSizeType="MM">
      <fontProperties italic="0" underline="0" bold="0" strikethrough="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style=""/>
      <attribute field="" label="" colorOpacity="1" color="#000000"/>
      <axisSymbol>
        <symbol is_animated="0" type="line" name="" clip_to_extent="1" force_rhr="0" alpha="1" frame_rate="10">
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
          <layer pass="0" enabled="1" locked="0" class="SimpleLine">
            <Option type="Map">
              <Option value="0" type="QString" name="align_dash_pattern"/>
              <Option value="square" type="QString" name="capstyle"/>
              <Option value="5;2" type="QString" name="customdash"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
              <Option value="MM" type="QString" name="customdash_unit"/>
              <Option value="0" type="QString" name="dash_pattern_offset"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
              <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
              <Option value="0" type="QString" name="draw_inside_polygon"/>
              <Option value="bevel" type="QString" name="joinstyle"/>
              <Option value="35,35,35,255" type="QString" name="line_color"/>
              <Option value="solid" type="QString" name="line_style"/>
              <Option value="0.26" type="QString" name="line_width"/>
              <Option value="MM" type="QString" name="line_width_unit"/>
              <Option value="0" type="QString" name="offset"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
              <Option value="MM" type="QString" name="offset_unit"/>
              <Option value="0" type="QString" name="ring_filter"/>
              <Option value="0" type="QString" name="trim_distance_end"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
              <Option value="MM" type="QString" name="trim_distance_end_unit"/>
              <Option value="0" type="QString" name="trim_distance_start"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
              <Option value="MM" type="QString" name="trim_distance_start_unit"/>
              <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
              <Option value="0" type="QString" name="use_custom_dash"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings showAll="1" linePlacementFlags="18" priority="0" obstacle="0" zIndex="0" dist="0" placement="0">
    <properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="COD_UNICO_END" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_SETOR" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NUM_QUADRA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NUM_FACE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="VAL_LATITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="VAL_LONGITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="COD_UNICO_END" index="0" name=""/>
    <alias field="COD_SETOR" index="1" name=""/>
    <alias field="NUM_QUADRA" index="2" name=""/>
    <alias field="NUM_FACE" index="3" name=""/>
    <alias field="VAL_LATITUDE" index="4" name=""/>
    <alias field="VAL_LONGITUDE" index="5" name=""/>
  </aliases>
  <defaults>
    <default field="COD_UNICO_END" expression="" applyOnUpdate="0"/>
    <default field="COD_SETOR" expression="" applyOnUpdate="0"/>
    <default field="NUM_QUADRA" expression="" applyOnUpdate="0"/>
    <default field="NUM_FACE" expression="" applyOnUpdate="0"/>
    <default field="VAL_LATITUDE" expression="" applyOnUpdate="0"/>
    <default field="VAL_LONGITUDE" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="COD_UNICO_END" unique_strength="0" constraints="0" notnull_strength="0" exp_strength="0"/>
    <constraint field="COD_SETOR" unique_strength="0" constraints="0" notnull_strength="0" exp_strength="0"/>
    <constraint field="NUM_QUADRA" unique_strength="0" constraints="0" notnull_strength="0" exp_strength="0"/>
    <constraint field="NUM_FACE" unique_strength="0" constraints="0" notnull_strength="0" exp_strength="0"/>
    <constraint field="VAL_LATITUDE" unique_strength="0" constraints="0" notnull_strength="0" exp_strength="0"/>
    <constraint field="VAL_LONGITUDE" unique_strength="0" constraints="0" notnull_strength="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="COD_UNICO_END" desc="" exp=""/>
    <constraint field="COD_SETOR" desc="" exp=""/>
    <constraint field="NUM_QUADRA" desc="" exp=""/>
    <constraint field="NUM_FACE" desc="" exp=""/>
    <constraint field="VAL_LATITUDE" desc="" exp=""/>
    <constraint field="VAL_LONGITUDE" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="">
    <columns>
      <column type="field" name="COD_UNICO_END" hidden="0" width="-1"/>
      <column type="field" name="COD_SETOR" hidden="0" width="-1"/>
      <column type="field" name="NUM_QUADRA" hidden="0" width="-1"/>
      <column type="field" name="NUM_FACE" hidden="0" width="-1"/>
      <column type="field" name="VAL_LATITUDE" hidden="0" width="-1"/>
      <column type="field" name="VAL_LONGITUDE" hidden="0" width="-1"/>
      <column type="actions" hidden="1" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="CEP" editable="1"/>
    <field name="CODIGO_DO_ENDERECO" editable="1"/>
    <field name="COD_DISTRITO" editable="1"/>
    <field name="COD_ESPECIE" editable="1"/>
    <field name="COD_INDICADOR_CONST_ENDERECO" editable="1"/>
    <field name="COD_INDICADOR_ESTAB_ENDERECO" editable="1"/>
    <field name="COD_INDICADOR_FINALIDADE_CONST" editable="1"/>
    <field name="COD_MUNICIPIO" editable="1"/>
    <field name="COD_SETOR" editable="1"/>
    <field name="COD_SUBDISTRITO" editable="1"/>
    <field name="COD_TIPO_ESPECI" editable="1"/>
    <field name="COD_UF" editable="1"/>
    <field name="COD_UNICO_END" editable="1"/>
    <field name="COD_UNICO_ENDERECO" editable="1"/>
    <field name="DATA_DE_CONFIRMACAO" editable="1"/>
    <field name="DISTANCE" editable="1"/>
    <field name="DSC_ESTABELECIMENTO" editable="1"/>
    <field name="DSC_LOCALIDADE" editable="1"/>
    <field name="DSC_MODIFICADOR" editable="1"/>
    <field name="ENDERECO" editable="1"/>
    <field name="FACE" editable="1"/>
    <field name="LATITUDE" editable="1"/>
    <field name="LOCALIDADE" editable="1"/>
    <field name="LONGITUDE" editable="1"/>
    <field name="NOM_COMP_ELEM1" editable="1"/>
    <field name="NOM_COMP_ELEM2" editable="1"/>
    <field name="NOM_COMP_ELEM3" editable="1"/>
    <field name="NOM_COMP_ELEM4" editable="1"/>
    <field name="NOM_COMP_ELEM5" editable="1"/>
    <field name="NOM_SEGLOGR" editable="1"/>
    <field name="NOM_TIPO_SEGLOGR" editable="1"/>
    <field name="NOM_TITULO_SEGLOGR" editable="1"/>
    <field name="NUM_ENDERECO" editable="1"/>
    <field name="NUM_FACE" editable="1"/>
    <field name="NUM_QUADRA" editable="1"/>
    <field name="NV_GEO_COORD" editable="1"/>
    <field name="PDOP" editable="1"/>
    <field name="PONTO_DE_REFERENCIA" editable="1"/>
    <field name="QUADRA" editable="1"/>
    <field name="SATELITES" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="UV" editable="1"/>
    <field name="VAL_COMP_ELEM1" editable="1"/>
    <field name="VAL_COMP_ELEM2" editable="1"/>
    <field name="VAL_COMP_ELEM3" editable="1"/>
    <field name="VAL_COMP_ELEM4" editable="1"/>
    <field name="VAL_COMP_ELEM5" editable="1"/>
    <field name="VAL_LATITUDE" editable="1"/>
    <field name="VAL_LONGITUDE" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="CEP" labelOnTop="0"/>
    <field name="CODIGO_DO_ENDERECO" labelOnTop="0"/>
    <field name="COD_DISTRITO" labelOnTop="0"/>
    <field name="COD_ESPECIE" labelOnTop="0"/>
    <field name="COD_INDICADOR_CONST_ENDERECO" labelOnTop="0"/>
    <field name="COD_INDICADOR_ESTAB_ENDERECO" labelOnTop="0"/>
    <field name="COD_INDICADOR_FINALIDADE_CONST" labelOnTop="0"/>
    <field name="COD_MUNICIPIO" labelOnTop="0"/>
    <field name="COD_SETOR" labelOnTop="0"/>
    <field name="COD_SUBDISTRITO" labelOnTop="0"/>
    <field name="COD_TIPO_ESPECI" labelOnTop="0"/>
    <field name="COD_UF" labelOnTop="0"/>
    <field name="COD_UNICO_END" labelOnTop="0"/>
    <field name="COD_UNICO_ENDERECO" labelOnTop="0"/>
    <field name="DATA_DE_CONFIRMACAO" labelOnTop="0"/>
    <field name="DISTANCE" labelOnTop="0"/>
    <field name="DSC_ESTABELECIMENTO" labelOnTop="0"/>
    <field name="DSC_LOCALIDADE" labelOnTop="0"/>
    <field name="DSC_MODIFICADOR" labelOnTop="0"/>
    <field name="ENDERECO" labelOnTop="0"/>
    <field name="FACE" labelOnTop="0"/>
    <field name="LATITUDE" labelOnTop="0"/>
    <field name="LOCALIDADE" labelOnTop="0"/>
    <field name="LONGITUDE" labelOnTop="0"/>
    <field name="NOM_COMP_ELEM1" labelOnTop="0"/>
    <field name="NOM_COMP_ELEM2" labelOnTop="0"/>
    <field name="NOM_COMP_ELEM3" labelOnTop="0"/>
    <field name="NOM_COMP_ELEM4" labelOnTop="0"/>
    <field name="NOM_COMP_ELEM5" labelOnTop="0"/>
    <field name="NOM_SEGLOGR" labelOnTop="0"/>
    <field name="NOM_TIPO_SEGLOGR" labelOnTop="0"/>
    <field name="NOM_TITULO_SEGLOGR" labelOnTop="0"/>
    <field name="NUM_ENDERECO" labelOnTop="0"/>
    <field name="NUM_FACE" labelOnTop="0"/>
    <field name="NUM_QUADRA" labelOnTop="0"/>
    <field name="NV_GEO_COORD" labelOnTop="0"/>
    <field name="PDOP" labelOnTop="0"/>
    <field name="PONTO_DE_REFERENCIA" labelOnTop="0"/>
    <field name="QUADRA" labelOnTop="0"/>
    <field name="SATELITES" labelOnTop="0"/>
    <field name="STATUS" labelOnTop="0"/>
    <field name="UV" labelOnTop="0"/>
    <field name="VAL_COMP_ELEM1" labelOnTop="0"/>
    <field name="VAL_COMP_ELEM2" labelOnTop="0"/>
    <field name="VAL_COMP_ELEM3" labelOnTop="0"/>
    <field name="VAL_COMP_ELEM4" labelOnTop="0"/>
    <field name="VAL_COMP_ELEM5" labelOnTop="0"/>
    <field name="VAL_LATITUDE" labelOnTop="0"/>
    <field name="VAL_LONGITUDE" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CEP" reuseLastValue="0"/>
    <field name="CODIGO_DO_ENDERECO" reuseLastValue="0"/>
    <field name="COD_DISTRITO" reuseLastValue="0"/>
    <field name="COD_ESPECIE" reuseLastValue="0"/>
    <field name="COD_INDICADOR_CONST_ENDERECO" reuseLastValue="0"/>
    <field name="COD_INDICADOR_ESTAB_ENDERECO" reuseLastValue="0"/>
    <field name="COD_INDICADOR_FINALIDADE_CONST" reuseLastValue="0"/>
    <field name="COD_MUNICIPIO" reuseLastValue="0"/>
    <field name="COD_SETOR" reuseLastValue="0"/>
    <field name="COD_SUBDISTRITO" reuseLastValue="0"/>
    <field name="COD_TIPO_ESPECI" reuseLastValue="0"/>
    <field name="COD_UF" reuseLastValue="0"/>
    <field name="COD_UNICO_END" reuseLastValue="0"/>
    <field name="COD_UNICO_ENDERECO" reuseLastValue="0"/>
    <field name="DATA_DE_CONFIRMACAO" reuseLastValue="0"/>
    <field name="DISTANCE" reuseLastValue="0"/>
    <field name="DSC_ESTABELECIMENTO" reuseLastValue="0"/>
    <field name="DSC_LOCALIDADE" reuseLastValue="0"/>
    <field name="DSC_MODIFICADOR" reuseLastValue="0"/>
    <field name="ENDERECO" reuseLastValue="0"/>
    <field name="FACE" reuseLastValue="0"/>
    <field name="LATITUDE" reuseLastValue="0"/>
    <field name="LOCALIDADE" reuseLastValue="0"/>
    <field name="LONGITUDE" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM1" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM2" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM3" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM4" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM5" reuseLastValue="0"/>
    <field name="NOM_SEGLOGR" reuseLastValue="0"/>
    <field name="NOM_TIPO_SEGLOGR" reuseLastValue="0"/>
    <field name="NOM_TITULO_SEGLOGR" reuseLastValue="0"/>
    <field name="NUM_ENDERECO" reuseLastValue="0"/>
    <field name="NUM_FACE" reuseLastValue="0"/>
    <field name="NUM_QUADRA" reuseLastValue="0"/>
    <field name="NV_GEO_COORD" reuseLastValue="0"/>
    <field name="PDOP" reuseLastValue="0"/>
    <field name="PONTO_DE_REFERENCIA" reuseLastValue="0"/>
    <field name="QUADRA" reuseLastValue="0"/>
    <field name="SATELITES" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="UV" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM1" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM2" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM3" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM4" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM5" reuseLastValue="0"/>
    <field name="VAL_LATITUDE" reuseLastValue="0"/>
    <field name="VAL_LONGITUDE" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"NOM_TIPO_SEGLOGR"</previewExpression>
  <mapTip>&lt;!DOCTYPE html>
                            &lt;html>
                              &lt;head>
                                &lt;meta http-equiv="content-type" content="text/html; charset=UTF-8">
                                &lt;style>
                                    table.grey{
                                        border-style: none;
                                        width: auto;
                                        padding: 15px;
                                        border-collapse: collapse;
                                        border-left: 0;
                                        border-right: 0;
                                        border-radius: 10px;
                                        border-spacing: 0px;
                                        overflow:hidden; /* hide overflowing cells */
                                    }
                                &lt;/style>					
                              &lt;/head>
                              &lt;body>
                                &lt;table  class="grey">
                                    &lt;tbody>                           
                                        &lt;tr style="height: 18px; width: auto;">
                                            &lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">Atributo&lt;/span>&lt;/td>
                                            &lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">valor&lt;/span>&lt;/td>
                                        &lt;/tr>
                                        &lt;tr style="font-size: 12px; width: auto;">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">SETOR&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">260795005000004&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>                             
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">QUADRA&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%NUM_QUADRA%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>
                                        &lt;tr style="font-size: 12px; width: auto;">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">FACE&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%NUM_FACE%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CÓDIGO ÚNICO&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%COD_UNICO_END%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>										
                                    &lt;/tbody>
                                &lt;/table>	
                              &lt;/body>
                            &lt;/html></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
