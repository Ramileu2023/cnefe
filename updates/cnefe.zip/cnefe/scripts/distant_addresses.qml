<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="1" version="3.28.9-Firenze" symbologyReferenceScale="-1" simplifyAlgorithm="0" hasScaleBasedVisibilityFlag="0" styleCategories="AllStyleCategories" simplifyDrawingTol="1" simplifyLocal="1" maxScale="0" simplifyDrawingHints="0" minScale="100000000" simplifyMaxScale="1" readOnly="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endField="" startExpression="" durationField="" enabled="0" accumulate="0" endExpression="" startField="" limitMode="0" fixedDuration="0" mode="0" durationUnit="min">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation binding="Centroid" zoffset="0" zscale="1" symbology="Line" type="IndividualFeatures" clamping="Terrain" extrusionEnabled="0" extrusion="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" name="" is_animated="0" type="line" frame_rate="10" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SimpleLine">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="183,72,75,255"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" name="" is_animated="0" type="fill" frame_rate="10" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="183,72,75,255"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="131,51,54,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" name="" is_animated="0" type="marker" frame_rate="10" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="183,72,75,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="131,51,54,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 symbollevels="0" referencescale="-1" type="singleSymbol" forceraster="0" enableorderby="0">
    <symbols>
      <symbol alpha="1" name="0" is_animated="0" type="marker" frame_rate="10" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="0,255,0,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="0,0,0,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="area"/>
            <Option name="size" type="QString" value="4"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer pass="0" enabled="1" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="227,26,28,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="227,26,28,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.4"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="area"/>
            <Option name="size" type="QString" value="0.875"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontStrikeout="0" capitalization="0" previewBkgrdColor="255,255,255,255" fontWordSpacing="0" textOpacity="1" fontKerning="1" isExpression="0" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontUnderline="0" fieldName="CODIGO_DO_ENDERECO" textOrientation="horizontal" fontLetterSpacing="0" fontSize="12" multilineHeight="1" multilineHeightUnit="Percentage" textColor="0,0,255,255" useSubstitutions="0" fontWeight="50" forcedItalic="0" blendMode="0" fontFamily="Arial Black" allowHtml="0" fontItalic="0" forcedBold="0" legendString="Aa" namedStyle="Normal">
        <families/>
        <text-buffer bufferNoFill="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferColor="250,250,250,255" bufferSize="1.2" bufferSizeUnits="MM" bufferOpacity="1" bufferDraw="1" bufferBlendMode="0" bufferJoinStyle="128"/>
        <text-mask maskSize="4.5" maskOpacity="1" maskEnabled="1" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskJoinStyle="128" maskedSymbolLayers="" maskType="0"/>
        <background shapeOffsetY="0" shapeRotationType="0" shapeOffsetUnit="Point" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeOffsetX="0" shapeSizeUnit="Point" shapeRadiiX="0" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="0" shapeBorderWidthUnit="Point" shapeOpacity="1" shapeType="0" shapeSizeX="0" shapeBorderColor="128,128,128,255" shapeBorderWidth="0" shapeSizeType="0" shapeSizeY="0" shapeFillColor="255,255,255,255" shapeRadiiUnit="Point" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotation="0">
          <symbol alpha="1" name="markerSymbol" is_animated="0" type="marker" frame_rate="10" clip_to_extent="1" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" enabled="1" locked="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" type="QString" value="0"/>
                <Option name="cap_style" type="QString" value="square"/>
                <Option name="color" type="QString" value="255,158,23,255"/>
                <Option name="horizontal_anchor_point" type="QString" value="1"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="name" type="QString" value="circle"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="35,35,35,255"/>
                <Option name="outline_style" type="QString" value="solid"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="outline_width_unit" type="QString" value="MM"/>
                <Option name="scale_method" type="QString" value="diameter"/>
                <Option name="size" type="QString" value="2"/>
                <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="size_unit" type="QString" value="MM"/>
                <Option name="vertical_anchor_point" type="QString" value="1"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol alpha="1" name="fillSymbol" is_animated="0" type="fill" frame_rate="10" clip_to_extent="1" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" enabled="1" locked="0" class="SimpleFill">
              <Option type="Map">
                <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="color" type="QString" value="255,255,255,255"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="128,128,128,255"/>
                <Option name="outline_style" type="QString" value="no"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_unit" type="QString" value="Point"/>
                <Option name="style" type="QString" value="solid"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowRadiusAlphaOnly="0" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowBlendMode="6" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowUnder="0" shadowRadius="1.5" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowDraw="0" shadowColor="0,0,0,255"/>
        <dd_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format autoWrapLength="0" reverseDirectionSymbol="0" plussign="0" useMaxLineLengthForAutoWrap="1" leftDirectionSymbol="&lt;" rightDirectionSymbol=">" formatNumbers="0" decimals="3" addDirectionSymbol="0" placeDirectionSymbol="0" wrapChar="" multilineAlign="3"/>
      <placement placementFlags="10" placement="6" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" overrunDistanceUnit="MM" allowDegraded="0" offsetType="1" repeatDistanceUnits="MM" centroidWhole="0" fitInPolygonOnly="0" geometryGenerator="" repeatDistance="0" lineAnchorPercent="0.5" rotationAngle="0" overlapHandling="PreventOverlap" priority="5" quadOffset="4" distMapUnitScale="3x:0,0,0,0,0,0" lineAnchorTextPoint="FollowPlacement" polygonPlacementFlags="2" dist="0" preserveRotation="1" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" geometryGeneratorType="PointGeometry" lineAnchorClipping="0" maxCurvedCharAngleOut="-25" centroidInside="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" rotationUnit="AngleDegrees" overrunDistance="0" distUnits="MM" xOffset="0" lineAnchorType="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" yOffset="0" geometryGeneratorEnabled="0"/>
      <rendering fontMinPixelSize="3" scaleMin="0" obstacle="1" drawLabels="1" obstacleFactor="1" limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" upsidedownLabels="0" unplacedVisibility="0" minFeatureSize="0" fontLimitPixelSize="0" scaleVisibility="0" zIndex="0" mergeLines="0" obstacleType="1" scaleMax="0" maxNumLabels="2000"/>
      <dd_properties>
        <Option type="Map">
          <Option name="name" type="QString" value=""/>
          <Option name="properties"/>
          <Option name="type" type="QString" value="collection"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
          <Option name="blendMode" type="int" value="0"/>
          <Option name="ddProperties" type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
          <Option name="drawToAllParts" type="bool" value="false"/>
          <Option name="enabled" type="QString" value="0"/>
          <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
          <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; frame_rate=&quot;10&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot; class=&quot;SimpleLine&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
          <Option name="minLength" type="double" value="0"/>
          <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="minLengthUnit" type="QString" value="MM"/>
          <Option name="offsetFromAnchor" type="double" value="0"/>
          <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
          <Option name="offsetFromLabel" type="double" value="0"/>
          <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option name="OnConvertFormatRegeneratePrimaryKey" type="bool" value="true"/>
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory spacingUnitScale="3x:0,0,0,0,0,0" sizeType="MM" spacing="5" lineSizeType="MM" scaleBasedVisibility="0" minScaleDenominator="0" penAlpha="255" backgroundColor="#ffffff" enabled="0" penColor="#000000" rotationOffset="270" lineSizeScale="3x:0,0,0,0,0,0" scaleDependency="Area" opacity="1" width="15" maxScaleDenominator="1e+08" backgroundAlpha="255" sizeScale="3x:0,0,0,0,0,0" diagramOrientation="Up" showAxis="1" labelPlacementMethod="XHeight" penWidth="0" height="15" minimumSize="0" barWidth="5" spacingUnit="MM" direction="0">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" underline="0" style="" italic="0" bold="0" strikethrough="0"/>
      <attribute color="#000000" label="" field="" colorOpacity="1"/>
      <axisSymbol>
        <symbol alpha="1" name="" is_animated="0" type="line" frame_rate="10" clip_to_extent="1" force_rhr="0">
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer pass="0" enabled="1" locked="0" class="SimpleLine">
            <Option type="Map">
              <Option name="align_dash_pattern" type="QString" value="0"/>
              <Option name="capstyle" type="QString" value="square"/>
              <Option name="customdash" type="QString" value="5;2"/>
              <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="customdash_unit" type="QString" value="MM"/>
              <Option name="dash_pattern_offset" type="QString" value="0"/>
              <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
              <Option name="draw_inside_polygon" type="QString" value="0"/>
              <Option name="joinstyle" type="QString" value="bevel"/>
              <Option name="line_color" type="QString" value="35,35,35,255"/>
              <Option name="line_style" type="QString" value="solid"/>
              <Option name="line_width" type="QString" value="0.26"/>
              <Option name="line_width_unit" type="QString" value="MM"/>
              <Option name="offset" type="QString" value="0"/>
              <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offset_unit" type="QString" value="MM"/>
              <Option name="ring_filter" type="QString" value="0"/>
              <Option name="trim_distance_end" type="QString" value="0"/>
              <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_end_unit" type="QString" value="MM"/>
              <Option name="trim_distance_start" type="QString" value="0"/>
              <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_start_unit" type="QString" value="MM"/>
              <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
              <Option name="use_custom_dash" type="QString" value="0"/>
              <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings priority="0" obstacle="0" dist="0" showAll="1" zIndex="0" linePlacementFlags="18" placement="0">
    <properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CODIGO_UNICO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="UV" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CODIGO_DO_ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="QUADRA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="FACE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CEP" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LOCALIDADE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PONTO_DE_REFERENCIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ESPECIES" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="SATELITES" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PDOP" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LATITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LONGITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DISTANCE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" field="STATUS" index="0"/>
    <alias name="" field="CODIGO_UNICO" index="1"/>
    <alias name="" field="UV" index="2"/>
    <alias name="" field="CODIGO_DO_ENDERECO" index="3"/>
    <alias name="" field="QUADRA" index="4"/>
    <alias name="" field="FACE" index="5"/>
    <alias name="" field="CEP" index="6"/>
    <alias name="" field="LOCALIDADE" index="7"/>
    <alias name="" field="ENDERECO" index="8"/>
    <alias name="" field="PONTO_DE_REFERENCIA" index="9"/>
    <alias name="" field="ESPECIES" index="10"/>
    <alias name="" field="SATELITES" index="11"/>
    <alias name="" field="PDOP" index="12"/>
    <alias name="" field="LATITUDE" index="13"/>
    <alias name="" field="LONGITUDE" index="14"/>
    <alias name="" field="DISTANCE" index="15"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" expression="" field="STATUS"/>
    <default applyOnUpdate="0" expression="" field="CODIGO_UNICO"/>
    <default applyOnUpdate="0" expression="" field="UV"/>
    <default applyOnUpdate="0" expression="" field="CODIGO_DO_ENDERECO"/>
    <default applyOnUpdate="0" expression="" field="QUADRA"/>
    <default applyOnUpdate="0" expression="" field="FACE"/>
    <default applyOnUpdate="0" expression="" field="CEP"/>
    <default applyOnUpdate="0" expression="" field="LOCALIDADE"/>
    <default applyOnUpdate="0" expression="" field="ENDERECO"/>
    <default applyOnUpdate="0" expression="" field="PONTO_DE_REFERENCIA"/>
    <default applyOnUpdate="0" expression="" field="ESPECIES"/>
    <default applyOnUpdate="0" expression="" field="SATELITES"/>
    <default applyOnUpdate="0" expression="" field="PDOP"/>
    <default applyOnUpdate="0" expression="" field="LATITUDE"/>
    <default applyOnUpdate="0" expression="" field="LONGITUDE"/>
    <default applyOnUpdate="0" expression="" field="DISTANCE"/>
  </defaults>
  <constraints>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="STATUS" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="CODIGO_UNICO" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="UV" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="CODIGO_DO_ENDERECO" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="QUADRA" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="FACE" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="CEP" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="LOCALIDADE" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="ENDERECO" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="PONTO_DE_REFERENCIA" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="ESPECIES" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="SATELITES" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="PDOP" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="LATITUDE" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="LONGITUDE" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="DISTANCE" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="STATUS" desc=""/>
    <constraint exp="" field="CODIGO_UNICO" desc=""/>
    <constraint exp="" field="UV" desc=""/>
    <constraint exp="" field="CODIGO_DO_ENDERECO" desc=""/>
    <constraint exp="" field="QUADRA" desc=""/>
    <constraint exp="" field="FACE" desc=""/>
    <constraint exp="" field="CEP" desc=""/>
    <constraint exp="" field="LOCALIDADE" desc=""/>
    <constraint exp="" field="ENDERECO" desc=""/>
    <constraint exp="" field="PONTO_DE_REFERENCIA" desc=""/>
    <constraint exp="" field="ESPECIES" desc=""/>
    <constraint exp="" field="SATELITES" desc=""/>
    <constraint exp="" field="PDOP" desc=""/>
    <constraint exp="" field="LATITUDE" desc=""/>
    <constraint exp="" field="LONGITUDE" desc=""/>
    <constraint exp="" field="DISTANCE" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns>
      <column width="-1" name="CEP" hidden="0" type="field"/>
      <column width="-1" name="LATITUDE" hidden="0" type="field"/>
      <column width="-1" name="LONGITUDE" hidden="0" type="field"/>
      <column width="-1" name="UV" hidden="0" type="field"/>
      <column width="-1" name="ENDERECO" hidden="0" type="field"/>
      <column width="-1" name="PONTO_DE_REFERENCIA" hidden="0" type="field"/>
      <column width="-1" name="QUADRA" hidden="0" type="field"/>
      <column width="-1" name="FACE" hidden="0" type="field"/>
      <column width="-1" name="CODIGO_DO_ENDERECO" hidden="0" type="field"/>
      <column width="-1" name="LOCALIDADE" hidden="0" type="field"/>
      <column width="-1" name="STATUS" hidden="0" type="field"/>
      <column width="-1" name="SATELITES" hidden="0" type="field"/>
      <column width="-1" name="PDOP" hidden="0" type="field"/>
      <column width="-1" name="DISTANCE" hidden="0" type="field"/>
      <column width="-1" name="CODIGO_UNICO" hidden="0" type="field"/>
      <column width="-1" name="ESPECIES" hidden="0" type="field"/>
      <column width="-1" hidden="1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="CEP" editable="1"/>
    <field name="CODIGO_DO_ENDERECO" editable="1"/>
    <field name="CODIGO_UNICO" editable="1"/>
    <field name="COD_DISTRITO" editable="1"/>
    <field name="COD_ESPECIE" editable="1"/>
    <field name="COD_INDICADOR_CONST_ENDERECO" editable="1"/>
    <field name="COD_INDICADOR_ESTAB_ENDERECO" editable="1"/>
    <field name="COD_INDICADOR_FINALIDADE_CONST" editable="1"/>
    <field name="COD_MUNICIPIO" editable="1"/>
    <field name="COD_SETOR" editable="1"/>
    <field name="COD_SUBDISTRITO" editable="1"/>
    <field name="COD_TIPO_ESPECI" editable="1"/>
    <field name="COD_UF" editable="1"/>
    <field name="COD_UNICO_ENDERECO" editable="1"/>
    <field name="DATA_DE_CONFIRMACAO" editable="1"/>
    <field name="DISTANCE" editable="1"/>
    <field name="DSC_ESTABELECIMENTO" editable="1"/>
    <field name="DSC_LOCALIDADE" editable="1"/>
    <field name="DSC_MODIFICADOR" editable="1"/>
    <field name="ENDERECO" editable="1"/>
    <field name="ESPECIES" editable="1"/>
    <field name="FACE" editable="1"/>
    <field name="LATITUDE" editable="1"/>
    <field name="LOCALIDADE" editable="1"/>
    <field name="LONGITUDE" editable="1"/>
    <field name="NOM_COMP_ELEM1" editable="1"/>
    <field name="NOM_COMP_ELEM2" editable="1"/>
    <field name="NOM_COMP_ELEM3" editable="1"/>
    <field name="NOM_COMP_ELEM4" editable="1"/>
    <field name="NOM_COMP_ELEM5" editable="1"/>
    <field name="NOM_SEGLOGR" editable="1"/>
    <field name="NOM_TIPO_SEGLOGR" editable="1"/>
    <field name="NOM_TITULO_SEGLOGR" editable="1"/>
    <field name="NUM_ENDERECO" editable="1"/>
    <field name="NUM_FACE" editable="1"/>
    <field name="NUM_QUADRA" editable="1"/>
    <field name="NV_GEO_COORD" editable="1"/>
    <field name="PDOP" editable="1"/>
    <field name="PONTO_DE_REFERENCIA" editable="1"/>
    <field name="QUADRA" editable="1"/>
    <field name="SATELITES" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="UV" editable="1"/>
    <field name="VAL_COMP_ELEM1" editable="1"/>
    <field name="VAL_COMP_ELEM2" editable="1"/>
    <field name="VAL_COMP_ELEM3" editable="1"/>
    <field name="VAL_COMP_ELEM4" editable="1"/>
    <field name="VAL_COMP_ELEM5" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="CEP"/>
    <field labelOnTop="0" name="CODIGO_DO_ENDERECO"/>
    <field labelOnTop="0" name="CODIGO_UNICO"/>
    <field labelOnTop="0" name="COD_DISTRITO"/>
    <field labelOnTop="0" name="COD_ESPECIE"/>
    <field labelOnTop="0" name="COD_INDICADOR_CONST_ENDERECO"/>
    <field labelOnTop="0" name="COD_INDICADOR_ESTAB_ENDERECO"/>
    <field labelOnTop="0" name="COD_INDICADOR_FINALIDADE_CONST"/>
    <field labelOnTop="0" name="COD_MUNICIPIO"/>
    <field labelOnTop="0" name="COD_SETOR"/>
    <field labelOnTop="0" name="COD_SUBDISTRITO"/>
    <field labelOnTop="0" name="COD_TIPO_ESPECI"/>
    <field labelOnTop="0" name="COD_UF"/>
    <field labelOnTop="0" name="COD_UNICO_ENDERECO"/>
    <field labelOnTop="0" name="DATA_DE_CONFIRMACAO"/>
    <field labelOnTop="0" name="DISTANCE"/>
    <field labelOnTop="0" name="DSC_ESTABELECIMENTO"/>
    <field labelOnTop="0" name="DSC_LOCALIDADE"/>
    <field labelOnTop="0" name="DSC_MODIFICADOR"/>
    <field labelOnTop="0" name="ENDERECO"/>
    <field labelOnTop="0" name="ESPECIES"/>
    <field labelOnTop="0" name="FACE"/>
    <field labelOnTop="0" name="LATITUDE"/>
    <field labelOnTop="0" name="LOCALIDADE"/>
    <field labelOnTop="0" name="LONGITUDE"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM1"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM2"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM3"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM4"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM5"/>
    <field labelOnTop="0" name="NOM_SEGLOGR"/>
    <field labelOnTop="0" name="NOM_TIPO_SEGLOGR"/>
    <field labelOnTop="0" name="NOM_TITULO_SEGLOGR"/>
    <field labelOnTop="0" name="NUM_ENDERECO"/>
    <field labelOnTop="0" name="NUM_FACE"/>
    <field labelOnTop="0" name="NUM_QUADRA"/>
    <field labelOnTop="0" name="NV_GEO_COORD"/>
    <field labelOnTop="0" name="PDOP"/>
    <field labelOnTop="0" name="PONTO_DE_REFERENCIA"/>
    <field labelOnTop="0" name="QUADRA"/>
    <field labelOnTop="0" name="SATELITES"/>
    <field labelOnTop="0" name="STATUS"/>
    <field labelOnTop="0" name="UV"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM1"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM2"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM3"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM4"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM5"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CEP" reuseLastValue="0"/>
    <field name="CODIGO_DO_ENDERECO" reuseLastValue="0"/>
    <field name="CODIGO_UNICO" reuseLastValue="0"/>
    <field name="COD_DISTRITO" reuseLastValue="0"/>
    <field name="COD_ESPECIE" reuseLastValue="0"/>
    <field name="COD_INDICADOR_CONST_ENDERECO" reuseLastValue="0"/>
    <field name="COD_INDICADOR_ESTAB_ENDERECO" reuseLastValue="0"/>
    <field name="COD_INDICADOR_FINALIDADE_CONST" reuseLastValue="0"/>
    <field name="COD_MUNICIPIO" reuseLastValue="0"/>
    <field name="COD_SETOR" reuseLastValue="0"/>
    <field name="COD_SUBDISTRITO" reuseLastValue="0"/>
    <field name="COD_TIPO_ESPECI" reuseLastValue="0"/>
    <field name="COD_UF" reuseLastValue="0"/>
    <field name="COD_UNICO_ENDERECO" reuseLastValue="0"/>
    <field name="DATA_DE_CONFIRMACAO" reuseLastValue="0"/>
    <field name="DISTANCE" reuseLastValue="0"/>
    <field name="DSC_ESTABELECIMENTO" reuseLastValue="0"/>
    <field name="DSC_LOCALIDADE" reuseLastValue="0"/>
    <field name="DSC_MODIFICADOR" reuseLastValue="0"/>
    <field name="ENDERECO" reuseLastValue="0"/>
    <field name="ESPECIES" reuseLastValue="0"/>
    <field name="FACE" reuseLastValue="0"/>
    <field name="LATITUDE" reuseLastValue="0"/>
    <field name="LOCALIDADE" reuseLastValue="0"/>
    <field name="LONGITUDE" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM1" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM2" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM3" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM4" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM5" reuseLastValue="0"/>
    <field name="NOM_SEGLOGR" reuseLastValue="0"/>
    <field name="NOM_TIPO_SEGLOGR" reuseLastValue="0"/>
    <field name="NOM_TITULO_SEGLOGR" reuseLastValue="0"/>
    <field name="NUM_ENDERECO" reuseLastValue="0"/>
    <field name="NUM_FACE" reuseLastValue="0"/>
    <field name="NUM_QUADRA" reuseLastValue="0"/>
    <field name="NV_GEO_COORD" reuseLastValue="0"/>
    <field name="PDOP" reuseLastValue="0"/>
    <field name="PONTO_DE_REFERENCIA" reuseLastValue="0"/>
    <field name="QUADRA" reuseLastValue="0"/>
    <field name="SATELITES" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="UV" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM1" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM2" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM3" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM4" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM5" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"NOM_TIPO_SEGLOGR"</previewExpression>
  <mapTip>&lt;!DOCTYPE html>
                            &lt;html>
                              &lt;head>
                                &lt;meta http-equiv="content-type" content="text/html; charset=UTF-8">
                                &lt;style>
                                    table.grey{
                                        border-style: none;
                                        width: auto;
                                        padding: 15px;
                                        border-collapse: collapse;
                                        border-left: 0;
                                        border-right: 0;
                                        border-radius: 10px;
                                        border-spacing: 0px;
                                        overflow:hidden; /* hide overflowing cells */
                                    }
                                &lt;/style>					
                              &lt;/head>
                              &lt;body>
                                &lt;table  class="grey">
                                    &lt;tbody>                           
                                        &lt;tr style="height: 18px; width: auto;">
                                            &lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">Atributo&lt;/span>&lt;/td>
                                            &lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">valor&lt;/span>&lt;/td>
                                        &lt;/tr>
                                        &lt;tr style="font-size: 12px; width: auto;">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">SETOR&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">260960005000514&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>                             
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">UV&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%UV%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>
                                        &lt;tr style="font-size: 12px; width: auto;">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">ENDEREÇO&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%ENDERECO%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">PONTO DE REFERÊNCIA&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%PONTO_DE_REFERENCIA%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>
                                        
                                        &lt;tr style="font-size: 12px; width: auto;">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">QUADRA&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%QUADRA%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">FACE&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%FACE%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>
                                        &lt;tr style="font-size: 12px; width: auto;">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CÓDIGO DO ENDEREÇO&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%CODIGO_DO_ENDERECO%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CEP&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%CEP%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>
                                        &lt;tr style="font-size: 12px; width: auto;">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">LOCALIDADE&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%LOCALIDADE%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">STATUS&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%STATUS%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>
                                        &lt;tr style="font-size: 12px; width: auto;">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">ESPÉCIES&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%ESPECIES%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>						
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">DISTÂNCIA DA FACE&lt;/span>&lt;/td>
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%DISTANCE%]&lt;/span>&lt;/strong>&lt;/td>
                                        &lt;/tr>						
                                    &lt;/tbody>
                                &lt;/table>	
                              &lt;/body>
                            &lt;/html></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
