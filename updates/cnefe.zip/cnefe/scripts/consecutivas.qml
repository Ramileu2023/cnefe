<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis maxScale="0" styleCategories="AllStyleCategories" hasScaleBasedVisibilityFlag="0" version="3.28.6-Firenze" symbologyReferenceScale="-1" minScale="100000000" simplifyDrawingHints="1" simplifyAlgorithm="0" labelsEnabled="0" simplifyLocal="1" simplifyMaxScale="1" readOnly="0" simplifyDrawingTol="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal mode="0" accumulate="0" startField="" startExpression="" enabled="0" endExpression="" durationField="" fixedDuration="0" endField="" limitMode="0" durationUnit="min">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation showMarkerSymbolInSurfacePlots="0" type="IndividualFeatures" zscale="1" extrusion="0" respectLayerSymbol="1" symbology="Line" clamping="Terrain" zoffset="0" extrusionEnabled="0" binding="Centroid">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol is_animated="0" type="line" name="" frame_rate="10" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="232,113,141,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.6" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol is_animated="0" type="fill" name="" frame_rate="10" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="232,113,141,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="166,81,101,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol is_animated="0" type="marker" name="" frame_rate="10" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="square" name="cap_style"/>
            <Option type="QString" value="232,113,141,255" name="color"/>
            <Option type="QString" value="1" name="horizontal_anchor_point"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="diamond" name="name"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="166,81,101,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="diameter" name="scale_method"/>
            <Option type="QString" value="3" name="size"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
            <Option type="QString" value="MM" name="size_unit"/>
            <Option type="QString" value="1" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 referencescale="-1" type="singleSymbol" enableorderby="0" symbollevels="0" forceraster="0">
    <symbols>
      <symbol is_animated="0" type="line" name="0" frame_rate="10" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="227,26,28,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="1.86" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="ccw" name="direction"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="239,41,41,255" name="single_color"/>
                <Option type="QString" value="rgb" name="spec"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="0.146" name="opacity"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="ccw" name="direction"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.386" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="rgb" name="spec"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style textColor="0,0,255,255" isExpression="1" textOpacity="1" multilineHeightUnit="Percentage" useSubstitutions="0" fontLetterSpacing="0" fontWordSpacing="0" allowHtml="0" fieldName="if(&quot;NUM_QUADRA&quot;  &lt;>  ''  AND   &quot;NUM_QUADRA&quot;  IS NOT NULL  AND   &quot;NUM_QUADRA&quot;  &lt;> '0',concat( 'Q:', lpad(  &quot;NUM_QUADRA&quot; ,3,'000'),'   ','F:',lpad( &quot;NUM_FACE&quot; ,3,'000')), '')&#xd;&#xa;&#xd;&#xa;  " fontItalic="0" fontKerning="1" multilineHeight="1" forcedBold="0" capitalization="0" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedItalic="0" fontStrikeout="0" fontFamily="Arial Black" fontSize="12" previewBkgrdColor="255,255,255,255" fontUnderline="0" blendMode="0" namedStyle="Normal" textOrientation="horizontal" legendString="Aa" fontWeight="50">
        <families/>
        <text-buffer bufferSize="1.2" bufferDraw="1" bufferJoinStyle="128" bufferNoFill="0" bufferOpacity="1" bufferSizeUnits="MM" bufferColor="250,250,250,255" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0"/>
        <text-mask maskedSymbolLayers="" maskSizeUnits="MM" maskOpacity="1" maskType="0" maskSize="4.5" maskEnabled="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskJoinStyle="128"/>
        <background shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeSVGFile="" shapeRotation="0" shapeBorderWidthUnit="Point" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeFillColor="255,255,255,255" shapeRadiiUnit="Point" shapeOpacity="1" shapeSizeUnit="Point" shapeBorderColor="128,128,128,255" shapeSizeX="0" shapeRadiiY="0" shapeOffsetUnit="Point" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeRotationType="0" shapeOffsetX="0" shapeDraw="0" shapeBorderWidth="0" shapeBlendMode="0" shapeJoinStyle="64">
          <symbol is_animated="0" type="marker" name="markerSymbol" frame_rate="10" clip_to_extent="1" alpha="1" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
              <Option type="Map">
                <Option type="QString" value="0" name="angle"/>
                <Option type="QString" value="square" name="cap_style"/>
                <Option type="QString" value="190,178,151,255" name="color"/>
                <Option type="QString" value="1" name="horizontal_anchor_point"/>
                <Option type="QString" value="bevel" name="joinstyle"/>
                <Option type="QString" value="circle" name="name"/>
                <Option type="QString" value="0,0" name="offset"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="35,35,35,255" name="outline_color"/>
                <Option type="QString" value="solid" name="outline_style"/>
                <Option type="QString" value="0" name="outline_width"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                <Option type="QString" value="MM" name="outline_width_unit"/>
                <Option type="QString" value="diameter" name="scale_method"/>
                <Option type="QString" value="2" name="size"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                <Option type="QString" value="MM" name="size_unit"/>
                <Option type="QString" value="1" name="vertical_anchor_point"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name"/>
                  <Option name="properties"/>
                  <Option type="QString" value="collection" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol is_animated="0" type="fill" name="fillSymbol" frame_rate="10" clip_to_extent="1" alpha="1" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleFill" enabled="1" locked="0" pass="0">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                <Option type="QString" value="255,255,255,255" name="color"/>
                <Option type="QString" value="bevel" name="joinstyle"/>
                <Option type="QString" value="0,0" name="offset"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="128,128,128,255" name="outline_color"/>
                <Option type="QString" value="no" name="outline_style"/>
                <Option type="QString" value="0" name="outline_width"/>
                <Option type="QString" value="Point" name="outline_width_unit"/>
                <Option type="QString" value="solid" name="style"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name"/>
                  <Option name="properties"/>
                  <Option type="QString" value="collection" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowBlendMode="6" shadowOffsetAngle="135" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowRadiusAlphaOnly="0" shadowUnder="0" shadowDraw="0" shadowRadius="1.5" shadowOffsetGlobal="1" shadowOpacity="0.69999999999999996" shadowOffsetDist="1" shadowRadiusUnit="MM"/>
        <dd_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format autoWrapLength="0" multilineAlign="0" rightDirectionSymbol=">" plussign="0" leftDirectionSymbol="&lt;" reverseDirectionSymbol="0" placeDirectionSymbol="0" addDirectionSymbol="0" wrapChar="" useMaxLineLengthForAutoWrap="1" formatNumbers="0" decimals="3"/>
      <placement offsetType="0" maxCurvedCharAngleIn="25" placement="2" geometryGeneratorType="PointGeometry" lineAnchorTextPoint="FollowPlacement" repeatDistance="0" overrunDistance="0" placementFlags="15" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" distMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" layerType="LineGeometry" offsetUnits="MM" distUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" preserveRotation="1" centroidInside="0" priority="5" geometryGeneratorEnabled="0" rotationAngle="0" rotationUnit="AngleDegrees" centroidWhole="0" maxCurvedCharAngleOut="-25" overlapHandling="PreventOverlap" yOffset="0" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorType="0" xOffset="0" polygonPlacementFlags="2" geometryGenerator="" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" lineAnchorPercent="0.5" allowDegraded="0" dist="0" lineAnchorClipping="0"/>
      <rendering minFeatureSize="0" upsidedownLabels="0" scaleMin="0" zIndex="0" mergeLines="0" unplacedVisibility="0" fontMaxPixelSize="10000" obstacleFactor="1" obstacleType="1" limitNumLabels="0" obstacle="1" labelPerPart="0" drawLabels="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleMax="2500" fontMinPixelSize="3" scaleVisibility="1"/>
      <dd_properties>
        <Option type="Map">
          <Option type="QString" value="" name="name"/>
          <Option name="properties"/>
          <Option type="QString" value="collection" name="type"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
          <Option type="int" value="0" name="blendMode"/>
          <Option type="Map" name="ddProperties">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
          <Option type="bool" value="false" name="drawToAllParts"/>
          <Option type="QString" value="0" name="enabled"/>
          <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
          <Option type="QString" value="&lt;symbol is_animated=&quot;0&quot; type=&quot;line&quot; name=&quot;symbol&quot; frame_rate=&quot;10&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
          <Option type="double" value="0" name="minLength"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
          <Option type="QString" value="MM" name="minLengthUnit"/>
          <Option type="double" value="0" name="offsetFromAnchor"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
          <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
          <Option type="double" value="0" name="offsetFromLabel"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
          <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option type="List" name="dualview/previewExpressions">
        <Option type="QString" value="&quot;NOM_TIPO_S&quot;"/>
      </Option>
      <Option type="int" value="0" name="embeddedWidgets/count"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory diagramOrientation="Up" height="15" minScaleDenominator="0" backgroundColor="#ffffff" penAlpha="255" sizeType="MM" sizeScale="3x:0,0,0,0,0,0" spacing="5" enabled="0" rotationOffset="270" width="15" direction="0" penColor="#000000" scaleBasedVisibility="0" backgroundAlpha="255" maxScaleDenominator="1e+08" labelPlacementMethod="XHeight" opacity="1" spacingUnitScale="3x:0,0,0,0,0,0" scaleDependency="Area" minimumSize="0" lineSizeScale="3x:0,0,0,0,0,0" barWidth="5" showAxis="1" penWidth="0" lineSizeType="MM" spacingUnit="MM">
      <fontProperties strikethrough="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" bold="0" underline="0" italic="0"/>
      <attribute label="" color="#000000" colorOpacity="1" field=""/>
      <axisSymbol>
        <symbol is_animated="0" type="line" name="" frame_rate="10" clip_to_extent="1" alpha="1" force_rhr="0">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
          <layer class="SimpleLine" enabled="1" locked="0" pass="0">
            <Option type="Map">
              <Option type="QString" value="0" name="align_dash_pattern"/>
              <Option type="QString" value="square" name="capstyle"/>
              <Option type="QString" value="5;2" name="customdash"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
              <Option type="QString" value="MM" name="customdash_unit"/>
              <Option type="QString" value="0" name="dash_pattern_offset"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
              <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
              <Option type="QString" value="0" name="draw_inside_polygon"/>
              <Option type="QString" value="bevel" name="joinstyle"/>
              <Option type="QString" value="35,35,35,255" name="line_color"/>
              <Option type="QString" value="solid" name="line_style"/>
              <Option type="QString" value="0.26" name="line_width"/>
              <Option type="QString" value="MM" name="line_width_unit"/>
              <Option type="QString" value="0" name="offset"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
              <Option type="QString" value="MM" name="offset_unit"/>
              <Option type="QString" value="0" name="ring_filter"/>
              <Option type="QString" value="0" name="trim_distance_end"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
              <Option type="QString" value="MM" name="trim_distance_end_unit"/>
              <Option type="QString" value="0" name="trim_distance_start"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
              <Option type="QString" value="MM" name="trim_distance_start_unit"/>
              <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
              <Option type="QString" value="0" name="use_custom_dash"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings obstacle="0" priority="0" placement="2" zIndex="0" showAll="1" linePlacementFlags="18" dist="0">
    <properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="None" name="fid">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="CEP">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LOCALIDADE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="NUM_QUADRA">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="NUM_FACE">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LOGRADOURO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="COD_SETOR">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="FLAG_FACE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_FACE">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" field="fid" index="0"/>
    <alias name="" field="CEP" index="1"/>
    <alias name="" field="LOCALIDADE" index="2"/>
    <alias name="" field="NUM_QUADRA" index="3"/>
    <alias name="" field="NUM_FACE" index="4"/>
    <alias name="" field="LOGRADOURO" index="5"/>
    <alias name="" field="COD_SETOR" index="6"/>
    <alias name="" field="FLAG_FACE" index="7"/>
    <alias name="" field="ID_FACE" index="8"/>
  </aliases>
  <defaults>
    <default expression="" applyOnUpdate="0" field="fid"/>
    <default expression="" applyOnUpdate="0" field="CEP"/>
    <default expression="" applyOnUpdate="0" field="LOCALIDADE"/>
    <default expression="" applyOnUpdate="0" field="NUM_QUADRA"/>
    <default expression="" applyOnUpdate="0" field="NUM_FACE"/>
    <default expression="" applyOnUpdate="0" field="LOGRADOURO"/>
    <default expression="" applyOnUpdate="0" field="COD_SETOR"/>
    <default expression="" applyOnUpdate="0" field="FLAG_FACE"/>
    <default expression="" applyOnUpdate="0" field="ID_FACE"/>
  </defaults>
  <constraints>
    <constraint unique_strength="1" exp_strength="0" constraints="3" notnull_strength="1" field="fid"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="CEP"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="LOCALIDADE"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="NUM_QUADRA"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="NUM_FACE"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="LOGRADOURO"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="COD_SETOR"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="FLAG_FACE"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="ID_FACE"/>
  </constraints>
  <constraintExpressions>
    <constraint field="fid" exp="" desc=""/>
    <constraint field="CEP" exp="" desc=""/>
    <constraint field="LOCALIDADE" exp="" desc=""/>
    <constraint field="NUM_QUADRA" exp="" desc=""/>
    <constraint field="NUM_FACE" exp="" desc=""/>
    <constraint field="LOGRADOURO" exp="" desc=""/>
    <constraint field="COD_SETOR" exp="" desc=""/>
    <constraint field="FLAG_FACE" exp="" desc=""/>
    <constraint field="ID_FACE" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="&quot;NUM_QUADRA&quot;">
    <columns>
      <column type="field" hidden="0" name="COD_SETOR" width="-1"/>
      <column type="field" hidden="0" name="NUM_QUADRA" width="-1"/>
      <column type="field" hidden="0" name="NUM_FACE" width="-1"/>
      <column type="field" hidden="0" name="fid" width="-1"/>
      <column type="field" hidden="0" name="CEP" width="-1"/>
      <column type="field" hidden="0" name="LOCALIDADE" width="-1"/>
      <column type="field" hidden="0" name="LOGRADOURO" width="-1"/>
      <column type="field" hidden="0" name="FLAG_FACE" width="-1"/>
      <column type="field" hidden="0" name="ID_FACE" width="-1"/>
      <column type="actions" hidden="1" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="CEP" editable="1"/>
    <field name="CEP_FACE" editable="1"/>
    <field name="COD_FACE" editable="1"/>
    <field name="COD_FACE_C" editable="1"/>
    <field name="COD_MUNICI" editable="1"/>
    <field name="COD_SETOR" editable="1"/>
    <field name="DSC_LOCALI" editable="1"/>
    <field name="FLAG_FACE" editable="1"/>
    <field name="ID_FACE" editable="1"/>
    <field name="LOCALIDADE" editable="1"/>
    <field name="LOGRADOURO" editable="1"/>
    <field name="NOM_SEGLOG" editable="1"/>
    <field name="NOM_TIPO_S" editable="1"/>
    <field name="NOM_TITULO" editable="1"/>
    <field name="NUM_FACE" editable="1"/>
    <field name="NUM_QUADRA" editable="1"/>
    <field name="QTD_DOM" editable="1"/>
    <field name="QTD_END" editable="1"/>
    <field name="buffer" editable="1"/>
    <field name="face_p" editable="1"/>
    <field name="fid" editable="1"/>
    <field name="nome_face_p" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="CEP"/>
    <field labelOnTop="0" name="CEP_FACE"/>
    <field labelOnTop="0" name="COD_FACE"/>
    <field labelOnTop="0" name="COD_FACE_C"/>
    <field labelOnTop="0" name="COD_MUNICI"/>
    <field labelOnTop="0" name="COD_SETOR"/>
    <field labelOnTop="0" name="DSC_LOCALI"/>
    <field labelOnTop="0" name="FLAG_FACE"/>
    <field labelOnTop="0" name="ID_FACE"/>
    <field labelOnTop="0" name="LOCALIDADE"/>
    <field labelOnTop="0" name="LOGRADOURO"/>
    <field labelOnTop="0" name="NOM_SEGLOG"/>
    <field labelOnTop="0" name="NOM_TIPO_S"/>
    <field labelOnTop="0" name="NOM_TITULO"/>
    <field labelOnTop="0" name="NUM_FACE"/>
    <field labelOnTop="0" name="NUM_QUADRA"/>
    <field labelOnTop="0" name="QTD_DOM"/>
    <field labelOnTop="0" name="QTD_END"/>
    <field labelOnTop="0" name="buffer"/>
    <field labelOnTop="0" name="face_p"/>
    <field labelOnTop="0" name="fid"/>
    <field labelOnTop="0" name="nome_face_p"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CEP" reuseLastValue="0"/>
    <field name="CEP_FACE" reuseLastValue="0"/>
    <field name="COD_FACE" reuseLastValue="0"/>
    <field name="COD_FACE_C" reuseLastValue="0"/>
    <field name="COD_MUNICI" reuseLastValue="0"/>
    <field name="COD_SETOR" reuseLastValue="0"/>
    <field name="DSC_LOCALI" reuseLastValue="0"/>
    <field name="FLAG_FACE" reuseLastValue="0"/>
    <field name="ID_FACE" reuseLastValue="0"/>
    <field name="LOCALIDADE" reuseLastValue="0"/>
    <field name="LOGRADOURO" reuseLastValue="0"/>
    <field name="NOM_SEGLOG" reuseLastValue="0"/>
    <field name="NOM_TIPO_S" reuseLastValue="0"/>
    <field name="NOM_TITULO" reuseLastValue="0"/>
    <field name="NUM_FACE" reuseLastValue="0"/>
    <field name="NUM_QUADRA" reuseLastValue="0"/>
    <field name="QTD_DOM" reuseLastValue="0"/>
    <field name="QTD_END" reuseLastValue="0"/>
    <field name="buffer" reuseLastValue="0"/>
    <field name="face_p" reuseLastValue="0"/>
    <field name="fid" reuseLastValue="0"/>
    <field name="nome_face_p" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"NOM_TIPO_S"</previewExpression>
  <mapTip>&lt;!DOCTYPE html>&#xd;
						&lt;html>&#xd;
						  &lt;head>&#xd;
							&lt;meta http-equiv="content-type" content="text/html; charset=UTF-8">&#xd;
							&lt;style>&#xd;
								table.grey{&#xd;
									border-style: none;&#xd;
									width: auto;&#xd;
									padding: 15px;&#xd;
									border-collapse: collapse;&#xd;
									border-left: 0;&#xd;
									border-right: 0;&#xd;
									border-radius: 10px;&#xd;
									border-spacing: 0px;&#xd;
									overflow:hidden; /* hide overflowing cells */&#xd;
								}&#xd;
							&lt;/style>					&#xd;
						  &lt;/head>&#xd;
						  &lt;body>&#xd;
							&lt;table  class="grey">&#xd;
								&lt;tbody>&#xd;
									&lt;tr style="height: 18px; width: auto;">&#xd;
										&lt;td style="height: 18px; background-color: #0000ff; text-align: center;">&lt;span style="color: #ffffff;">Atributo&lt;/span>&lt;/td>&#xd;
										&lt;td style="height: 18px; background-color: #0000ff; text-align: center;">&lt;span style="color: #ffffff;">valor&lt;/span>&lt;/td>&#xd;
									&lt;/tr>&#xd;
									&lt;tr style="font-size: 10px; width: auto;">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #0000ff; white-space: nowrap;">SETOR&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #0000ff; white-space: nowrap;">[%COD_SETOR%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>	&#xd;
									&lt;tr style="font-size: 10px; width: auto; background-color: #f2f2f2">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #0000ff; white-space: nowrap;">QUADRA&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #0000ff; white-space: nowrap;">[%NUM_QUADRA%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>		&#xd;
									&lt;tr style="font-size: 10px; width: auto;">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #0000ff; white-space: nowrap;">FACE&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #0000ff; white-space: nowrap;">[%NUM_FACE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>										&#xd;
									&lt;tr style="font-size: 10px; width: auto; background-color: #f2f2f2">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #0000ff; white-space: nowrap;">LOGRADOURO&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #0000ff; white-space: nowrap;">[%LOGRADOURO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>&#xd;
									&lt;tr style="font-size: 10px; width: auto;">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #0000ff; white-space: nowrap;">CEP&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #0000ff; white-space: nowrap;">[%CEP%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>&#xd;
									&lt;tr style="font-size: 10px; width: auto; background-color: #f2f2f2">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #0000ff; white-space: nowrap;">LOCALIDADE&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #0000ff; white-space: nowrap;">[%LOCALIDADE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>									&#xd;
								&lt;/tbody>&#xd;
							&lt;/table>	&#xd;
						  &lt;/body>&#xd;
						&lt;/html></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
