<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis readOnly="0" version="3.28.6-Firenze" simplifyLocal="1" minScale="100000000" styleCategories="AllStyleCategories" hasScaleBasedVisibilityFlag="0" maxScale="0" simplifyDrawingHints="0" simplifyAlgorithm="0" symbologyReferenceScale="-1" simplifyDrawingTol="1" labelsEnabled="0" simplifyMaxScale="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal enabled="0" startExpression="" endExpression="" endField="" accumulate="0" mode="0" durationField="" startField="" durationUnit="min" fixedDuration="0" limitMode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusion="0" extrusionEnabled="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" zscale="1" clamping="Terrain" binding="Centroid" type="IndividualFeatures" zoffset="0" symbology="Line">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol frame_rate="10" alpha="1" force_rhr="0" type="line" name="" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" class="SimpleLine" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="183,72,75,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol frame_rate="10" alpha="1" force_rhr="0" type="fill" name="" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" class="SimpleFill" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="183,72,75,255"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="131,51,54,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol frame_rate="10" alpha="1" force_rhr="0" type="marker" name="" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" class="SimpleMarker" locked="0">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="183,72,75,255"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="diamond"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="131,51,54,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="3"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 forceraster="0" enableorderby="0" type="singleSymbol" symbollevels="0" referencescale="-1">
    <symbols>
      <symbol frame_rate="10" alpha="1" force_rhr="0" type="marker" name="0" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" class="SimpleMarker" locked="0">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="184,8,8,255"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="star"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="184,8,8,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="area"/>
            <Option type="QString" name="size" value="3.66667"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <effect enabled="1" type="effectStack">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" pass="0" class="SimpleMarker" locked="0">
          <Option type="Map">
            <Option type="QString" name="angle" value="34"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="255,0,0,255"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="star"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="255,0,0,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="area"/>
            <Option type="QString" name="size" value="4"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <effect enabled="0" type="effectStack">
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <customproperties>
    <Option type="Map">
      <Option type="bool" name="OnConvertFormatRegeneratePrimaryKey" value="true"/>
      <Option type="int" name="embeddedWidgets/count" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory sizeType="MM" sizeScale="3x:0,0,0,0,0,0" showAxis="1" scaleBasedVisibility="0" enabled="0" backgroundColor="#ffffff" penColor="#000000" lineSizeType="MM" width="15" scaleDependency="Area" penAlpha="255" minScaleDenominator="0" penWidth="0" spacing="5" height="15" diagramOrientation="Up" labelPlacementMethod="XHeight" spacingUnitScale="3x:0,0,0,0,0,0" direction="0" spacingUnit="MM" barWidth="5" lineSizeScale="3x:0,0,0,0,0,0" minimumSize="0" opacity="1" rotationOffset="270" backgroundAlpha="255" maxScaleDenominator="1e+08">
      <fontProperties style="" underline="0" italic="0" bold="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" strikethrough="0"/>
      <attribute color="#000000" colorOpacity="1" label="" field=""/>
      <axisSymbol>
        <symbol frame_rate="10" alpha="1" force_rhr="0" type="line" name="" clip_to_extent="1" is_animated="0">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer enabled="1" pass="0" class="SimpleLine" locked="0">
            <Option type="Map">
              <Option type="QString" name="align_dash_pattern" value="0"/>
              <Option type="QString" name="capstyle" value="square"/>
              <Option type="QString" name="customdash" value="5;2"/>
              <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="customdash_unit" value="MM"/>
              <Option type="QString" name="dash_pattern_offset" value="0"/>
              <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
              <Option type="QString" name="draw_inside_polygon" value="0"/>
              <Option type="QString" name="joinstyle" value="bevel"/>
              <Option type="QString" name="line_color" value="35,35,35,255"/>
              <Option type="QString" name="line_style" value="solid"/>
              <Option type="QString" name="line_width" value="0.26"/>
              <Option type="QString" name="line_width_unit" value="MM"/>
              <Option type="QString" name="offset" value="0"/>
              <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="offset_unit" value="MM"/>
              <Option type="QString" name="ring_filter" value="0"/>
              <Option type="QString" name="trim_distance_end" value="0"/>
              <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_end_unit" value="MM"/>
              <Option type="QString" name="trim_distance_start" value="0"/>
              <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_start_unit" value="MM"/>
              <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
              <Option type="QString" name="use_custom_dash" value="0"/>
              <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings dist="0" placement="0" linePlacementFlags="18" zIndex="0" obstacle="0" priority="0" showAll="1">
    <properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="None" name="UV">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ENDERECO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="PONTO_DE_REFERENCIA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="QUADRA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="FACE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="CODIGO_DO_ENDERECO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="CEP">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LOCALIDADE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="STATUS">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="DATA_DE_CONFIRMACAO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LATITUDE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LONGITUDE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MINIMUM_DISTANCE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="UV"/>
    <alias name="" index="1" field="ENDERECO"/>
    <alias name="" index="2" field="PONTO_DE_REFERENCIA"/>
    <alias name="" index="3" field="QUADRA"/>
    <alias name="" index="4" field="FACE"/>
    <alias name="" index="5" field="CODIGO_DO_ENDERECO"/>
    <alias name="" index="6" field="CEP"/>
    <alias name="" index="7" field="LOCALIDADE"/>
    <alias name="" index="8" field="STATUS"/>
    <alias name="" index="9" field="DATA_DE_CONFIRMACAO"/>
    <alias name="" index="10" field="LATITUDE"/>
    <alias name="" index="11" field="LONGITUDE"/>
    <alias name="" index="12" field="MINIMUM_DISTANCE"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" expression="" field="UV"/>
    <default applyOnUpdate="0" expression="" field="ENDERECO"/>
    <default applyOnUpdate="0" expression="" field="PONTO_DE_REFERENCIA"/>
    <default applyOnUpdate="0" expression="" field="QUADRA"/>
    <default applyOnUpdate="0" expression="" field="FACE"/>
    <default applyOnUpdate="0" expression="" field="CODIGO_DO_ENDERECO"/>
    <default applyOnUpdate="0" expression="" field="CEP"/>
    <default applyOnUpdate="0" expression="" field="LOCALIDADE"/>
    <default applyOnUpdate="0" expression="" field="STATUS"/>
    <default applyOnUpdate="0" expression="" field="DATA_DE_CONFIRMACAO"/>
    <default applyOnUpdate="0" expression="" field="LATITUDE"/>
    <default applyOnUpdate="0" expression="" field="LONGITUDE"/>
    <default applyOnUpdate="0" expression="" field="MINIMUM_DISTANCE"/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="UV" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="ENDERECO" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="PONTO_DE_REFERENCIA" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="QUADRA" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="FACE" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="CODIGO_DO_ENDERECO" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="CEP" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="LOCALIDADE" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="STATUS" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="DATA_DE_CONFIRMACAO" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="LATITUDE" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="LONGITUDE" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" notnull_strength="0" field="MINIMUM_DISTANCE" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="UV"/>
    <constraint desc="" exp="" field="ENDERECO"/>
    <constraint desc="" exp="" field="PONTO_DE_REFERENCIA"/>
    <constraint desc="" exp="" field="QUADRA"/>
    <constraint desc="" exp="" field="FACE"/>
    <constraint desc="" exp="" field="CODIGO_DO_ENDERECO"/>
    <constraint desc="" exp="" field="CEP"/>
    <constraint desc="" exp="" field="LOCALIDADE"/>
    <constraint desc="" exp="" field="STATUS"/>
    <constraint desc="" exp="" field="DATA_DE_CONFIRMACAO"/>
    <constraint desc="" exp="" field="LATITUDE"/>
    <constraint desc="" exp="" field="LONGITUDE"/>
    <constraint desc="" exp="" field="MINIMUM_DISTANCE"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="">
    <columns>
      <column width="-1" hidden="0" type="field" name="CEP"/>
      <column width="-1" hidden="0" type="field" name="LATITUDE"/>
      <column width="-1" hidden="0" type="field" name="LONGITUDE"/>
      <column width="-1" hidden="0" type="field" name="UV"/>
      <column width="-1" hidden="0" type="field" name="ENDERECO"/>
      <column width="-1" hidden="0" type="field" name="PONTO_DE_REFERENCIA"/>
      <column width="-1" hidden="0" type="field" name="QUADRA"/>
      <column width="-1" hidden="0" type="field" name="FACE"/>
      <column width="-1" hidden="0" type="field" name="CODIGO_DO_ENDERECO"/>
      <column width="-1" hidden="0" type="field" name="LOCALIDADE"/>
      <column width="-1" hidden="0" type="field" name="STATUS"/>
      <column width="-1" hidden="0" type="field" name="DATA_DE_CONFIRMACAO"/>
      <column width="-1" hidden="0" type="field" name="MINIMUM_DISTANCE"/>
      <column width="-1" hidden="1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="CEP"/>
    <field editable="1" name="CODIGO_DO_ENDERECO"/>
    <field editable="1" name="COD_DISTRITO"/>
    <field editable="1" name="COD_ESPECIE"/>
    <field editable="1" name="COD_INDICADOR_CONST_ENDERECO"/>
    <field editable="1" name="COD_INDICADOR_ESTAB_ENDERECO"/>
    <field editable="1" name="COD_INDICADOR_FINALIDADE_CONST"/>
    <field editable="1" name="COD_MUNICIPIO"/>
    <field editable="1" name="COD_SETOR"/>
    <field editable="1" name="COD_SUBDISTRITO"/>
    <field editable="1" name="COD_TIPO_ESPECI"/>
    <field editable="1" name="COD_UF"/>
    <field editable="1" name="COD_UNICO_ENDERECO"/>
    <field editable="1" name="DATA_DE_CONFIRMACAO"/>
    <field editable="1" name="DSC_ESTABELECIMENTO"/>
    <field editable="1" name="DSC_LOCALIDADE"/>
    <field editable="1" name="DSC_MODIFICADOR"/>
    <field editable="1" name="ENDERECO"/>
    <field editable="1" name="FACE"/>
    <field editable="1" name="LATITUDE"/>
    <field editable="1" name="LOCALIDADE"/>
    <field editable="1" name="LONGITUDE"/>
    <field editable="1" name="MINIMUM_DISTANCE"/>
    <field editable="1" name="NOM_COMP_ELEM1"/>
    <field editable="1" name="NOM_COMP_ELEM2"/>
    <field editable="1" name="NOM_COMP_ELEM3"/>
    <field editable="1" name="NOM_COMP_ELEM4"/>
    <field editable="1" name="NOM_COMP_ELEM5"/>
    <field editable="1" name="NOM_SEGLOGR"/>
    <field editable="1" name="NOM_TIPO_SEGLOGR"/>
    <field editable="1" name="NOM_TITULO_SEGLOGR"/>
    <field editable="1" name="NUM_ENDERECO"/>
    <field editable="1" name="NUM_FACE"/>
    <field editable="1" name="NUM_QUADRA"/>
    <field editable="1" name="NV_GEO_COORD"/>
    <field editable="1" name="PONTO_DE_REFERENCIA"/>
    <field editable="1" name="QUADRA"/>
    <field editable="1" name="STATUS"/>
    <field editable="1" name="UV"/>
    <field editable="1" name="VAL_COMP_ELEM1"/>
    <field editable="1" name="VAL_COMP_ELEM2"/>
    <field editable="1" name="VAL_COMP_ELEM3"/>
    <field editable="1" name="VAL_COMP_ELEM4"/>
    <field editable="1" name="VAL_COMP_ELEM5"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="CEP"/>
    <field labelOnTop="0" name="CODIGO_DO_ENDERECO"/>
    <field labelOnTop="0" name="COD_DISTRITO"/>
    <field labelOnTop="0" name="COD_ESPECIE"/>
    <field labelOnTop="0" name="COD_INDICADOR_CONST_ENDERECO"/>
    <field labelOnTop="0" name="COD_INDICADOR_ESTAB_ENDERECO"/>
    <field labelOnTop="0" name="COD_INDICADOR_FINALIDADE_CONST"/>
    <field labelOnTop="0" name="COD_MUNICIPIO"/>
    <field labelOnTop="0" name="COD_SETOR"/>
    <field labelOnTop="0" name="COD_SUBDISTRITO"/>
    <field labelOnTop="0" name="COD_TIPO_ESPECI"/>
    <field labelOnTop="0" name="COD_UF"/>
    <field labelOnTop="0" name="COD_UNICO_ENDERECO"/>
    <field labelOnTop="0" name="DATA_DE_CONFIRMACAO"/>
    <field labelOnTop="0" name="DSC_ESTABELECIMENTO"/>
    <field labelOnTop="0" name="DSC_LOCALIDADE"/>
    <field labelOnTop="0" name="DSC_MODIFICADOR"/>
    <field labelOnTop="0" name="ENDERECO"/>
    <field labelOnTop="0" name="FACE"/>
    <field labelOnTop="0" name="LATITUDE"/>
    <field labelOnTop="0" name="LOCALIDADE"/>
    <field labelOnTop="0" name="LONGITUDE"/>
    <field labelOnTop="0" name="MINIMUM_DISTANCE"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM1"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM2"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM3"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM4"/>
    <field labelOnTop="0" name="NOM_COMP_ELEM5"/>
    <field labelOnTop="0" name="NOM_SEGLOGR"/>
    <field labelOnTop="0" name="NOM_TIPO_SEGLOGR"/>
    <field labelOnTop="0" name="NOM_TITULO_SEGLOGR"/>
    <field labelOnTop="0" name="NUM_ENDERECO"/>
    <field labelOnTop="0" name="NUM_FACE"/>
    <field labelOnTop="0" name="NUM_QUADRA"/>
    <field labelOnTop="0" name="NV_GEO_COORD"/>
    <field labelOnTop="0" name="PONTO_DE_REFERENCIA"/>
    <field labelOnTop="0" name="QUADRA"/>
    <field labelOnTop="0" name="STATUS"/>
    <field labelOnTop="0" name="UV"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM1"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM2"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM3"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM4"/>
    <field labelOnTop="0" name="VAL_COMP_ELEM5"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CEP" reuseLastValue="0"/>
    <field name="CODIGO_DO_ENDERECO" reuseLastValue="0"/>
    <field name="COD_DISTRITO" reuseLastValue="0"/>
    <field name="COD_ESPECIE" reuseLastValue="0"/>
    <field name="COD_INDICADOR_CONST_ENDERECO" reuseLastValue="0"/>
    <field name="COD_INDICADOR_ESTAB_ENDERECO" reuseLastValue="0"/>
    <field name="COD_INDICADOR_FINALIDADE_CONST" reuseLastValue="0"/>
    <field name="COD_MUNICIPIO" reuseLastValue="0"/>
    <field name="COD_SETOR" reuseLastValue="0"/>
    <field name="COD_SUBDISTRITO" reuseLastValue="0"/>
    <field name="COD_TIPO_ESPECI" reuseLastValue="0"/>
    <field name="COD_UF" reuseLastValue="0"/>
    <field name="COD_UNICO_ENDERECO" reuseLastValue="0"/>
    <field name="DATA_DE_CONFIRMACAO" reuseLastValue="0"/>
    <field name="DSC_ESTABELECIMENTO" reuseLastValue="0"/>
    <field name="DSC_LOCALIDADE" reuseLastValue="0"/>
    <field name="DSC_MODIFICADOR" reuseLastValue="0"/>
    <field name="ENDERECO" reuseLastValue="0"/>
    <field name="FACE" reuseLastValue="0"/>
    <field name="LATITUDE" reuseLastValue="0"/>
    <field name="LOCALIDADE" reuseLastValue="0"/>
    <field name="LONGITUDE" reuseLastValue="0"/>
    <field name="MINIMUM_DISTANCE" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM1" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM2" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM3" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM4" reuseLastValue="0"/>
    <field name="NOM_COMP_ELEM5" reuseLastValue="0"/>
    <field name="NOM_SEGLOGR" reuseLastValue="0"/>
    <field name="NOM_TIPO_SEGLOGR" reuseLastValue="0"/>
    <field name="NOM_TITULO_SEGLOGR" reuseLastValue="0"/>
    <field name="NUM_ENDERECO" reuseLastValue="0"/>
    <field name="NUM_FACE" reuseLastValue="0"/>
    <field name="NUM_QUADRA" reuseLastValue="0"/>
    <field name="NV_GEO_COORD" reuseLastValue="0"/>
    <field name="PONTO_DE_REFERENCIA" reuseLastValue="0"/>
    <field name="QUADRA" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="UV" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM1" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM2" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM3" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM4" reuseLastValue="0"/>
    <field name="VAL_COMP_ELEM5" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"NOM_TIPO_SEGLOGR"</previewExpression>
  <mapTip>&lt;!DOCTYPE html>
        &lt;html>
          &lt;head>
            &lt;meta http-equiv="content-type" content="text/html; charset=UTF-8">
          &lt;/head>
          &lt;body>
            &lt;table style="width: 200px;" border="0">
              &lt;tbody>
                &lt;tr>
                  &lt;td style="text-align: center; width: 128px; vertical-align: bottom; background-color: white;">&lt;span
                        style="color: #548dd4; font-size:10px; ">SETOR&lt;/span>&lt;br>&lt;/td>
                  &lt;td style="text-align: center; width: 128px; vertical-align: bottom; background-color: white;">&lt;span
                      style="color: #548dd4; font-size:10px;">QUADRA&lt;/span>&lt;/td>
                  &lt;td style="text-align: center; width: 128px; vertical-align: bottom; background-color: white;">&lt;span
                      style="color: #548dd4; font-size:10px;">FACE&lt;/span>&lt;/td>
                &lt;/tr>
                &lt;tr>
                  &lt;td style="text-align: center; vertical-align: top; background-color: white;">&lt;span
                      style="color: #00129a; font-size:12px;">[%COD_SETOR%]&lt;/span>&lt;/td>
                  &lt;td style="text-align: center; vertical-align: top; background-color: white;">&lt;span
                      style="color: #00129a; font-size:12px;">[%NUM_QUADRA%]&lt;/span>&lt;/td>
                  &lt;td style="text-align: center; vertical-align: top; background-color: white;">&lt;span
                      style="color: #00129a; font-size:12px;">[%NUM_FACE%]&lt;/span>&lt;/td>
                &lt;/tr>
              &lt;/tbody>
            &lt;/table>
          &lt;/body>
        &lt;/html></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
