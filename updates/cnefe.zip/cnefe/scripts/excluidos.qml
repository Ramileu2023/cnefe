<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingTol="1" hasScaleBasedVisibilityFlag="0" simplifyDrawingHints="0" symbologyReferenceScale="-1" version="3.28.6-Firenze" simplifyMaxScale="1" maxScale="0" readOnly="0" minScale="100000000" styleCategories="AllStyleCategories" labelsEnabled="0" simplifyAlgorithm="0" simplifyLocal="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal fixedDuration="0" startField="" accumulate="0" endField="" enabled="0" durationField="" mode="0" endExpression="" startExpression="" durationUnit="min" limitMode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zscale="1" zoffset="0" extrusionEnabled="0" clamping="Terrain" extrusion="0" type="IndividualFeatures" respectLayerSymbol="1" symbology="Line" showMarkerSymbolInSurfacePlots="0" binding="Centroid">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol force_rhr="0" frame_rate="10" type="line" name="" is_animated="0" clip_to_extent="1" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" class="SimpleLine" locked="0">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="255,158,23,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol force_rhr="0" frame_rate="10" type="fill" name="" is_animated="0" clip_to_extent="1" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" class="SimpleFill" locked="0">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="255,158,23,255" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="182,113,16,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol force_rhr="0" frame_rate="10" type="marker" name="" is_animated="0" clip_to_extent="1" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" class="SimpleMarker" locked="0">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="255,158,23,255" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="diamond" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="182,113,16,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="3" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 referencescale="-1" enableorderby="0" type="RuleRenderer" forceraster="0" symbollevels="0">
    <rules key="{299318b8-65f4-4b52-ba6e-8a44c0d1f659}">
      <rule filter=" &quot;STATUS DO ENDERECO&quot; = 'ENDERECO EXCLUIDO'" label="Excluído" key="{7ef82fc7-03c2-40a1-a78d-982512db1e61}" symbol="0"/>
      <rule filter=" &quot;STATUS DO ENDERECO&quot; = 'ENDERECO INCLUIDO' " label="Incluído" key="{83978a38-c795-4346-b874-d157a448ac46}" symbol="1"/>
    </rules>
    <symbols>
      <symbol force_rhr="0" frame_rate="10" type="marker" name="0" is_animated="0" clip_to_extent="1" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" class="SvgMarker" locked="0">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="255,0,0,255" type="QString" name="color"/>
            <Option value="0" type="QString" name="fixedAspectRatio"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="C:\Users\eulim\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\cnefe\functions\interface\icons\end.svg" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255" type="QString" name="outline_color"/>
            <Option value="0" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option name="parameters"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="15" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" frame_rate="10" type="marker" name="1" is_animated="0" clip_to_extent="1" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" class="SvgMarker" locked="0">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="229,182,54,255" type="QString" name="color"/>
            <Option value="0" type="QString" name="fixedAspectRatio"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="C:\Users\eulim\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\cnefe\functions\interface\icons\begin.svg" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255" type="QString" name="outline_color"/>
            <Option value="0" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option name="parameters"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="15" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <customproperties>
    <Option type="Map">
      <Option type="List" name="dualview/previewExpressions">
        <Option value="&quot;NOME DO RESPONSAVEL&quot;" type="QString"/>
      </Option>
      <Option value="0" type="int" name="embeddedWidgets/count"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory sizeType="MM" opacity="1" penColor="#000000" penAlpha="255" direction="0" penWidth="0" lineSizeScale="3x:0,0,0,0,0,0" scaleDependency="Area" lineSizeType="MM" diagramOrientation="Up" backgroundAlpha="255" showAxis="1" sizeScale="3x:0,0,0,0,0,0" scaleBasedVisibility="0" minimumSize="0" barWidth="5" spacing="5" enabled="0" backgroundColor="#ffffff" labelPlacementMethod="XHeight" minScaleDenominator="0" spacingUnit="MM" spacingUnitScale="3x:0,0,0,0,0,0" height="15" width="15" rotationOffset="270" maxScaleDenominator="1e+08">
      <fontProperties strikethrough="0" underline="0" italic="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0"/>
      <axisSymbol>
        <symbol force_rhr="0" frame_rate="10" type="line" name="" is_animated="0" clip_to_extent="1" alpha="1">
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
          <layer pass="0" enabled="1" class="SimpleLine" locked="0">
            <Option type="Map">
              <Option value="0" type="QString" name="align_dash_pattern"/>
              <Option value="square" type="QString" name="capstyle"/>
              <Option value="5;2" type="QString" name="customdash"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
              <Option value="MM" type="QString" name="customdash_unit"/>
              <Option value="0" type="QString" name="dash_pattern_offset"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
              <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
              <Option value="0" type="QString" name="draw_inside_polygon"/>
              <Option value="bevel" type="QString" name="joinstyle"/>
              <Option value="35,35,35,255" type="QString" name="line_color"/>
              <Option value="solid" type="QString" name="line_style"/>
              <Option value="0.26" type="QString" name="line_width"/>
              <Option value="MM" type="QString" name="line_width_unit"/>
              <Option value="0" type="QString" name="offset"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
              <Option value="MM" type="QString" name="offset_unit"/>
              <Option value="0" type="QString" name="ring_filter"/>
              <Option value="0" type="QString" name="trim_distance_end"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
              <Option value="MM" type="QString" name="trim_distance_end_unit"/>
              <Option value="0" type="QString" name="trim_distance_start"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
              <Option value="MM" type="QString" name="trim_distance_start_unit"/>
              <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
              <Option value="0" type="QString" name="use_custom_dash"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings placement="0" priority="0" dist="0" zIndex="0" obstacle="0" linePlacementFlags="18" showAll="1">
    <properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="CODIGO UNICO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="QUADRA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="FACE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="UV" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CODIGO ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LOGRADOURO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NUMERO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LOCALIDADE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PONTO DE REFERENCIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CEP" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LATITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LONGITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ESPECIE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NOME DO RESPONSAVEL" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TELEFONE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ESTABELECIMENTO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="STATUS DO ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DATA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="SELECIONADO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="CODIGO UNICO" name=""/>
    <alias index="1" field="QUADRA" name=""/>
    <alias index="2" field="FACE" name=""/>
    <alias index="3" field="UV" name=""/>
    <alias index="4" field="CODIGO ENDERECO" name=""/>
    <alias index="5" field="LOGRADOURO" name=""/>
    <alias index="6" field="NUMERO" name=""/>
    <alias index="7" field="LOCALIDADE" name=""/>
    <alias index="8" field="PONTO DE REFERENCIA" name=""/>
    <alias index="9" field="CEP" name=""/>
    <alias index="10" field="LATITUDE" name=""/>
    <alias index="11" field="LONGITUDE" name=""/>
    <alias index="12" field="ESPECIE" name=""/>
    <alias index="13" field="NOME DO RESPONSAVEL" name=""/>
    <alias index="14" field="TELEFONE" name=""/>
    <alias index="15" field="ESTABELECIMENTO" name=""/>
    <alias index="16" field="STATUS DO ENDERECO" name=""/>
    <alias index="17" field="DATA" name=""/>
    <alias index="18" field="SELECIONADO" name=""/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" field="CODIGO UNICO" expression=""/>
    <default applyOnUpdate="0" field="QUADRA" expression=""/>
    <default applyOnUpdate="0" field="FACE" expression=""/>
    <default applyOnUpdate="0" field="UV" expression=""/>
    <default applyOnUpdate="0" field="CODIGO ENDERECO" expression=""/>
    <default applyOnUpdate="0" field="LOGRADOURO" expression=""/>
    <default applyOnUpdate="0" field="NUMERO" expression=""/>
    <default applyOnUpdate="0" field="LOCALIDADE" expression=""/>
    <default applyOnUpdate="0" field="PONTO DE REFERENCIA" expression=""/>
    <default applyOnUpdate="0" field="CEP" expression=""/>
    <default applyOnUpdate="0" field="LATITUDE" expression=""/>
    <default applyOnUpdate="0" field="LONGITUDE" expression=""/>
    <default applyOnUpdate="0" field="ESPECIE" expression=""/>
    <default applyOnUpdate="0" field="NOME DO RESPONSAVEL" expression=""/>
    <default applyOnUpdate="0" field="TELEFONE" expression=""/>
    <default applyOnUpdate="0" field="ESTABELECIMENTO" expression=""/>
    <default applyOnUpdate="0" field="STATUS DO ENDERECO" expression=""/>
    <default applyOnUpdate="0" field="DATA" expression=""/>
    <default applyOnUpdate="0" field="SELECIONADO" expression=""/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="CODIGO UNICO" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="QUADRA" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="FACE" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="UV" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="CODIGO ENDERECO" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="LOGRADOURO" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="NUMERO" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="LOCALIDADE" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="PONTO DE REFERENCIA" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="CEP" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="LATITUDE" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="LONGITUDE" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="ESPECIE" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="NOME DO RESPONSAVEL" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="TELEFONE" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="ESTABELECIMENTO" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="STATUS DO ENDERECO" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="DATA" constraints="0" notnull_strength="0" unique_strength="0"/>
    <constraint exp_strength="0" field="SELECIONADO" constraints="0" notnull_strength="0" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="CODIGO UNICO" desc=""/>
    <constraint exp="" field="QUADRA" desc=""/>
    <constraint exp="" field="FACE" desc=""/>
    <constraint exp="" field="UV" desc=""/>
    <constraint exp="" field="CODIGO ENDERECO" desc=""/>
    <constraint exp="" field="LOGRADOURO" desc=""/>
    <constraint exp="" field="NUMERO" desc=""/>
    <constraint exp="" field="LOCALIDADE" desc=""/>
    <constraint exp="" field="PONTO DE REFERENCIA" desc=""/>
    <constraint exp="" field="CEP" desc=""/>
    <constraint exp="" field="LATITUDE" desc=""/>
    <constraint exp="" field="LONGITUDE" desc=""/>
    <constraint exp="" field="ESPECIE" desc=""/>
    <constraint exp="" field="NOME DO RESPONSAVEL" desc=""/>
    <constraint exp="" field="TELEFONE" desc=""/>
    <constraint exp="" field="ESTABELECIMENTO" desc=""/>
    <constraint exp="" field="STATUS DO ENDERECO" desc=""/>
    <constraint exp="" field="DATA" desc=""/>
    <constraint exp="" field="SELECIONADO" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortExpression="" sortOrder="0" actionWidgetStyle="dropDown">
    <columns>
      <column hidden="0" width="-1" type="field" name="CODIGO UNICO"/>
      <column hidden="0" width="-1" type="field" name="QUADRA"/>
      <column hidden="0" width="-1" type="field" name="FACE"/>
      <column hidden="0" width="-1" type="field" name="UV"/>
      <column hidden="0" width="-1" type="field" name="CODIGO ENDERECO"/>
      <column hidden="0" width="-1" type="field" name="LOGRADOURO"/>
      <column hidden="0" width="-1" type="field" name="NUMERO"/>
      <column hidden="0" width="-1" type="field" name="LOCALIDADE"/>
      <column hidden="0" width="-1" type="field" name="PONTO DE REFERENCIA"/>
      <column hidden="0" width="-1" type="field" name="CEP"/>
      <column hidden="0" width="-1" type="field" name="LATITUDE"/>
      <column hidden="0" width="-1" type="field" name="LONGITUDE"/>
      <column hidden="0" width="-1" type="field" name="ESPECIE"/>
      <column hidden="0" width="-1" type="field" name="NOME DO RESPONSAVEL"/>
      <column hidden="0" width="-1" type="field" name="TELEFONE"/>
      <column hidden="0" width="-1" type="field" name="ESTABELECIMENTO"/>
      <column hidden="0" width="-1" type="field" name="STATUS DO ENDERECO"/>
      <column hidden="0" width="-1" type="field" name="DATA"/>
      <column hidden="0" width="-1" type="field" name="SELECIONADO"/>
      <column hidden="1" width="-1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="CEP"/>
    <field editable="1" name="CODIGO ENDERECO"/>
    <field editable="1" name="CODIGO UNICO"/>
    <field editable="1" name="DATA"/>
    <field editable="1" name="ESPECIE"/>
    <field editable="1" name="ESTABELECIMENTO"/>
    <field editable="1" name="FACE"/>
    <field editable="1" name="LATITUDE"/>
    <field editable="1" name="LOCALIDADE"/>
    <field editable="1" name="LOGRADOURO"/>
    <field editable="1" name="LONGITUDE"/>
    <field editable="1" name="NOME DO RESPONSAVEL"/>
    <field editable="1" name="NUMERO"/>
    <field editable="1" name="PONTO DE REFERENCIA"/>
    <field editable="1" name="QUADRA"/>
    <field editable="1" name="SELECIONADO"/>
    <field editable="1" name="STATUS DO ENDERECO"/>
    <field editable="1" name="TELEFONE"/>
    <field editable="1" name="UV"/>
  </editable>
  <labelOnTop>
    <field name="CEP" labelOnTop="0"/>
    <field name="CODIGO ENDERECO" labelOnTop="0"/>
    <field name="CODIGO UNICO" labelOnTop="0"/>
    <field name="DATA" labelOnTop="0"/>
    <field name="ESPECIE" labelOnTop="0"/>
    <field name="ESTABELECIMENTO" labelOnTop="0"/>
    <field name="FACE" labelOnTop="0"/>
    <field name="LATITUDE" labelOnTop="0"/>
    <field name="LOCALIDADE" labelOnTop="0"/>
    <field name="LOGRADOURO" labelOnTop="0"/>
    <field name="LONGITUDE" labelOnTop="0"/>
    <field name="NOME DO RESPONSAVEL" labelOnTop="0"/>
    <field name="NUMERO" labelOnTop="0"/>
    <field name="PONTO DE REFERENCIA" labelOnTop="0"/>
    <field name="QUADRA" labelOnTop="0"/>
    <field name="SELECIONADO" labelOnTop="0"/>
    <field name="STATUS DO ENDERECO" labelOnTop="0"/>
    <field name="TELEFONE" labelOnTop="0"/>
    <field name="UV" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="CEP"/>
    <field reuseLastValue="0" name="CODIGO ENDERECO"/>
    <field reuseLastValue="0" name="CODIGO UNICO"/>
    <field reuseLastValue="0" name="DATA"/>
    <field reuseLastValue="0" name="ESPECIE"/>
    <field reuseLastValue="0" name="ESTABELECIMENTO"/>
    <field reuseLastValue="0" name="FACE"/>
    <field reuseLastValue="0" name="LATITUDE"/>
    <field reuseLastValue="0" name="LOCALIDADE"/>
    <field reuseLastValue="0" name="LOGRADOURO"/>
    <field reuseLastValue="0" name="LONGITUDE"/>
    <field reuseLastValue="0" name="NOME DO RESPONSAVEL"/>
    <field reuseLastValue="0" name="NUMERO"/>
    <field reuseLastValue="0" name="PONTO DE REFERENCIA"/>
    <field reuseLastValue="0" name="QUADRA"/>
    <field reuseLastValue="0" name="SELECIONADO"/>
    <field reuseLastValue="0" name="STATUS DO ENDERECO"/>
    <field reuseLastValue="0" name="TELEFONE"/>
    <field reuseLastValue="0" name="UV"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"NOME DO RESPONSAVEL"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
