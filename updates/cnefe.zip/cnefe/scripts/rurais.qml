<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis maxScale="0" labelsEnabled="0" version="3.28.6-Firenze" simplifyAlgorithm="0" hasScaleBasedVisibilityFlag="0" minScale="100000000" simplifyLocal="1" styleCategories="AllStyleCategories" simplifyDrawingTol="1" symbologyReferenceScale="-1" simplifyDrawingHints="0" simplifyMaxScale="1" readOnly="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal fixedDuration="0" limitMode="0" endField="" durationField="" durationUnit="min" accumulate="0" endExpression="" startField="" enabled="0" startExpression="" mode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation clamping="Terrain" zoffset="0" type="IndividualFeatures" extrusion="0" binding="Centroid" showMarkerSymbolInSurfacePlots="0" respectLayerSymbol="1" extrusionEnabled="0" zscale="1" symbology="Line">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol clip_to_extent="1" type="line" alpha="1" frame_rate="10" name="" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleLine" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="183,72,75,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol clip_to_extent="1" type="fill" alpha="1" frame_rate="10" name="" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleFill" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="183,72,75,255"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="131,51,54,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol clip_to_extent="1" type="marker" alpha="1" frame_rate="10" name="" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleMarker" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="183,72,75,255"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="diamond"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="131,51,54,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="3"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" type="singleSymbol" forceraster="0" referencescale="-1" symbollevels="0">
    <symbols>
      <symbol clip_to_extent="1" type="marker" alpha="1" frame_rate="10" name="0" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" class="SimpleMarker" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="0,255,0,255"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="circle"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="0,0,255,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.4"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="4"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" class="SimpleMarker" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="0,255,0,255"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="circle"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="255,0,0,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.4"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="0.875"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <customproperties>
    <Option type="Map">
      <Option type="List" name="dualview/previewExpressions">
        <Option type="QString" value="&quot;plus_code&quot;"/>
      </Option>
      <Option type="int" name="embeddedWidgets/count" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory penColor="#000000" enabled="0" lineSizeScale="3x:0,0,0,0,0,0" spacingUnitScale="3x:0,0,0,0,0,0" scaleBasedVisibility="0" sizeType="MM" spacing="5" backgroundAlpha="255" showAxis="1" backgroundColor="#ffffff" minScaleDenominator="0" sizeScale="3x:0,0,0,0,0,0" labelPlacementMethod="XHeight" penWidth="0" opacity="1" maxScaleDenominator="1e+08" width="15" scaleDependency="Area" rotationOffset="270" penAlpha="255" height="15" lineSizeType="MM" barWidth="5" spacingUnit="MM" direction="0" minimumSize="0" diagramOrientation="Up">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" style="" strikethrough="0" bold="0"/>
      <attribute label="" color="#000000" field="" colorOpacity="1"/>
      <axisSymbol>
        <symbol clip_to_extent="1" type="line" alpha="1" frame_rate="10" name="" is_animated="0" force_rhr="0">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer locked="0" class="SimpleLine" pass="0" enabled="1">
            <Option type="Map">
              <Option type="QString" name="align_dash_pattern" value="0"/>
              <Option type="QString" name="capstyle" value="square"/>
              <Option type="QString" name="customdash" value="5;2"/>
              <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="customdash_unit" value="MM"/>
              <Option type="QString" name="dash_pattern_offset" value="0"/>
              <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
              <Option type="QString" name="draw_inside_polygon" value="0"/>
              <Option type="QString" name="joinstyle" value="bevel"/>
              <Option type="QString" name="line_color" value="35,35,35,255"/>
              <Option type="QString" name="line_style" value="solid"/>
              <Option type="QString" name="line_width" value="0.26"/>
              <Option type="QString" name="line_width_unit" value="MM"/>
              <Option type="QString" name="offset" value="0"/>
              <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="offset_unit" value="MM"/>
              <Option type="QString" name="ring_filter" value="0"/>
              <Option type="QString" name="trim_distance_end" value="0"/>
              <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_end_unit" value="MM"/>
              <Option type="QString" name="trim_distance_start" value="0"/>
              <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_start_unit" value="MM"/>
              <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
              <Option type="QString" name="use_custom_dash" value="0"/>
              <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings showAll="1" dist="0" placement="0" priority="0" zIndex="0" linePlacementFlags="18" obstacle="0">
    <properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="UV" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PONTO_DE_REFERENCIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="QUADRA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="FACE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CODIGO_DO_ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CEP" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LOCALIDADE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DATA_DE_CONFIRMACAO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LATITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LONGITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" name="" field="UV"/>
    <alias index="1" name="" field="ENDERECO"/>
    <alias index="2" name="" field="PONTO_DE_REFERENCIA"/>
    <alias index="3" name="" field="QUADRA"/>
    <alias index="4" name="" field="FACE"/>
    <alias index="5" name="" field="CODIGO_DO_ENDERECO"/>
    <alias index="6" name="" field="CEP"/>
    <alias index="7" name="" field="LOCALIDADE"/>
    <alias index="8" name="" field="STATUS"/>
    <alias index="9" name="" field="DATA_DE_CONFIRMACAO"/>
    <alias index="10" name="" field="LATITUDE"/>
    <alias index="11" name="" field="LONGITUDE"/>
  </aliases>
  <defaults>
    <default field="UV" applyOnUpdate="0" expression=""/>
    <default field="ENDERECO" applyOnUpdate="0" expression=""/>
    <default field="PONTO_DE_REFERENCIA" applyOnUpdate="0" expression=""/>
    <default field="QUADRA" applyOnUpdate="0" expression=""/>
    <default field="FACE" applyOnUpdate="0" expression=""/>
    <default field="CODIGO_DO_ENDERECO" applyOnUpdate="0" expression=""/>
    <default field="CEP" applyOnUpdate="0" expression=""/>
    <default field="LOCALIDADE" applyOnUpdate="0" expression=""/>
    <default field="STATUS" applyOnUpdate="0" expression=""/>
    <default field="DATA_DE_CONFIRMACAO" applyOnUpdate="0" expression=""/>
    <default field="LATITUDE" applyOnUpdate="0" expression=""/>
    <default field="LONGITUDE" applyOnUpdate="0" expression=""/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" field="UV" exp_strength="0"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" field="ENDERECO" exp_strength="0"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" field="PONTO_DE_REFERENCIA" exp_strength="0"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" field="QUADRA" exp_strength="0"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" field="FACE" exp_strength="0"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" field="CODIGO_DO_ENDERECO" exp_strength="0"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" field="CEP" exp_strength="0"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" field="LOCALIDADE" exp_strength="0"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" field="STATUS" exp_strength="0"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" field="DATA_DE_CONFIRMACAO" exp_strength="0"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" field="LATITUDE" exp_strength="0"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" field="LONGITUDE" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="UV"/>
    <constraint exp="" desc="" field="ENDERECO"/>
    <constraint exp="" desc="" field="PONTO_DE_REFERENCIA"/>
    <constraint exp="" desc="" field="QUADRA"/>
    <constraint exp="" desc="" field="FACE"/>
    <constraint exp="" desc="" field="CODIGO_DO_ENDERECO"/>
    <constraint exp="" desc="" field="CEP"/>
    <constraint exp="" desc="" field="LOCALIDADE"/>
    <constraint exp="" desc="" field="STATUS"/>
    <constraint exp="" desc="" field="DATA_DE_CONFIRMACAO"/>
    <constraint exp="" desc="" field="LATITUDE"/>
    <constraint exp="" desc="" field="LONGITUDE"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="&quot;DATA_DE_CONFIRMACAO&quot;" sortOrder="0">
    <columns>
      <column type="field" name="UV" width="-1" hidden="0"/>
      <column type="field" name="ENDERECO" width="-1" hidden="0"/>
      <column type="field" name="PONTO_DE_REFERENCIA" width="364" hidden="0"/>
      <column type="field" name="QUADRA" width="-1" hidden="0"/>
      <column type="field" name="FACE" width="-1" hidden="0"/>
      <column type="field" name="CODIGO_DO_ENDERECO" width="139" hidden="0"/>
      <column type="field" name="CEP" width="-1" hidden="0"/>
      <column type="field" name="LOCALIDADE" width="-1" hidden="0"/>
      <column type="field" name="STATUS" width="-1" hidden="0"/>
      <column type="field" name="DATA_DE_CONFIRMACAO" width="182" hidden="0"/>
      <column type="field" name="LATITUDE" width="-1" hidden="0"/>
      <column type="field" name="LONGITUDE" width="-1" hidden="0"/>
      <column type="actions" width="-1" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="CEP" editable="1"/>
    <field name="CODIGO_DO_ENDERECO" editable="1"/>
    <field name="DATA_DE_CONFIRMACAO" editable="1"/>
    <field name="ENDERECO" editable="1"/>
    <field name="FACE" editable="1"/>
    <field name="LATITUDE" editable="1"/>
    <field name="LOCALIDADE" editable="1"/>
    <field name="LONGITUDE" editable="1"/>
    <field name="Name" editable="1"/>
    <field name="PONTO_DE_REFERENCIA" editable="1"/>
    <field name="QUADRA" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="UV" editable="1"/>
    <field name="altitudeMode" editable="1"/>
    <field name="area_m2" editable="1"/>
    <field name="begin" editable="1"/>
    <field name="confidence" editable="1"/>
    <field name="description" editable="1"/>
    <field name="drawOrder" editable="1"/>
    <field name="end" editable="1"/>
    <field name="extrude" editable="1"/>
    <field name="icon" editable="1"/>
    <field name="latitude" editable="1"/>
    <field name="longitude" editable="1"/>
    <field name="plus_code" editable="1"/>
    <field name="tessellate" editable="1"/>
    <field name="timestamp" editable="1"/>
    <field name="visibility" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="CEP"/>
    <field labelOnTop="0" name="CODIGO_DO_ENDERECO"/>
    <field labelOnTop="0" name="DATA_DE_CONFIRMACAO"/>
    <field labelOnTop="0" name="ENDERECO"/>
    <field labelOnTop="0" name="FACE"/>
    <field labelOnTop="0" name="LATITUDE"/>
    <field labelOnTop="0" name="LOCALIDADE"/>
    <field labelOnTop="0" name="LONGITUDE"/>
    <field labelOnTop="0" name="Name"/>
    <field labelOnTop="0" name="PONTO_DE_REFERENCIA"/>
    <field labelOnTop="0" name="QUADRA"/>
    <field labelOnTop="0" name="STATUS"/>
    <field labelOnTop="0" name="UV"/>
    <field labelOnTop="0" name="altitudeMode"/>
    <field labelOnTop="0" name="area_m2"/>
    <field labelOnTop="0" name="begin"/>
    <field labelOnTop="0" name="confidence"/>
    <field labelOnTop="0" name="description"/>
    <field labelOnTop="0" name="drawOrder"/>
    <field labelOnTop="0" name="end"/>
    <field labelOnTop="0" name="extrude"/>
    <field labelOnTop="0" name="icon"/>
    <field labelOnTop="0" name="latitude"/>
    <field labelOnTop="0" name="longitude"/>
    <field labelOnTop="0" name="plus_code"/>
    <field labelOnTop="0" name="tessellate"/>
    <field labelOnTop="0" name="timestamp"/>
    <field labelOnTop="0" name="visibility"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CEP" reuseLastValue="0"/>
    <field name="CODIGO_DO_ENDERECO" reuseLastValue="0"/>
    <field name="DATA_DE_CONFIRMACAO" reuseLastValue="0"/>
    <field name="ENDERECO" reuseLastValue="0"/>
    <field name="FACE" reuseLastValue="0"/>
    <field name="LATITUDE" reuseLastValue="0"/>
    <field name="LOCALIDADE" reuseLastValue="0"/>
    <field name="LONGITUDE" reuseLastValue="0"/>
    <field name="Name" reuseLastValue="0"/>
    <field name="PONTO_DE_REFERENCIA" reuseLastValue="0"/>
    <field name="QUADRA" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="UV" reuseLastValue="0"/>
    <field name="altitudeMode" reuseLastValue="0"/>
    <field name="area_m2" reuseLastValue="0"/>
    <field name="begin" reuseLastValue="0"/>
    <field name="confidence" reuseLastValue="0"/>
    <field name="description" reuseLastValue="0"/>
    <field name="drawOrder" reuseLastValue="0"/>
    <field name="end" reuseLastValue="0"/>
    <field name="extrude" reuseLastValue="0"/>
    <field name="icon" reuseLastValue="0"/>
    <field name="latitude" reuseLastValue="0"/>
    <field name="longitude" reuseLastValue="0"/>
    <field name="plus_code" reuseLastValue="0"/>
    <field name="tessellate" reuseLastValue="0"/>
    <field name="timestamp" reuseLastValue="0"/>
    <field name="visibility" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"plus_code"</previewExpression>
  <mapTip>&lt;!DOCTYPE html>&#xd;
                            &lt;html>&#xd;
                              &lt;head>&#xd;
                                &lt;meta http-equiv="content-type" content="text/html; charset=UTF-8">&#xd;
                                &lt;style>&#xd;
                                    table.grey{&#xd;
                                        border-style: none;&#xd;
                                        width: auto;&#xd;
                                        padding: 15px;&#xd;
                                        border-collapse: collapse;&#xd;
                                        border-left: 0;&#xd;
                                        border-right: 0;&#xd;
                                        border-radius: 10px;&#xd;
                                        border-spacing: 0px;&#xd;
                                        overflow:hidden; /* hide overflowing cells */&#xd;
                                    }&#xd;
                                &lt;/style>                    &#xd;
                              &lt;/head>&#xd;
                              &lt;body>&#xd;
                                &lt;table  class="grey">&#xd;
                                    &lt;tbody>&#xd;
                                        &lt;tr style="height: 18px; width: auto;">&#xd;
                                            &lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">Atributo&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">valor&lt;/span>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto;">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">UV&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%UV%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>                                   &#xd;
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">ENDEREÇO&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%ENDERECO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>                                   &#xd;
                                        &lt;tr style="font-size: 12px; width: auto;">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">PONTO DE REFERENCIA&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%PONTO_DE_REFERENCIA%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CÓDIGO DO ENDEREÇO&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%CODIGO_DO_ENDERECO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>                                   &#xd;
                                        &lt;tr style="font-size: 12px; width: auto;">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CEP&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%CEP%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">LOCALIDADE&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%LOCALIDADE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto;">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">STATUS&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%STATUS%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>&#xd;
                                        &lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
                                            &lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">DATA DE CONFIRMAÇÃO&lt;/span>&lt;/td>&#xd;
                                            &lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%DATA_DE_CONFIRMACAO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
                                        &lt;/tr>                                   &#xd;
                                        &#xd;
                                    &lt;/tbody>&#xd;
                                &lt;/table>    &#xd;
                              &lt;/body>&#xd;
                            &lt;/html></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
