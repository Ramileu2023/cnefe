<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="0" version="3.28.9-Firenze" symbologyReferenceScale="-1" simplifyAlgorithm="0" hasScaleBasedVisibilityFlag="0" styleCategories="AllStyleCategories" simplifyDrawingTol="1" simplifyLocal="1" maxScale="0" simplifyDrawingHints="0" minScale="100000000" simplifyMaxScale="1" readOnly="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endField="" startExpression="" durationField="" enabled="0" accumulate="0" endExpression="" startField="" limitMode="0" fixedDuration="0" mode="0" durationUnit="min">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation binding="Centroid" zoffset="0" zscale="1" symbology="Line" type="IndividualFeatures" clamping="Terrain" extrusionEnabled="0" extrusion="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" name="" is_animated="0" type="line" frame_rate="10" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SimpleLine">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="225,89,137,255"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" name="" is_animated="0" type="fill" frame_rate="10" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="225,89,137,255"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="161,64,98,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" name="" is_animated="0" type="marker" frame_rate="10" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="225,89,137,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="161,64,98,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 symbollevels="0" referencescale="-1" type="RuleRenderer" forceraster="0" enableorderby="0">
    <rules key="{5a4a5cfb-b8e5-4585-b739-d368c74911d3}">
      <rule filter=" &quot;ICON&quot;  =  'current' " symbol="0" label="ATUAL" key="{9dc6f8d1-114c-4c0f-8e3c-36ccb1dcb815}"/>
      <rule filter=" &quot;ICON&quot;  =  'previous' " symbol="1" label="ANTERIOR" key="{02879a05-8380-492c-a04c-968779f6f38d}"/>
    </rules>
    <symbols>
      <symbol alpha="1" name="0" is_animated="0" type="marker" frame_rate="10" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="color" type="QString" value="255,0,0,255"/>
            <Option name="fixedAspectRatio" type="QString" value="0"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="name" type="QString" value="C:/Users/eulimar.tiburcio/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/cnefe/functions/interface/icons/home-account-current.svg"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="parameters"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="8"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" name="1" is_animated="0" type="marker" frame_rate="10" clip_to_extent="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="color" type="QString" value="255,0,0,255"/>
            <Option name="fixedAspectRatio" type="QString" value="0"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="name" type="QString" value="C:/Users/eulimar.tiburcio/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/cnefe/functions/interface/icons/home-account-previous.svg"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="parameters"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="8"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <customproperties>
    <Option type="Map">
      <Option name="OnConvertFormatRegeneratePrimaryKey" type="bool" value="true"/>
      <Option name="dualview/previewExpressions" type="List">
        <Option type="QString" value="&quot;UV&quot;"/>
      </Option>
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory spacingUnitScale="3x:0,0,0,0,0,0" sizeType="MM" spacing="5" lineSizeType="MM" scaleBasedVisibility="0" minScaleDenominator="0" penAlpha="255" backgroundColor="#ffffff" enabled="0" penColor="#000000" rotationOffset="270" lineSizeScale="3x:0,0,0,0,0,0" scaleDependency="Area" opacity="1" width="15" maxScaleDenominator="1e+08" backgroundAlpha="255" sizeScale="3x:0,0,0,0,0,0" diagramOrientation="Up" showAxis="1" labelPlacementMethod="XHeight" penWidth="0" height="15" minimumSize="0" barWidth="5" spacingUnit="MM" direction="0">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" underline="0" style="" italic="0" bold="0" strikethrough="0"/>
      <attribute color="#000000" label="" field="" colorOpacity="1"/>
      <axisSymbol>
        <symbol alpha="1" name="" is_animated="0" type="line" frame_rate="10" clip_to_extent="1" force_rhr="0">
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer pass="0" enabled="1" locked="0" class="SimpleLine">
            <Option type="Map">
              <Option name="align_dash_pattern" type="QString" value="0"/>
              <Option name="capstyle" type="QString" value="square"/>
              <Option name="customdash" type="QString" value="5;2"/>
              <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="customdash_unit" type="QString" value="MM"/>
              <Option name="dash_pattern_offset" type="QString" value="0"/>
              <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
              <Option name="draw_inside_polygon" type="QString" value="0"/>
              <Option name="joinstyle" type="QString" value="bevel"/>
              <Option name="line_color" type="QString" value="35,35,35,255"/>
              <Option name="line_style" type="QString" value="solid"/>
              <Option name="line_width" type="QString" value="0.26"/>
              <Option name="line_width_unit" type="QString" value="MM"/>
              <Option name="offset" type="QString" value="0"/>
              <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offset_unit" type="QString" value="MM"/>
              <Option name="ring_filter" type="QString" value="0"/>
              <Option name="trim_distance_end" type="QString" value="0"/>
              <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_end_unit" type="QString" value="MM"/>
              <Option name="trim_distance_start" type="QString" value="0"/>
              <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_start_unit" type="QString" value="MM"/>
              <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
              <Option name="use_custom_dash" type="QString" value="0"/>
              <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings priority="0" obstacle="0" dist="0" showAll="1" zIndex="0" linePlacementFlags="18" placement="0">
    <properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CODIGO_UNICO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="UV" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CODIGO_DO_ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="QUADRA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="FACE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CEP" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LOCALIDADE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PONTO_DE_REFERENCIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ESPECIES" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="SATELITES" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PDOP" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LATITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LONGITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ICON" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DISTANCE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DISTANCIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" field="STATUS" index="0"/>
    <alias name="" field="CODIGO_UNICO" index="1"/>
    <alias name="" field="UV" index="2"/>
    <alias name="" field="CODIGO_DO_ENDERECO" index="3"/>
    <alias name="" field="QUADRA" index="4"/>
    <alias name="" field="FACE" index="5"/>
    <alias name="" field="CEP" index="6"/>
    <alias name="" field="LOCALIDADE" index="7"/>
    <alias name="" field="ENDERECO" index="8"/>
    <alias name="" field="PONTO_DE_REFERENCIA" index="9"/>
    <alias name="" field="ESPECIES" index="10"/>
    <alias name="" field="SATELITES" index="11"/>
    <alias name="" field="PDOP" index="12"/>
    <alias name="" field="LATITUDE" index="13"/>
    <alias name="" field="LONGITUDE" index="14"/>
    <alias name="" field="ICON" index="15"/>
    <alias name="" field="DISTANCE" index="16"/>
    <alias name="" field="DISTANCIA" index="17"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" expression="" field="STATUS"/>
    <default applyOnUpdate="0" expression="" field="CODIGO_UNICO"/>
    <default applyOnUpdate="0" expression="" field="UV"/>
    <default applyOnUpdate="0" expression="" field="CODIGO_DO_ENDERECO"/>
    <default applyOnUpdate="0" expression="" field="QUADRA"/>
    <default applyOnUpdate="0" expression="" field="FACE"/>
    <default applyOnUpdate="0" expression="" field="CEP"/>
    <default applyOnUpdate="0" expression="" field="LOCALIDADE"/>
    <default applyOnUpdate="0" expression="" field="ENDERECO"/>
    <default applyOnUpdate="0" expression="" field="PONTO_DE_REFERENCIA"/>
    <default applyOnUpdate="0" expression="" field="ESPECIES"/>
    <default applyOnUpdate="0" expression="" field="SATELITES"/>
    <default applyOnUpdate="0" expression="" field="PDOP"/>
    <default applyOnUpdate="0" expression="" field="LATITUDE"/>
    <default applyOnUpdate="0" expression="" field="LONGITUDE"/>
    <default applyOnUpdate="0" expression="" field="ICON"/>
    <default applyOnUpdate="0" expression="" field="DISTANCE"/>
    <default applyOnUpdate="0" expression="" field="DISTANCIA"/>
  </defaults>
  <constraints>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="STATUS" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="CODIGO_UNICO" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="UV" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="CODIGO_DO_ENDERECO" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="QUADRA" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="FACE" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="CEP" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="LOCALIDADE" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="ENDERECO" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="PONTO_DE_REFERENCIA" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="ESPECIES" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="SATELITES" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="PDOP" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="LATITUDE" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="LONGITUDE" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="ICON" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="DISTANCE" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" unique_strength="0" field="DISTANCIA" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="STATUS" desc=""/>
    <constraint exp="" field="CODIGO_UNICO" desc=""/>
    <constraint exp="" field="UV" desc=""/>
    <constraint exp="" field="CODIGO_DO_ENDERECO" desc=""/>
    <constraint exp="" field="QUADRA" desc=""/>
    <constraint exp="" field="FACE" desc=""/>
    <constraint exp="" field="CEP" desc=""/>
    <constraint exp="" field="LOCALIDADE" desc=""/>
    <constraint exp="" field="ENDERECO" desc=""/>
    <constraint exp="" field="PONTO_DE_REFERENCIA" desc=""/>
    <constraint exp="" field="ESPECIES" desc=""/>
    <constraint exp="" field="SATELITES" desc=""/>
    <constraint exp="" field="PDOP" desc=""/>
    <constraint exp="" field="LATITUDE" desc=""/>
    <constraint exp="" field="LONGITUDE" desc=""/>
    <constraint exp="" field="ICON" desc=""/>
    <constraint exp="" field="DISTANCE" desc=""/>
    <constraint exp="" field="DISTANCIA" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortOrder="1" sortExpression="&quot;DISTANCE&quot;" actionWidgetStyle="dropDown">
    <columns>
      <column width="-1" name="UV" hidden="0" type="field"/>
      <column width="-1" name="ENDERECO" hidden="0" type="field"/>
      <column width="336" name="PONTO_DE_REFERENCIA" hidden="0" type="field"/>
      <column width="-1" name="QUADRA" hidden="0" type="field"/>
      <column width="-1" name="FACE" hidden="0" type="field"/>
      <column width="-1" name="CODIGO_DO_ENDERECO" hidden="0" type="field"/>
      <column width="-1" name="CEP" hidden="0" type="field"/>
      <column width="-1" name="LOCALIDADE" hidden="0" type="field"/>
      <column width="-1" name="STATUS" hidden="0" type="field"/>
      <column width="-1" name="LATITUDE" hidden="0" type="field"/>
      <column width="-1" name="LONGITUDE" hidden="0" type="field"/>
      <column width="-1" name="DISTANCE" hidden="0" type="field"/>
      <column width="-1" name="ICON" hidden="0" type="field"/>
      <column width="-1" name="DISTANCIA" hidden="0" type="field"/>
      <column width="-1" name="CODIGO_UNICO" hidden="0" type="field"/>
      <column width="-1" name="ESPECIES" hidden="0" type="field"/>
      <column width="-1" name="SATELITES" hidden="0" type="field"/>
      <column width="-1" name="PDOP" hidden="0" type="field"/>
      <column width="-1" hidden="1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="CEP" editable="1"/>
    <field name="CODIGO_DO_ENDERECO" editable="1"/>
    <field name="CODIGO_UNICO" editable="1"/>
    <field name="DATA_DE_CONFIRMACAO" editable="1"/>
    <field name="DISTANCE" editable="1"/>
    <field name="DISTANCIA" editable="1"/>
    <field name="ENDERECO" editable="1"/>
    <field name="ESPECIES" editable="1"/>
    <field name="FACE" editable="1"/>
    <field name="ICON" editable="1"/>
    <field name="LATITUDE" editable="1"/>
    <field name="LOCALIDADE" editable="1"/>
    <field name="LONGITUDE" editable="1"/>
    <field name="PDOP" editable="1"/>
    <field name="PONTO_DE_REFERENCIA" editable="1"/>
    <field name="QUADRA" editable="1"/>
    <field name="SATELITES" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="UV" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="CEP"/>
    <field labelOnTop="0" name="CODIGO_DO_ENDERECO"/>
    <field labelOnTop="0" name="CODIGO_UNICO"/>
    <field labelOnTop="0" name="DATA_DE_CONFIRMACAO"/>
    <field labelOnTop="0" name="DISTANCE"/>
    <field labelOnTop="0" name="DISTANCIA"/>
    <field labelOnTop="0" name="ENDERECO"/>
    <field labelOnTop="0" name="ESPECIES"/>
    <field labelOnTop="0" name="FACE"/>
    <field labelOnTop="0" name="ICON"/>
    <field labelOnTop="0" name="LATITUDE"/>
    <field labelOnTop="0" name="LOCALIDADE"/>
    <field labelOnTop="0" name="LONGITUDE"/>
    <field labelOnTop="0" name="PDOP"/>
    <field labelOnTop="0" name="PONTO_DE_REFERENCIA"/>
    <field labelOnTop="0" name="QUADRA"/>
    <field labelOnTop="0" name="SATELITES"/>
    <field labelOnTop="0" name="STATUS"/>
    <field labelOnTop="0" name="UV"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CEP" reuseLastValue="0"/>
    <field name="CODIGO_DO_ENDERECO" reuseLastValue="0"/>
    <field name="CODIGO_UNICO" reuseLastValue="0"/>
    <field name="DATA_DE_CONFIRMACAO" reuseLastValue="0"/>
    <field name="DISTANCE" reuseLastValue="0"/>
    <field name="DISTANCIA" reuseLastValue="0"/>
    <field name="ENDERECO" reuseLastValue="0"/>
    <field name="ESPECIES" reuseLastValue="0"/>
    <field name="FACE" reuseLastValue="0"/>
    <field name="ICON" reuseLastValue="0"/>
    <field name="LATITUDE" reuseLastValue="0"/>
    <field name="LOCALIDADE" reuseLastValue="0"/>
    <field name="LONGITUDE" reuseLastValue="0"/>
    <field name="PDOP" reuseLastValue="0"/>
    <field name="PONTO_DE_REFERENCIA" reuseLastValue="0"/>
    <field name="QUADRA" reuseLastValue="0"/>
    <field name="SATELITES" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="UV" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"UV"</previewExpression>
  <mapTip>&lt;!DOCTYPE html>&#xd;
						&lt;html>&#xd;
						  &lt;head>&#xd;
							&lt;meta http-equiv="content-type" content="text/html; charset=UTF-8">&#xd;
							&lt;style>&#xd;
								table.grey{&#xd;
									border-style: none;&#xd;
									width: auto;&#xd;
									padding: 15px;&#xd;
									border-collapse: collapse;&#xd;
									border-left: 0;&#xd;
									border-right: 0;&#xd;
									border-radius: 10px;&#xd;
									border-spacing: 0px;&#xd;
									overflow:hidden; /* hide overflowing cells */&#xd;
								}&#xd;
							&lt;/style>					&#xd;
						  &lt;/head>&#xd;
						  &lt;body>&#xd;
							&lt;table  class="grey">&#xd;
								&lt;tbody>&#xd;
									&lt;tr style="height: 18px; width: auto;">&#xd;
										&lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">Atributo&lt;/span>&lt;/td>&#xd;
										&lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">valor&lt;/span>&lt;/td>&#xd;
									&lt;/tr>&#xd;
									&lt;tr style="font-size: 12px; width: auto;">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CÓDIGO ÚNICO&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%CODIGO_UNICO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>									&#xd;
									&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">ENDEREÇO&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%ENDERECO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>									&#xd;
									&lt;tr style="font-size: 12px; width: auto;">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">PONTO DE REFERENCIA&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%PONTO_DE_REFERENCIA%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>																		&#xd;
									&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">CEP&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%CEP%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>&#xd;
									&lt;tr style="font-size: 12px; width: auto;">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">LOCALIDADE&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%LOCALIDADE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>&#xd;
									&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">STATUS&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%STATUS%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>&#xd;
									&lt;tr style="font-size: 12px; width: auto;">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">ESPÉCIES&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%ESPECIES%]&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>&#xd;
									&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">DISTÂNCIA&lt;/span>&lt;/td>&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%DISTANCIA%] metros&lt;/span>&lt;/strong>&lt;/td>&#xd;
									&lt;/tr>														&#xd;
								&lt;/tbody>&#xd;
							&lt;/table>	&#xd;
						  &lt;/body>&#xd;
						&lt;/html></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
