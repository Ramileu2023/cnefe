from datetime import datetime
from selenium import webdriver
from selenium.common.exceptions import TimeoutException, NoSuchElementException, NoSuchDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import requests
from getuseragent import UserAgent
import time
import os
from pathlib import Path
def executar_amostragem(pasta_download, uf, ano, opcoes_ano):
    
    def limpar_pasta(pasta):
        for nome_arquivo in os.listdir(pasta):
            caminho_arquivo = os.path.join(pasta, nome_arquivo)
            try:
                if os.path.isfile(caminho_arquivo):
                    os.remove(caminho_arquivo)
            except Exception as e:
                print(f"⚠️ Não foi possível remover {caminho_arquivo}: {e}")

    def extrair_cookies(driver):
        cookies_selenium = driver.get_cookies()
        return {cookie['name']: cookie['value'] for cookie in cookies_selenium}

    def pegar_chromedriver_path():
        base_path = Path.home() / ".cache" / "selenium" / "chromedriver" / "win64"
        if not base_path.exists():
            raise FileNotFoundError(f"Pasta {base_path} não existe. Execute 'python -m selenium --browser chrome --debug' para baixar o ChromeDriver.")

        # Listar as subpastas, que são versões do ChromeDriver
        versoes = [p for p in base_path.iterdir() if p.is_dir()]
        if not versoes:
            raise FileNotFoundError(f"Nenhuma versão de ChromeDriver encontrada em {base_path}")

        # Ordenar versões para pegar a mais recente (ordem lexicográfica funciona aqui)
        versoes.sort(reverse=True)
        pasta_mais_recente = versoes[0]

        chromedriver_path = pasta_mais_recente / "chromedriver.exe"
        if not chromedriver_path.exists():
            raise FileNotFoundError(f"chromedriver.exe não encontrado em {chromedriver_path}")

        return chromedriver_path

    # Obter UserAgent
    useragent = UserAgent("firefox")
    theuseragent = useragent.Random()

    usuario, senha = carregar_credenciais()

    # Limpa a pasta antes de iniciar
    limpar_pasta(pasta_download)


    # Configurar o ChromeDriver
    options = webdriver.ChromeOptions()
    options.add_argument('--start-maximized')  # Opcional
    #options.add_argument("--headless")  # Executa sem interface gráfica
    options.add_argument("--disable-blink-features=AutomationControlled")  # Remove a flag "AutomationControlled"
    options.add_argument("--no-sandbox")  # Melhora compatibilidade
    options.add_argument("--disable-dev-shm-usage")  # Reduz uso de memória
    options.add_argument("--disable-gpu")  # Evita problemas gráficos
    options.add_argument("--ignore-certificate-errors") # Configuração para ignorar erros SSL
    # options.add_argument("--incognito")  # Estava causando problema em [def status_listagem(item, dialog):]              
    options.add_argument(f"user-agent={theuseragent}")

    options.add_experimental_option("prefs", {
        "download.default_directory": pasta_download,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })

    # Inicializa o WebDriver    
    try:
        chromedriver_path = pegar_chromedriver_path()
        service = Service(str(chromedriver_path))
        driver = webdriver.Chrome(service=service, options=options)
    except FileNotFoundError:
        # Cai no modo automático do Selenium
        driver = webdriver.Chrome(options=options)

    driver.set_page_load_timeout(60)
    # 🛠️ Modifica o `navigator.webdriver` antes de carregar qualquer página
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    }) 

    # Acessa a página inicial
    driver.get("https://w3amostramestra.ibge.gov.br/")

    # Espera até o botão estar clicável, com timeout de 10 segundos
    wait = WebDriverWait(driver, 10)
    login_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "form[action='/Home/Login'] button[type='submit']")))
    login_button.click()

    # Preencher a caixa de texto de login
    login_field = WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.ID, "UserName"))
    )
    login_field.send_keys(usuario)

    # Preencher a caixa de texto de senha
    senha_field = WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.ID, "Password"))
    )            
    senha_field.send_keys(senha)

    # Clicar no botão de login
    login_button = WebDriverWait(driver, 30).until(
        EC.visibility_of_element_located((By.ID, "login"))
    )             
    login_button.click()

    # Espera até o botão "Relatórios" estar clicável (máximo 10 segundos)
    wait = WebDriverWait(driver, 10)
    botao_relatorios = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[text()='Relatórios']")))
    botao_relatorios.click()

    # Espera o link "Amostra UPAs" aparecer e clica nele
    link_amostra_upas = wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, '/AmostraUpasUE') and contains(text(), 'Amostra UPAs')]")))
    link_amostra_upas.click()

    def selecionar_combo(driver, seletor_container, texto_visivel, timeout=10, tentativas=3):
        """
        Clica no combo customizado (Select2) e seleciona a opção com o texto visível especificado,
        se ela existir. Caso contrário, exibe um aviso e retorna False.
        """
        for tentativa in range(1, tentativas + 1):
            try:
                #print(f"⏳ Tentando selecionar '{texto_visivel}' no combo {seletor_container} (tentativa {tentativa})...")

                container = WebDriverWait(driver, timeout).until(
                    EC.element_to_be_clickable(seletor_container)
                )
                container.click()

                opcoes_xpath = "//ul[contains(@class, 'select2-results__options')]/li"
                WebDriverWait(driver, timeout).until(
                    EC.presence_of_element_located((By.XPATH, opcoes_xpath))
                )

                opcoes = driver.find_elements(By.XPATH, opcoes_xpath)
                textos_disponiveis = [opcao.text.strip() for opcao in opcoes]

                if texto_visivel not in textos_disponiveis:
                    #print(f"❌ Opção '{texto_visivel}' não está disponível no combo. Disponíveis: {textos_disponiveis}")
                    driver.find_element(By.TAG_NAME, "body").click()  # Fecha o dropdown
                    return False

                for opcao in opcoes:
                    if opcao.text.strip() == texto_visivel:
                        opcao.click()
                        #print(f"✅ Selecionado: {texto_visivel}")
                        return True

            except Exception as e:
                print(f"⚠️ Tentativa {tentativa} falhou ao selecionar {seletor_container}: {e}")
                time.sleep(1)

        return False  # em vez de raise

    def esperar_elemento_sumir(driver, by, timeout=10):
        try:
            WebDriverWait(driver, timeout).until_not(
                EC.presence_of_element_located(by)
            )
        except TimeoutException:
            print("⚠️ Elemento não sumiu, seguindo assim mesmo...")

    def unificar_csvs_sem_pandas(pasta_download):
        arquivos = [f for f in os.listdir(pasta_download) if f.endswith(".csv")]
        arquivos = sorted(arquivos)

        if not arquivos:
            print("⚠️ Nenhum CSV encontrado para unificar.")
            return

        cabecalho_referencia = None
        linhas_unificadas = []

        for i, nome_arquivo in enumerate(arquivos):
            caminho = os.path.join(pasta_download, nome_arquivo)
            with open(caminho, 'r', encoding='utf-8') as infile:
                linhas = infile.readlines()

            if not linhas:
                print(f"⚠️ Arquivo vazio ignorado: {nome_arquivo}")
                continue

            cabecalho_atual = linhas[0].strip()
            if cabecalho_referencia is None:
                cabecalho_referencia = cabecalho_atual
                linhas_unificadas.append(cabecalho_atual + '\n')
            elif cabecalho_atual != cabecalho_referencia:
                print(f"❌ Cabeçalho diferente detectado em {nome_arquivo}!")
                print(f"Esperado: {cabecalho_referencia}")
                print(f"Encontrado: {cabecalho_atual}")
                return  # ou continue, dependendo da sua política

            linhas_unificadas.extend(l.strip() + '\n' for l in linhas[1:])

        # Escreve no arquivo final
        arquivo_saida = os.path.join(pasta_download, "Amostra_UPAs_2025_UNIFICADO.csv")
        with open(arquivo_saida, 'w', encoding='utf-8') as outfile:
            outfile.writelines(linhas_unificadas)

        print(f"✅ CSVs unificados com cabeçalhos verificados: {arquivo_saida}")

    def baixar_csv(pasta_download, ano, trimestre):
        nome_base = "Amostra Mestra - Relatório Amostra de UPAs"
        timeout = 30

        for _ in range(timeout):
            arquivos = [f for f in os.listdir(pasta_download) if f.startswith(nome_base) and f.endswith(".csv")]
            if arquivos:
                arquivo_original = arquivos[-1]
                caminho_original = os.path.join(pasta_download, arquivo_original)

                # Gera nome novo com ano e trimestre
                novo_nome = f"Amostra_UPAs_{ano}_T{trimestre}.csv"
                caminho_novo = os.path.join(pasta_download, novo_nome)

                # Renomeia
                os.rename(caminho_original, caminho_novo)

                print(f"✅ CSV baixado e renomeado: {novo_nome}")
                return novo_nome

            time.sleep(1)

        raise Exception("❌ CSV não foi baixado dentro do tempo esperado.")

    def processar_trimestre(driver, pasta_download, uf, ano, trimestre):
        driver.get("https://w3amostramestra.ibge.gov.br/AmostraUpasUE#")

        # 🔁 Aguarde e force refresh para evitar 23 - CEARÁ interno do JS preso
        time.sleep(2)
        driver.refresh()
        time.sleep(2)

        if not selecionar_combo(driver, (By.ID, "select2-IdUf-container"), uf):
            print(f"⛔ Erro ao selecionar UF '{uf}', pulando trimestre {trimestre}.")
            return

        if not selecionar_combo(driver, (By.ID, "select2-AnoAmostra-container"), ano):
            print(f"⛔ Erro ao selecionar ano '{ano}', pulando trimestre {trimestre}.")
            return

        if not selecionar_combo(driver, (By.ID, "select2-TrimestreAmostra-container"), trimestre):
            #print(f"🔕 Trimestre {trimestre} não disponível, pulando...")
            return

        try:
            btn_filtrar = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.ID, "btnFiltrar"))
            )
            btn_filtrar.click()

            # ⏳ Aguarda recarregamento da tabela
            WebDriverWait(driver, 15).until(
                EC.presence_of_element_located((By.ID, "tbDados"))
            )

            # 💾 Exporta o CSV
            botao_exportar_csv = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "a.buttons-csv"))
            )
            botao_exportar_csv.click()

            baixar_csv(pasta_download, ano, trimestre)

        except Exception as e:
            print(f"❌ Erro ao processar trimestre {trimestre}: {e}")

    def executar_download_unificado(driver, pasta_download, uf, ano):

        trimestres = [1, 2, 3, 4]
        for trimestre in trimestres:
            #print(f"\n🔄 Processando trimestre {trimestre}...")
            processar_trimestre(driver, pasta_download, uf, ano, str(trimestre))
        #print("\n🔗 Unificando arquivos CSV baixados...")
        unificar_csvs_sem_pandas(pasta_download)

    try:
        for ano in opcoes_ano:
            executar_download_unificado(driver, pasta_download, uf, ano)
    finally:
        driver.quit()