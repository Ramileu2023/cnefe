<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis minScale="100000000" simplifyAlgorithm="0" version="3.16.5-Hannover" simplifyMaxScale="1" hasScaleBasedVisibilityFlag="0" simplifyLocal="1" styleCategories="AllStyleCategories" labelsEnabled="0" readOnly="0" simplifyDrawingTol="1" simplifyDrawingHints="1" maxScale="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
  </flags>
  <temporal endField="" endExpression="" fixedDuration="0" accumulate="0" startField="" startExpression="" durationUnit="min" mode="0" enabled="0" durationField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <renderer-v2 forceraster="0" type="singleSymbol" enableorderby="0" symbollevels="0">
    <symbols>
      <symbol name="0" alpha="1" type="line" clip_to_extent="1" force_rhr="0">
        <layer class="SimpleLine" enabled="1" locked="0" pass="0">
          <prop v="0" k="align_dash_pattern"/>
          <prop v="square" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="255,0,0,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="0" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <customproperties>
    <property key="embeddedWidgets/count" value="0"/>
    <property key="variableNames"/>
    <property key="variableValues"/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory minimumSize="0" penAlpha="255" barWidth="5" scaleBasedVisibility="0" enabled="0" penWidth="0" height="15" backgroundColor="#ffffff" spacing="0" diagramOrientation="Up" spacingUnit="MM" backgroundAlpha="255" penColor="#000000" lineSizeType="MM" rotationOffset="270" scaleDependency="Area" direction="1" width="15" lineSizeScale="3x:0,0,0,0,0,0" spacingUnitScale="3x:0,0,0,0,0,0" labelPlacementMethod="XHeight" sizeScale="3x:0,0,0,0,0,0" minScaleDenominator="1000" sizeType="MM" maxScaleDenominator="1e+08" opacity="1" showAxis="0">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style=""/>
      <attribute label="" color="#000000" field=""/>
      <axisSymbol>
        <symbol name="" alpha="1" type="line" clip_to_extent="1" force_rhr="0">
          <layer class="SimpleLine" enabled="1" locked="0" pass="0">
            <prop v="0" k="align_dash_pattern"/>
            <prop v="square" k="capstyle"/>
            <prop v="5;2" k="customdash"/>
            <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
            <prop v="MM" k="customdash_unit"/>
            <prop v="0" k="dash_pattern_offset"/>
            <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
            <prop v="MM" k="dash_pattern_offset_unit"/>
            <prop v="0" k="draw_inside_polygon"/>
            <prop v="bevel" k="joinstyle"/>
            <prop v="35,35,35,255" k="line_color"/>
            <prop v="solid" k="line_style"/>
            <prop v="0.26" k="line_width"/>
            <prop v="MM" k="line_width_unit"/>
            <prop v="0" k="offset"/>
            <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
            <prop v="MM" k="offset_unit"/>
            <prop v="0" k="ring_filter"/>
            <prop v="0" k="tweak_dash_pattern_on_corners"/>
            <prop v="0" k="use_custom_dash"/>
            <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings showAll="1" linePlacementFlags="2" zIndex="0" obstacle="0" dist="0" placement="2" priority="0">
    <properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="CD_LAYER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CD_SETOR" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NM_TXTMEMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CD_SEQ_LOGR" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TP_INSUMO_IMG" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" name="" field="CD_LAYER"/>
    <alias index="1" name="" field="CD_SETOR"/>
    <alias index="2" name="" field="NM_TXTMEMO"/>
    <alias index="3" name="" field="CD_SEQ_LOGR"/>
    <alias index="4" name="" field="ID"/>
    <alias index="5" name="" field="TP_INSUMO_IMG"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" field="CD_LAYER" expression=""/>
    <default applyOnUpdate="0" field="CD_SETOR" expression=""/>
    <default applyOnUpdate="0" field="NM_TXTMEMO" expression=""/>
    <default applyOnUpdate="0" field="CD_SEQ_LOGR" expression=""/>
    <default applyOnUpdate="0" field="ID" expression=""/>
    <default applyOnUpdate="0" field="TP_INSUMO_IMG" expression=""/>
  </defaults>
  <constraints>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="CD_LAYER"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="CD_SETOR"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="NM_TXTMEMO"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="CD_SEQ_LOGR"/>
    <constraint constraints="3" unique_strength="1" notnull_strength="1" exp_strength="0" field="ID"/>
    <constraint constraints="0" unique_strength="0" notnull_strength="0" exp_strength="0" field="TP_INSUMO_IMG"/>
  </constraints>
  <constraintExpressions>
    <constraint field="CD_LAYER" exp="" desc=""/>
    <constraint field="CD_SETOR" exp="" desc=""/>
    <constraint field="NM_TXTMEMO" exp="" desc=""/>
    <constraint field="CD_SEQ_LOGR" exp="" desc=""/>
    <constraint field="ID" exp="" desc=""/>
    <constraint field="TP_INSUMO_IMG" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortExpression="" actionWidgetStyle="dropDown" sortOrder="0">
    <columns>
      <column name="CD_LAYER" width="-1" type="field" hidden="0"/>
      <column name="CD_SETOR" width="-1" type="field" hidden="0"/>
      <column name="NM_TXTMEMO" width="-1" type="field" hidden="0"/>
      <column name="CD_SEQ_LOGR" width="-1" type="field" hidden="0"/>
      <column name="ID" width="-1" type="field" hidden="0"/>
      <column name="TP_INSUMO_IMG" width="-1" type="field" hidden="0"/>
      <column width="-1" type="actions" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="CD_LAYER" editable="1"/>
    <field name="CD_SEQ_LOGR" editable="1"/>
    <field name="CD_SETOR" editable="1"/>
    <field name="ID" editable="1"/>
    <field name="NM_TXTMEMO" editable="1"/>
    <field name="TP_INSUMO_IMG" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="CD_LAYER"/>
    <field labelOnTop="0" name="CD_SEQ_LOGR"/>
    <field labelOnTop="0" name="CD_SETOR"/>
    <field labelOnTop="0" name="ID"/>
    <field labelOnTop="0" name="NM_TXTMEMO"/>
    <field labelOnTop="0" name="TP_INSUMO_IMG"/>
  </labelOnTop>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"ID"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
