<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.16.5-Hannover" labelsEnabled="1" styleCategories="Symbology|Labeling|Fields|Forms|AttributeTable">
  <renderer-v2 type="singleSymbol" symbollevels="0" forceraster="0" enableorderby="0">
    <symbols>
      <symbol type="line" alpha="1" name="0" clip_to_extent="1" force_rhr="0">
        <layer enabled="1" class="SimpleLine" locked="0" pass="0">
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="170,110,142,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.858"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" locked="1" pass="2">
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="255,255,255,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.66"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style previewBkgrdColor="255,255,255,255" fontSizeUnit="Point" isExpression="0" fontFamily="MS Shell Dlg 2" multilineHeight="1" fontWordSpacing="0" fontWeight="50" fontUnderline="0" fontItalic="0" textColor="160,103,134,255" textOrientation="horizontal" fontSize="5.85" blendMode="0" fontLetterSpacing="0.296875" fontKerning="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontStrikeout="0" textOpacity="1" allowHtml="0" capitalization="0" useSubstitutions="0" namedStyle="Normal" fieldName="NOM_TOPONIMIA">
        <text-buffer bufferDraw="1" bufferOpacity="0.8" bufferColor="255,255,255,255" bufferJoinStyle="64" bufferNoFill="0" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferSizeUnits="MM"/>
        <text-mask maskJoinStyle="128" maskOpacity="1" maskSizeUnits="MM" maskType="0" maskEnabled="0" maskSize="1.5" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
        <background shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeRotation="0" shapeSizeUnit="MM" shapeSizeX="0" shapeSVGFile="" shapeRotationType="0" shapeOpacity="1" shapeBorderWidthUnit="MM" shapeRadiiY="0" shapeFillColor="255,255,255,255" shapeSizeY="0" shapeBorderWidth="0" shapeSizeType="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderColor="128,128,128,255" shapeJoinStyle="64" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeBlendMode="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="0">
          <symbol type="marker" alpha="1" name="markerSymbol" clip_to_extent="1" force_rhr="0">
            <layer enabled="1" class="SimpleMarker" locked="0" pass="0">
              <prop k="angle" v="0"/>
              <prop k="color" v="145,82,45,255"/>
              <prop k="horizontal_anchor_point" v="1"/>
              <prop k="joinstyle" v="bevel"/>
              <prop k="name" v="circle"/>
              <prop k="offset" v="0,0"/>
              <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="outline_color" v="35,35,35,255"/>
              <prop k="outline_style" v="solid"/>
              <prop k="outline_width" v="0"/>
              <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="outline_width_unit" v="MM"/>
              <prop k="scale_method" v="diameter"/>
              <prop k="size" v="2"/>
              <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="size_unit" v="MM"/>
              <prop k="vertical_anchor_point" v="1"/>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name"/>
                  <Option name="properties"/>
                  <Option type="QString" value="collection" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOpacity="0.7" shadowScale="100" shadowOffsetDist="1" shadowRadius="1.5" shadowOffsetUnit="MM" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowColor="0,0,0,255" shadowDraw="0" shadowRadiusAlphaOnly="0"/>
        <dd_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format placeDirectionSymbol="0" formatNumbers="0" useMaxLineLengthForAutoWrap="1" reverseDirectionSymbol="0" addDirectionSymbol="0" autoWrapLength="0" multilineAlign="0" leftDirectionSymbol="&lt;" plussign="0" wrapChar="" rightDirectionSymbol=">" decimals="3"/>
      <placement overrunDistanceUnit="MM" geometryGeneratorType="PointGeometry" geometryGenerator="" distUnits="MM" distMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" quadOffset="4" centroidWhole="0" overrunDistance="0" centroidInside="0" lineAnchorPercent="0.5" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" lineAnchorType="0" placementFlags="10" dist="0" layerType="LineGeometry" offsetUnits="MapUnit" maxCurvedCharAngleIn="20" repeatDistance="0" rotationAngle="0" polygonPlacementFlags="2" placement="2" xOffset="0" offsetType="0" fitInPolygonOnly="0" priority="5" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleOut="-20" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceUnits="MM" preserveRotation="1" geometryGeneratorEnabled="0"/>
      <rendering upsidedownLabels="0" scaleVisibility="0" maxNumLabels="2000" displayAll="0" drawLabels="1" fontLimitPixelSize="0" obstacle="1" fontMaxPixelSize="10000" minFeatureSize="0" obstacleFactor="1" fontMinPixelSize="3" scaleMin="1" obstacleType="0" mergeLines="0" limitNumLabels="0" zIndex="0" scaleMax="10000000" labelPerPart="0"/>
      <dd_properties>
        <Option type="Map">
          <Option type="QString" value="" name="name"/>
          <Option name="properties"/>
          <Option type="QString" value="collection" name="type"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
          <Option type="Map" name="ddProperties">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
          <Option type="bool" value="false" name="drawToAllParts"/>
          <Option type="QString" value="0" name="enabled"/>
          <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
          <Option type="QString" value="&lt;symbol type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
          <Option type="double" value="0" name="minLength"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
          <Option type="QString" value="MM" name="minLengthUnit"/>
          <Option type="double" value="0" name="offsetFromAnchor"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
          <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
          <Option type="double" value="0" name="offsetFromLabel"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
          <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="COD_LINHA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_SETOR" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_LIMITE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NOM_TOPONIMIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_CATEGORIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_OS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DAT_ATUALIZA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_GRUPO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="IND_ALTERADO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="COD_LINHA" name="" index="0"/>
    <alias field="COD_SETOR" name="" index="1"/>
    <alias field="COD_LIMITE" name="" index="2"/>
    <alias field="NOM_TOPONIMIA" name="" index="3"/>
    <alias field="COD_CATEGORIA" name="" index="4"/>
    <alias field="COD_OS" name="" index="5"/>
    <alias field="DAT_ATUALIZA" name="" index="6"/>
    <alias field="COD_GRUPO" name="" index="7"/>
    <alias field="IND_ALTERADO" name="" index="8"/>
  </aliases>
  <defaults>
    <default field="COD_LINHA" expression="" applyOnUpdate="0"/>
    <default field="COD_SETOR" expression="" applyOnUpdate="0"/>
    <default field="COD_LIMITE" expression="" applyOnUpdate="0"/>
    <default field="NOM_TOPONIMIA" expression="" applyOnUpdate="0"/>
    <default field="COD_CATEGORIA" expression="" applyOnUpdate="0"/>
    <default field="COD_OS" expression="" applyOnUpdate="0"/>
    <default field="DAT_ATUALIZA" expression="" applyOnUpdate="0"/>
    <default field="COD_GRUPO" expression="" applyOnUpdate="0"/>
    <default field="IND_ALTERADO" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="COD_LINHA" unique_strength="1" notnull_strength="1" exp_strength="0" constraints="3"/>
    <constraint field="COD_SETOR" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="COD_LIMITE" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="NOM_TOPONIMIA" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="COD_CATEGORIA" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="COD_OS" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="DAT_ATUALIZA" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="COD_GRUPO" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="IND_ALTERADO" unique_strength="0" notnull_strength="0" exp_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="COD_LINHA" desc="" exp=""/>
    <constraint field="COD_SETOR" desc="" exp=""/>
    <constraint field="COD_LIMITE" desc="" exp=""/>
    <constraint field="NOM_TOPONIMIA" desc="" exp=""/>
    <constraint field="COD_CATEGORIA" desc="" exp=""/>
    <constraint field="COD_OS" desc="" exp=""/>
    <constraint field="DAT_ATUALIZA" desc="" exp=""/>
    <constraint field="COD_GRUPO" desc="" exp=""/>
    <constraint field="IND_ALTERADO" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributetableconfig sortOrder="0" actionWidgetStyle="dropDown" sortExpression="">
    <columns>
      <column type="actions" width="-1" hidden="1"/>
      <column type="field" width="-1" name="COD_LINHA" hidden="0"/>
      <column type="field" width="-1" name="COD_SETOR" hidden="0"/>
      <column type="field" width="-1" name="COD_LIMITE" hidden="0"/>
      <column type="field" width="-1" name="NOM_TOPONIMIA" hidden="0"/>
      <column type="field" width="-1" name="COD_CATEGORIA" hidden="0"/>
      <column type="field" width="-1" name="COD_OS" hidden="0"/>
      <column type="field" width="-1" name="DAT_ATUALIZA" hidden="0"/>
      <column type="field" width="-1" name="COD_GRUPO" hidden="0"/>
      <column type="field" width="-1" name="IND_ALTERADO" hidden="0"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1">.</editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Formas QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra para seus formulários.

Digite o nome da função na "função Python Init"
campo.
Um exemplo a seguir:
"""
de qgis.PyQt.QtWidgets importar QWidget

def my_form_open(diálogo, camada, feição):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="COD_CATEGORIA"/>
    <field editable="1" name="COD_GRUPO"/>
    <field editable="1" name="COD_LIMITE"/>
    <field editable="1" name="COD_LINHA"/>
    <field editable="1" name="COD_OS"/>
    <field editable="1" name="COD_SETOR"/>
    <field editable="1" name="DAT_ATUALIZA"/>
    <field editable="1" name="IND_ALTERADO"/>
    <field editable="1" name="NOM_TOPONIMIA"/>
  </editable>
  <labelOnTop>
    <field name="COD_CATEGORIA" labelOnTop="0"/>
    <field name="COD_GRUPO" labelOnTop="0"/>
    <field name="COD_LIMITE" labelOnTop="0"/>
    <field name="COD_LINHA" labelOnTop="0"/>
    <field name="COD_OS" labelOnTop="0"/>
    <field name="COD_SETOR" labelOnTop="0"/>
    <field name="DAT_ATUALIZA" labelOnTop="0"/>
    <field name="IND_ALTERADO" labelOnTop="0"/>
    <field name="NOM_TOPONIMIA" labelOnTop="0"/>
  </labelOnTop>
  <dataDefinedFieldProperties/>
  <widgets/>
  <layerGeometryType>1</layerGeometryType>
</qgis>
