<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.16.5-Hannover" styleCategories="Symbology|Labeling|Fields|Forms|AttributeTable" labelsEnabled="1">
  <renderer-v2 enableorderby="0" type="singleSymbol" symbollevels="0" forceraster="0">
    <symbols>
      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="0">
        <layer pass="0" class="SimpleMarker" enabled="1" locked="0">
          <prop k="angle" v="0"/>
          <prop k="color" v="33,47,157,255"/>
          <prop k="horizontal_anchor_point" v="1"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="name" v="square"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="0,0,0,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0"/>
          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="scale_method" v="diameter"/>
          <prop k="size" v="1.3"/>
          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="size_unit" v="MM"/>
          <prop k="vertical_anchor_point" v="1"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontStrikeout="0" textOrientation="horizontal" capitalization="0" fontWeight="50" fontItalic="0" textColor="0,0,0,255" fontWordSpacing="0" blendMode="0" isExpression="1" multilineHeight="1" useSubstitutions="0" fontSizeUnit="Point" namedStyle="Normal" fontSize="5.85" fontKerning="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontUnderline="0" fontFamily="MS Shell Dlg 2" textOpacity="1" fontLetterSpacing="0" allowHtml="0" fieldName="if( &quot;nome_bet&quot; != '',  upper(&quot;nome_bet&quot;) , upper( &quot;nome_origem&quot; ))" previewBkgrdColor="255,255,255,255">
        <text-buffer bufferOpacity="0.8" bufferDraw="1" bufferColor="255,255,255,255" bufferSizeUnits="MM" bufferBlendMode="0" bufferSize="1.3" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="0" bufferJoinStyle="128"/>
        <text-mask maskJoinStyle="128" maskedSymbolLayers="" maskType="0" maskSize="1.5" maskEnabled="0" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM"/>
        <background shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeRotation="0" shapeJoinStyle="64" shapeDraw="0" shapeBorderColor="128,128,128,255" shapeFillColor="255,255,255,255" shapeRadiiY="0" shapeType="0" shapeOffsetX="0" shapeSVGFile="" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidthUnit="MM" shapeOffsetY="0" shapeSizeType="0" shapeSizeY="0" shapeRotationType="0" shapeRadiiX="0" shapeBlendMode="0" shapeRadiiUnit="MM">
          <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
            <layer pass="0" class="SimpleMarker" enabled="1" locked="0">
              <prop k="angle" v="0"/>
              <prop k="color" v="145,82,45,255"/>
              <prop k="horizontal_anchor_point" v="1"/>
              <prop k="joinstyle" v="bevel"/>
              <prop k="name" v="circle"/>
              <prop k="offset" v="0,0"/>
              <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="outline_color" v="35,35,35,255"/>
              <prop k="outline_style" v="solid"/>
              <prop k="outline_width" v="0"/>
              <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="outline_width_unit" v="MM"/>
              <prop k="scale_method" v="diameter"/>
              <prop k="size" v="2"/>
              <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="size_unit" v="MM"/>
              <prop k="vertical_anchor_point" v="1"/>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" type="QString" name="name"/>
                  <Option name="properties"/>
                  <Option value="collection" type="QString" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowUnder="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusAlphaOnly="0" shadowRadiusUnit="MM" shadowBlendMode="6" shadowOffsetUnit="MM" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowRadius="1.5" shadowOpacity="0.7" shadowScale="100" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0"/>
        <dd_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format decimals="3" wrapChar="" reverseDirectionSymbol="0" formatNumbers="0" autoWrapLength="0" leftDirectionSymbol="&lt;" rightDirectionSymbol=">" placeDirectionSymbol="0" plussign="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" multilineAlign="3"/>
      <placement labelOffsetMapUnitScale="3x:0,0,0,0,0,0" placement="6" preserveRotation="1" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" lineAnchorType="0" maxCurvedCharAngleOut="-25" centroidWhole="0" priority="6" offsetUnits="MapUnit" yOffset="0" offsetType="0" repeatDistanceUnits="MM" geometryGenerator="" centroidInside="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" distUnits="MM" layerType="PointGeometry" geometryGeneratorType="PointGeometry" dist="0" placementFlags="10" geometryGeneratorEnabled="0" maxCurvedCharAngleIn="25" fitInPolygonOnly="0" repeatDistance="0" lineAnchorPercent="0.5" distMapUnitScale="3x:0,0,0,0,0,0" quadOffset="4" rotationAngle="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistanceUnit="MM"/>
      <rendering obstacleType="0" displayAll="0" scaleMax="10000000" mergeLines="0" drawLabels="1" obstacleFactor="0.7" limitNumLabels="0" fontMaxPixelSize="10000" fontMinPixelSize="3" upsidedownLabels="0" scaleMin="1" labelPerPart="0" minFeatureSize="0" fontLimitPixelSize="0" scaleVisibility="0" obstacle="1" maxNumLabels="2000" zIndex="0"/>
      <dd_properties>
        <Option type="Map">
          <Option value="" type="QString" name="name"/>
          <Option name="properties"/>
          <Option value="collection" type="QString" name="type"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option value="pole_of_inaccessibility" type="QString" name="anchorPoint"/>
          <Option type="Map" name="ddProperties">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
          <Option value="false" type="bool" name="drawToAllParts"/>
          <Option value="0" type="QString" name="enabled"/>
          <Option value="point_on_exterior" type="QString" name="labelAnchorPoint"/>
          <Option value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;layer pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; type=&quot;QString&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; type=&quot;QString&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString" name="lineSymbol"/>
          <Option value="0" type="double" name="minLength"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="minLengthMapUnitScale"/>
          <Option value="MM" type="QString" name="minLengthUnit"/>
          <Option value="0" type="double" name="offsetFromAnchor"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="offsetFromAnchorMapUnitScale"/>
          <Option value="MM" type="QString" name="offsetFromAnchorUnit"/>
          <Option value="0" type="double" name="offsetFromLabel"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="offsetFromLabelMapUnitScale"/>
          <Option value="MM" type="QString" name="offsetFromLabelUnit"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field configurationFlags="None" name="id">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="cod_bet">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="nome_bet">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="nome_origem">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="tipo_aglom">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="setorizado">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="origem_nome">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="id_origem">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="buffer_m">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="situacao">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="dados_origem">
      <editWidget type="KeyValue">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="nome_padronizado">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="nome_tratado">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="qtd_palavras">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="mostrar">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="id" name=""/>
    <alias index="1" field="cod_bet" name=""/>
    <alias index="2" field="nome_bet" name=""/>
    <alias index="3" field="nome_origem" name=""/>
    <alias index="4" field="tipo_aglom" name=""/>
    <alias index="5" field="setorizado" name=""/>
    <alias index="6" field="origem_nome" name=""/>
    <alias index="7" field="id_origem" name=""/>
    <alias index="8" field="buffer_m" name=""/>
    <alias index="9" field="situacao" name=""/>
    <alias index="10" field="dados_origem" name=""/>
    <alias index="11" field="nome_padronizado" name=""/>
    <alias index="12" field="nome_tratado" name=""/>
    <alias index="13" field="qtd_palavras" name=""/>
    <alias index="14" field="mostrar" name=""/>
  </aliases>
  <defaults>
    <default expression="" field="id" applyOnUpdate="0"/>
    <default expression="" field="cod_bet" applyOnUpdate="0"/>
    <default expression="" field="nome_bet" applyOnUpdate="0"/>
    <default expression="" field="nome_origem" applyOnUpdate="0"/>
    <default expression="" field="tipo_aglom" applyOnUpdate="0"/>
    <default expression="" field="setorizado" applyOnUpdate="0"/>
    <default expression="" field="origem_nome" applyOnUpdate="0"/>
    <default expression="" field="id_origem" applyOnUpdate="0"/>
    <default expression="" field="buffer_m" applyOnUpdate="0"/>
    <default expression="" field="situacao" applyOnUpdate="0"/>
    <default expression="" field="dados_origem" applyOnUpdate="0"/>
    <default expression="" field="nome_padronizado" applyOnUpdate="0"/>
    <default expression="" field="nome_tratado" applyOnUpdate="0"/>
    <default expression="" field="qtd_palavras" applyOnUpdate="0"/>
    <default expression="" field="mostrar" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint notnull_strength="1" unique_strength="1" exp_strength="0" field="id" constraints="3"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="cod_bet" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="nome_bet" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="nome_origem" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="tipo_aglom" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="setorizado" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="origem_nome" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="id_origem" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="buffer_m" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="situacao" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="dados_origem" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="nome_padronizado" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="nome_tratado" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="qtd_palavras" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="mostrar" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="id"/>
    <constraint desc="" exp="" field="cod_bet"/>
    <constraint desc="" exp="" field="nome_bet"/>
    <constraint desc="" exp="" field="nome_origem"/>
    <constraint desc="" exp="" field="tipo_aglom"/>
    <constraint desc="" exp="" field="setorizado"/>
    <constraint desc="" exp="" field="origem_nome"/>
    <constraint desc="" exp="" field="id_origem"/>
    <constraint desc="" exp="" field="buffer_m"/>
    <constraint desc="" exp="" field="situacao"/>
    <constraint desc="" exp="" field="dados_origem"/>
    <constraint desc="" exp="" field="nome_padronizado"/>
    <constraint desc="" exp="" field="nome_tratado"/>
    <constraint desc="" exp="" field="qtd_palavras"/>
    <constraint desc="" exp="" field="mostrar"/>
  </constraintExpressions>
  <expressionfields/>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="">
    <columns>
      <column type="actions" width="-1" hidden="1"/>
      <column type="field" width="-1" name="id" hidden="0"/>
      <column type="field" width="-1" name="cod_bet" hidden="0"/>
      <column type="field" width="-1" name="nome_bet" hidden="0"/>
      <column type="field" width="-1" name="nome_origem" hidden="0"/>
      <column type="field" width="-1" name="tipo_aglom" hidden="0"/>
      <column type="field" width="-1" name="setorizado" hidden="0"/>
      <column type="field" width="-1" name="origem_nome" hidden="0"/>
      <column type="field" width="-1" name="id_origem" hidden="0"/>
      <column type="field" width="-1" name="buffer_m" hidden="0"/>
      <column type="field" width="-1" name="situacao" hidden="0"/>
      <column type="field" width="-1" name="nome_padronizado" hidden="0"/>
      <column type="field" width="-1" name="nome_tratado" hidden="0"/>
      <column type="field" width="-1" name="qtd_palavras" hidden="0"/>
      <column type="field" width="-1" name="mostrar" hidden="0"/>
      <column type="field" width="-1" name="dados_origem" hidden="0"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath>.</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Formas QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra para seus formulários.

Digite o nome da função na "função Python Init"
campo.
Um exemplo a seguir:
"""
de qgis.PyQt.QtWidgets importar QWidget

def my_form_open(diálogo, camada, feição):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="buffer_m"/>
    <field editable="1" name="cod_bet"/>
    <field editable="1" name="dados_origem"/>
    <field editable="1" name="id"/>
    <field editable="1" name="id_origem"/>
    <field editable="1" name="mostrar"/>
    <field editable="1" name="nome_bet"/>
    <field editable="1" name="nome_origem"/>
    <field editable="1" name="nome_padronizado"/>
    <field editable="1" name="nome_tratado"/>
    <field editable="1" name="origem_nome"/>
    <field editable="1" name="qtd_palavras"/>
    <field editable="1" name="setorizado"/>
    <field editable="1" name="situacao"/>
    <field editable="1" name="tipo_aglom"/>
  </editable>
  <labelOnTop>
    <field name="buffer_m" labelOnTop="0"/>
    <field name="cod_bet" labelOnTop="0"/>
    <field name="dados_origem" labelOnTop="0"/>
    <field name="id" labelOnTop="0"/>
    <field name="id_origem" labelOnTop="0"/>
    <field name="mostrar" labelOnTop="0"/>
    <field name="nome_bet" labelOnTop="0"/>
    <field name="nome_origem" labelOnTop="0"/>
    <field name="nome_padronizado" labelOnTop="0"/>
    <field name="nome_tratado" labelOnTop="0"/>
    <field name="origem_nome" labelOnTop="0"/>
    <field name="qtd_palavras" labelOnTop="0"/>
    <field name="setorizado" labelOnTop="0"/>
    <field name="situacao" labelOnTop="0"/>
    <field name="tipo_aglom" labelOnTop="0"/>
  </labelOnTop>
  <dataDefinedFieldProperties/>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
