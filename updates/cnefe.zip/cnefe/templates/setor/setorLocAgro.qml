<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.16.5-Hannover" styleCategories="Symbology|Labeling|Fields|Forms|AttributeTable" labelsEnabled="0">
  <renderer-v2 enableorderby="0" type="singleSymbol" symbollevels="0" forceraster="0">
    <symbols>
      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="0">
        <layer pass="0" class="SimpleMarker" enabled="1" locked="0">
          <prop k="angle" v="0"/>
          <prop k="color" v="231,152,24,255"/>
          <prop k="horizontal_anchor_point" v="1"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="name" v="circle"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="0,0,0,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0"/>
          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="scale_method" v="diameter"/>
          <prop k="size" v="1.5"/>
          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="size_unit" v="MM"/>
          <prop k="vertical_anchor_point" v="1"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field configurationFlags="None" name="geocodigo">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="cod_setor">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="lati">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="long">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="estabelecimento">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="id">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="geocodigo" name=""/>
    <alias index="1" field="cod_setor" name=""/>
    <alias index="2" field="lati" name=""/>
    <alias index="3" field="long" name=""/>
    <alias index="4" field="estabelecimento" name=""/>
    <alias index="5" field="id" name=""/>
  </aliases>
  <defaults>
    <default expression="" field="geocodigo" applyOnUpdate="0"/>
    <default expression="" field="cod_setor" applyOnUpdate="0"/>
    <default expression="" field="lati" applyOnUpdate="0"/>
    <default expression="" field="long" applyOnUpdate="0"/>
    <default expression="" field="estabelecimento" applyOnUpdate="0"/>
    <default expression="" field="id" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="geocodigo" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="cod_setor" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="lati" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="long" constraints="0"/>
    <constraint notnull_strength="0" unique_strength="0" exp_strength="0" field="estabelecimento" constraints="0"/>
    <constraint notnull_strength="1" unique_strength="1" exp_strength="0" field="id" constraints="3"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="geocodigo"/>
    <constraint desc="" exp="" field="cod_setor"/>
    <constraint desc="" exp="" field="lati"/>
    <constraint desc="" exp="" field="long"/>
    <constraint desc="" exp="" field="estabelecimento"/>
    <constraint desc="" exp="" field="id"/>
  </constraintExpressions>
  <expressionfields/>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="">
    <columns>
      <column type="actions" width="-1" hidden="1"/>
      <column type="field" width="-1" name="geocodigo" hidden="0"/>
      <column type="field" width="-1" name="cod_setor" hidden="0"/>
      <column type="field" width="-1" name="lati" hidden="0"/>
      <column type="field" width="-1" name="long" hidden="0"/>
      <column type="field" width="-1" name="estabelecimento" hidden="0"/>
      <column type="field" width="-1" name="id" hidden="0"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath>.</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="cod_setor"/>
    <field editable="1" name="estabelecimento"/>
    <field editable="1" name="geocodigo"/>
    <field editable="1" name="id"/>
    <field editable="1" name="lati"/>
    <field editable="1" name="long"/>
  </editable>
  <labelOnTop>
    <field name="cod_setor" labelOnTop="0"/>
    <field name="estabelecimento" labelOnTop="0"/>
    <field name="geocodigo" labelOnTop="0"/>
    <field name="id" labelOnTop="0"/>
    <field name="lati" labelOnTop="0"/>
    <field name="long" labelOnTop="0"/>
  </labelOnTop>
  <dataDefinedFieldProperties/>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
