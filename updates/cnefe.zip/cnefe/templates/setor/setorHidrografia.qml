<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.16.5-Hannover" styleCategories="Symbology|Labeling|Fields|Forms|AttributeTable" labelsEnabled="1">
  <renderer-v2 forceraster="0" type="singleSymbol" symbollevels="0" enableorderby="0">
    <symbols>
      <symbol alpha="1" name="0" type="line" clip_to_extent="1" force_rhr="0">
        <layer class="SimpleLine" locked="0" pass="0" enabled="1">
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="0,85,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.26"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontWordSpacing="0" fontItalic="0" fontFamily="MS Shell Dlg 2" fontUnderline="0" fontKerning="1" capitalization="4" namedStyle="Normal" blendMode="0" multilineHeight="1" fontSize="5.85" textOrientation="horizontal" textColor="0,85,255,255" previewBkgrdColor="255,255,255,255" fontStrikeout="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="Point" isExpression="1" fontLetterSpacing="0" allowHtml="0" textOpacity="1" fontWeight="50" fieldName="if( upper(NOM_TOPONIMIA) in ('NULL', 'N?O INFORMADO', 'NÃO INFORMADO', 'NAO INFORMADO', ' :  : ') , '', NOM_TOPONIMIA)" useSubstitutions="0">
        <text-buffer bufferJoinStyle="64" bufferDraw="1" bufferNoFill="0" bufferBlendMode="0" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferSize="1" bufferColor="250,250,250,255"/>
        <text-mask maskJoinStyle="128" maskedSymbolLayers="" maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSize="1.5" maskOpacity="1"/>
        <background shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeSizeUnit="MM" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeJoinStyle="64" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeRotation="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeRadiiX="0" shapeBorderWidthUnit="MM" shapeOffsetY="0" shapeType="0" shapeSizeType="0" shapeSVGFile="" shapeRadiiUnit="MM" shapeDraw="0" shapeRadiiY="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetX="0" shapeSizeY="0" shapeSizeX="0" shapeFillColor="255,255,255,255" shapeBlendMode="0">
          <symbol alpha="1" name="markerSymbol" type="marker" clip_to_extent="1" force_rhr="0">
            <layer class="SimpleMarker" locked="0" pass="0" enabled="1">
              <prop k="angle" v="0"/>
              <prop k="color" v="196,60,57,255"/>
              <prop k="horizontal_anchor_point" v="1"/>
              <prop k="joinstyle" v="bevel"/>
              <prop k="name" v="circle"/>
              <prop k="offset" v="0,0"/>
              <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="outline_color" v="35,35,35,255"/>
              <prop k="outline_style" v="solid"/>
              <prop k="outline_width" v="0"/>
              <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="outline_width_unit" v="MM"/>
              <prop k="scale_method" v="diameter"/>
              <prop k="size" v="2"/>
              <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="size_unit" v="MM"/>
              <prop k="vertical_anchor_point" v="1"/>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowScale="100" shadowOffsetUnit="MM" shadowRadiusUnit="MM" shadowBlendMode="6" shadowColor="0,0,0,255" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadius="1.5" shadowUnder="0" shadowOffsetGlobal="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.7" shadowDraw="0"/>
        <dd_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format decimals="3" formatNumbers="0" multilineAlign="0" wrapChar="" reverseDirectionSymbol="0" rightDirectionSymbol=">" leftDirectionSymbol="&lt;" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" plussign="0" autoWrapLength="0" addDirectionSymbol="0"/>
      <placement placement="3" lineAnchorType="0" offsetUnits="MapUnit" lineAnchorPercent="0.5" priority="5" centroidInside="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" layerType="LineGeometry" distUnits="MM" maxCurvedCharAngleIn="45" maxCurvedCharAngleOut="-45" centroidWhole="0" polygonPlacementFlags="2" geometryGeneratorType="PointGeometry" geometryGenerator="" quadOffset="4" overrunDistanceUnit="MM" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" preserveRotation="1" rotationAngle="0" yOffset="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" repeatDistance="0" fitInPolygonOnly="0" repeatDistanceUnits="MM" xOffset="0" offsetType="0" placementFlags="2" dist="0.5" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" distMapUnitScale="3x:0,0,0,0,0,0"/>
      <rendering obstacleFactor="1" drawLabels="1" minFeatureSize="0" obstacleType="0" maxNumLabels="2000" scaleMax="10000000" fontLimitPixelSize="0" upsidedownLabels="0" fontMinPixelSize="3" obstacle="0" limitNumLabels="0" mergeLines="0" displayAll="0" scaleVisibility="0" labelPerPart="0" fontMaxPixelSize="10000" scaleMin="1" zIndex="0"/>
      <dd_properties>
        <Option type="Map">
          <Option value="" name="name" type="QString"/>
          <Option name="properties"/>
          <Option value="collection" name="type" type="QString"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
          <Option name="ddProperties" type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
          <Option value="false" name="drawToAllParts" type="bool"/>
          <Option value="0" name="enabled" type="QString"/>
          <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
          <Option value="&lt;symbol alpha=&quot;1&quot; name=&quot;symbol&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;layer class=&quot;SimpleLine&quot; locked=&quot;0&quot; pass=&quot;0&quot; enabled=&quot;1&quot;>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
          <Option value="0" name="minLength" type="double"/>
          <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
          <Option value="MM" name="minLengthUnit" type="QString"/>
          <Option value="0" name="offsetFromAnchor" type="double"/>
          <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
          <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
          <Option value="0" name="offsetFromLabel" type="double"/>
          <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
          <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="COD_DRENAGEM" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_SETOR" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_LIMITE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NOM_TOPONIMIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_CATEGORIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_OS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DAT_ATUALIZA" configurationFlags="None">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_GRUPO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="IND_ALTERADO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" field="COD_DRENAGEM" index="0"/>
    <alias name="" field="COD_SETOR" index="1"/>
    <alias name="" field="COD_LIMITE" index="2"/>
    <alias name="" field="NOM_TOPONIMIA" index="3"/>
    <alias name="" field="COD_CATEGORIA" index="4"/>
    <alias name="" field="COD_OS" index="5"/>
    <alias name="" field="DAT_ATUALIZA" index="6"/>
    <alias name="" field="COD_GRUPO" index="7"/>
    <alias name="" field="IND_ALTERADO" index="8"/>
  </aliases>
  <defaults>
    <default field="COD_DRENAGEM" expression="" applyOnUpdate="0"/>
    <default field="COD_SETOR" expression="" applyOnUpdate="0"/>
    <default field="COD_LIMITE" expression="" applyOnUpdate="0"/>
    <default field="NOM_TOPONIMIA" expression="" applyOnUpdate="0"/>
    <default field="COD_CATEGORIA" expression="" applyOnUpdate="0"/>
    <default field="COD_OS" expression="" applyOnUpdate="0"/>
    <default field="DAT_ATUALIZA" expression="" applyOnUpdate="0"/>
    <default field="COD_GRUPO" expression="" applyOnUpdate="0"/>
    <default field="IND_ALTERADO" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="COD_DRENAGEM" notnull_strength="1" constraints="3" exp_strength="0" unique_strength="1"/>
    <constraint field="COD_SETOR" notnull_strength="0" constraints="0" exp_strength="0" unique_strength="0"/>
    <constraint field="COD_LIMITE" notnull_strength="0" constraints="0" exp_strength="0" unique_strength="0"/>
    <constraint field="NOM_TOPONIMIA" notnull_strength="0" constraints="0" exp_strength="0" unique_strength="0"/>
    <constraint field="COD_CATEGORIA" notnull_strength="0" constraints="0" exp_strength="0" unique_strength="0"/>
    <constraint field="COD_OS" notnull_strength="0" constraints="0" exp_strength="0" unique_strength="0"/>
    <constraint field="DAT_ATUALIZA" notnull_strength="0" constraints="0" exp_strength="0" unique_strength="0"/>
    <constraint field="COD_GRUPO" notnull_strength="0" constraints="0" exp_strength="0" unique_strength="0"/>
    <constraint field="IND_ALTERADO" notnull_strength="0" constraints="0" exp_strength="0" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="COD_DRENAGEM" desc=""/>
    <constraint exp="" field="COD_SETOR" desc=""/>
    <constraint exp="" field="COD_LIMITE" desc=""/>
    <constraint exp="" field="NOM_TOPONIMIA" desc=""/>
    <constraint exp="" field="COD_CATEGORIA" desc=""/>
    <constraint exp="" field="COD_OS" desc=""/>
    <constraint exp="" field="DAT_ATUALIZA" desc=""/>
    <constraint exp="" field="COD_GRUPO" desc=""/>
    <constraint exp="" field="IND_ALTERADO" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributetableconfig sortExpression="" actionWidgetStyle="dropDown" sortOrder="0">
    <columns>
      <column width="-1" type="actions" hidden="1"/>
      <column width="-1" name="COD_DRENAGEM" type="field" hidden="0"/>
      <column width="-1" name="COD_SETOR" type="field" hidden="0"/>
      <column width="-1" name="COD_LIMITE" type="field" hidden="0"/>
      <column width="-1" name="NOM_TOPONIMIA" type="field" hidden="0"/>
      <column width="-1" name="COD_CATEGORIA" type="field" hidden="0"/>
      <column width="-1" name="COD_OS" type="field" hidden="0"/>
      <column width="-1" name="DAT_ATUALIZA" type="field" hidden="0"/>
      <column width="-1" name="COD_GRUPO" type="field" hidden="0"/>
      <column width="-1" name="IND_ALTERADO" type="field" hidden="0"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath>.</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- codificação: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando
o formulário
 é aberto.

QGIS forms can have a Python function that is called when the form is
opened.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "Python Init function".
Un exemplo a seguir:
"""
a partir de PyQt4.QtGui importe QWidget

def my_form_open(diálogo, camada, feição):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="COD_CATEGORIA" editable="1"/>
    <field name="COD_DRENAGEM" editable="1"/>
    <field name="COD_GRUPO" editable="1"/>
    <field name="COD_LIMITE" editable="1"/>
    <field name="COD_OS" editable="1"/>
    <field name="COD_SETOR" editable="1"/>
    <field name="DAT_ATUALIZA" editable="1"/>
    <field name="IND_ALTERADO" editable="1"/>
    <field name="NOM_TOPONIMIA" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="COD_CATEGORIA"/>
    <field labelOnTop="0" name="COD_DRENAGEM"/>
    <field labelOnTop="0" name="COD_GRUPO"/>
    <field labelOnTop="0" name="COD_LIMITE"/>
    <field labelOnTop="0" name="COD_OS"/>
    <field labelOnTop="0" name="COD_SETOR"/>
    <field labelOnTop="0" name="DAT_ATUALIZA"/>
    <field labelOnTop="0" name="IND_ALTERADO"/>
    <field labelOnTop="0" name="NOM_TOPONIMIA"/>
  </labelOnTop>
  <dataDefinedFieldProperties/>
  <widgets/>
  <layerGeometryType>1</layerGeometryType>
</qgis>
