<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="0" version="3.16.5-Hannover" styleCategories="Symbology|Labeling|Fields|Forms|AttributeTable">
  <renderer-v2 preprocessing="0" type="invertedPolygonRenderer" forceraster="0" enableorderby="0">
    <renderer-v2 symbollevels="0" type="singleSymbol" forceraster="0" enableorderby="0">
      <symbols>
        <symbol name="0" alpha="1" type="fill" force_rhr="0" clip_to_extent="1">
          <layer class="SimpleFill" pass="0" locked="0" enabled="1">
            <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="color" v="194,194,194,102"/>
            <prop k="joinstyle" v="bevel"/>
            <prop k="offset" v="0,0"/>
            <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="offset_unit" v="MM"/>
            <prop k="outline_color" v="246,246,0,255"/>
            <prop k="outline_style" v="solid"/>
            <prop k="outline_width" v="0.66"/>
            <prop k="outline_width_unit" v="MM"/>
            <prop k="style" v="solid"/>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </symbols>
      <rotation/>
      <sizescale/>
    </renderer-v2>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="COD_SETOR" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_OS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DAT_ATUALIZA" configurationFlags="None">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_UF" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_MUNICIPIO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_DISTRITO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_SUBDISTRITO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="VAL_SETOR" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="IND_ALTERADO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" field="COD_SETOR" index="0"/>
    <alias name="" field="COD_OS" index="1"/>
    <alias name="" field="DAT_ATUALIZA" index="2"/>
    <alias name="" field="COD_UF" index="3"/>
    <alias name="" field="COD_MUNICIPIO" index="4"/>
    <alias name="" field="COD_DISTRITO" index="5"/>
    <alias name="" field="COD_SUBDISTRITO" index="6"/>
    <alias name="" field="VAL_SETOR" index="7"/>
    <alias name="" field="IND_ALTERADO" index="8"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" field="COD_SETOR" expression=""/>
    <default applyOnUpdate="0" field="COD_OS" expression=""/>
    <default applyOnUpdate="0" field="DAT_ATUALIZA" expression=""/>
    <default applyOnUpdate="0" field="COD_UF" expression=""/>
    <default applyOnUpdate="0" field="COD_MUNICIPIO" expression=""/>
    <default applyOnUpdate="0" field="COD_DISTRITO" expression=""/>
    <default applyOnUpdate="0" field="COD_SUBDISTRITO" expression=""/>
    <default applyOnUpdate="0" field="VAL_SETOR" expression=""/>
    <default applyOnUpdate="0" field="IND_ALTERADO" expression=""/>
  </defaults>
  <constraints>
    <constraint notnull_strength="1" exp_strength="0" constraints="3" field="COD_SETOR" unique_strength="1"/>
    <constraint notnull_strength="0" exp_strength="0" constraints="0" field="COD_OS" unique_strength="0"/>
    <constraint notnull_strength="0" exp_strength="0" constraints="0" field="DAT_ATUALIZA" unique_strength="0"/>
    <constraint notnull_strength="0" exp_strength="0" constraints="0" field="COD_UF" unique_strength="0"/>
    <constraint notnull_strength="0" exp_strength="0" constraints="0" field="COD_MUNICIPIO" unique_strength="0"/>
    <constraint notnull_strength="0" exp_strength="0" constraints="0" field="COD_DISTRITO" unique_strength="0"/>
    <constraint notnull_strength="0" exp_strength="0" constraints="0" field="COD_SUBDISTRITO" unique_strength="0"/>
    <constraint notnull_strength="0" exp_strength="0" constraints="0" field="VAL_SETOR" unique_strength="0"/>
    <constraint notnull_strength="0" exp_strength="0" constraints="0" field="IND_ALTERADO" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="COD_SETOR" exp="" desc=""/>
    <constraint field="COD_OS" exp="" desc=""/>
    <constraint field="DAT_ATUALIZA" exp="" desc=""/>
    <constraint field="COD_UF" exp="" desc=""/>
    <constraint field="COD_MUNICIPIO" exp="" desc=""/>
    <constraint field="COD_DISTRITO" exp="" desc=""/>
    <constraint field="COD_SUBDISTRITO" exp="" desc=""/>
    <constraint field="VAL_SETOR" exp="" desc=""/>
    <constraint field="IND_ALTERADO" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributetableconfig sortExpression="" actionWidgetStyle="dropDown" sortOrder="0">
    <columns>
      <column hidden="1" type="actions" width="-1"/>
      <column hidden="0" name="COD_SETOR" type="field" width="-1"/>
      <column hidden="0" name="COD_OS" type="field" width="-1"/>
      <column hidden="0" name="DAT_ATUALIZA" type="field" width="-1"/>
      <column hidden="0" name="COD_UF" type="field" width="-1"/>
      <column hidden="0" name="COD_MUNICIPIO" type="field" width="-1"/>
      <column hidden="0" name="COD_DISTRITO" type="field" width="-1"/>
      <column hidden="0" name="COD_SUBDISTRITO" type="field" width="-1"/>
      <column hidden="0" name="VAL_SETOR" type="field" width="-1"/>
      <column hidden="0" name="IND_ALTERADO" type="field" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>1</editforminitcodesource>
  <editforminitfilepath>./Originais/ValidaDlgSetores.py</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- codificação: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando
o formulário
 é aberto.

QGIS forms can have a Python function that is called when the form is
opened.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "Python Init function".
Un exemplo a seguir:
"""
a partir de PyQt4.QtGui importe QWidget

def my_form_open(diálogo, camada, feição):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="COD_DISTRITO"/>
    <field editable="1" name="COD_MUNICIPIO"/>
    <field editable="1" name="COD_OS"/>
    <field editable="1" name="COD_SETOR"/>
    <field editable="1" name="COD_SUBDISTRITO"/>
    <field editable="1" name="COD_UF"/>
    <field editable="1" name="DAT_ATUALIZA"/>
    <field editable="1" name="IND_ALTERADO"/>
    <field editable="1" name="VAL_SETOR"/>
  </editable>
  <labelOnTop>
    <field name="COD_DISTRITO" labelOnTop="0"/>
    <field name="COD_MUNICIPIO" labelOnTop="0"/>
    <field name="COD_OS" labelOnTop="0"/>
    <field name="COD_SETOR" labelOnTop="0"/>
    <field name="COD_SUBDISTRITO" labelOnTop="0"/>
    <field name="COD_UF" labelOnTop="0"/>
    <field name="DAT_ATUALIZA" labelOnTop="0"/>
    <field name="IND_ALTERADO" labelOnTop="0"/>
    <field name="VAL_SETOR" labelOnTop="0"/>
  </labelOnTop>
  <dataDefinedFieldProperties/>
  <widgets/>
  <layerGeometryType>2</layerGeometryType>
</qgis>
