<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="1" version="3.16.5-Hannover" styleCategories="Symbology|Labeling|Fields|Forms|AttributeTable">
  <renderer-v2 type="singleSymbol" symbollevels="0" forceraster="0" enableorderby="0">
    <symbols>
      <symbol name="0" force_rhr="0" type="marker" clip_to_extent="1" alpha="1">
        <layer enabled="1" pass="0" class="SimpleMarker" locked="0">
          <prop k="angle" v="0"/>
          <prop k="color" v="33,47,157,255"/>
          <prop k="horizontal_anchor_point" v="1"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="name" v="square"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="0,0,0,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0"/>
          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="scale_method" v="diameter"/>
          <prop k="size" v="1.3"/>
          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="size_unit" v="MM"/>
          <prop k="vertical_anchor_point" v="1"/>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontUnderline="0" fieldName="title(NOM_TOPONIMIA)" isExpression="1" namedStyle="Normal" blendMode="0" multilineHeight="1" textOpacity="1" fontItalic="0" fontKerning="1" fontStrikeout="0" textOrientation="horizontal" allowHtml="0" useSubstitutions="0" capitalization="0" fontSizeUnit="Point" fontFamily="MS Shell Dlg 2" fontWeight="50" fontSize="5.85" fontWordSpacing="0" previewBkgrdColor="255,255,255,255" fontLetterSpacing="0.296875" textColor="0,0,0,255" fontSizeMapUnitScale="3x:0,0,0,0,0,0">
        <text-buffer bufferBlendMode="0" bufferNoFill="0" bufferOpacity="0.8" bufferColor="255,255,255,255" bufferSizeUnits="MM" bufferDraw="1" bufferJoinStyle="128" bufferSize="1.3" bufferSizeMapUnitScale="3x:0,0,0,0,0,0"/>
        <text-mask maskEnabled="0" maskSize="1.5" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0" maskedSymbolLayers=""/>
        <background shapeRadiiUnit="MM" shapeBorderWidth="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeX="0" shapeDraw="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetX="0" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSVGFile="" shapeBlendMode="0" shapeType="0" shapeSizeY="0" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeFillColor="255,255,255,255" shapeSizeUnit="MM" shapeJoinStyle="64" shapeOffsetY="0" shapeSizeType="0" shapeRotation="0" shapeOffsetUnit="MM" shapeBorderWidthUnit="MM">
          <symbol name="markerSymbol" force_rhr="0" type="marker" clip_to_extent="1" alpha="1">
            <layer enabled="1" pass="0" class="SimpleMarker" locked="0">
              <prop k="angle" v="0"/>
              <prop k="color" v="141,90,153,255"/>
              <prop k="horizontal_anchor_point" v="1"/>
              <prop k="joinstyle" v="bevel"/>
              <prop k="name" v="circle"/>
              <prop k="offset" v="0,0"/>
              <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="outline_color" v="35,35,35,255"/>
              <prop k="outline_style" v="solid"/>
              <prop k="outline_width" v="0"/>
              <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="outline_width_unit" v="MM"/>
              <prop k="scale_method" v="diameter"/>
              <prop k="size" v="2"/>
              <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="size_unit" v="MM"/>
              <prop k="vertical_anchor_point" v="1"/>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowOffsetDist="1" shadowOffsetAngle="135" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowOpacity="0.7" shadowBlendMode="6" shadowUnder="0" shadowRadiusAlphaOnly="0" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowDraw="0" shadowRadiusUnit="MM"/>
        <dd_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format placeDirectionSymbol="0" decimals="3" wrapChar="" multilineAlign="3" addDirectionSymbol="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" leftDirectionSymbol="&lt;" formatNumbers="0" plussign="0" autoWrapLength="0" useMaxLineLengthForAutoWrap="1"/>
      <placement offsetType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" geometryGeneratorEnabled="0" polygonPlacementFlags="2" offsetUnits="MapUnit" centroidInside="0" lineAnchorType="0" fitInPolygonOnly="0" yOffset="0" centroidWhole="0" geometryGeneratorType="PointGeometry" repeatDistance="0" geometryGenerator="" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" placement="6" maxCurvedCharAngleOut="-25" placementFlags="10" quadOffset="4" maxCurvedCharAngleIn="25" overrunDistanceUnit="MM" rotationAngle="0" priority="1" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" lineAnchorPercent="0.5" dist="0" distUnits="MM" preserveRotation="1" repeatDistanceUnits="MM"/>
      <rendering scaleMax="10000000" scaleVisibility="0" limitNumLabels="0" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" zIndex="0" fontLimitPixelSize="0" upsidedownLabels="0" maxNumLabels="2000" drawLabels="1" scaleMin="1" displayAll="0" fontMaxPixelSize="10000" labelPerPart="0" obstacleType="0" fontMinPixelSize="3"/>
      <dd_properties>
        <Option type="Map">
          <Option name="name" type="QString" value=""/>
          <Option name="properties"/>
          <Option name="type" type="QString" value="collection"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
          <Option name="ddProperties" type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
          <Option name="drawToAllParts" type="bool" value="false"/>
          <Option name="enabled" type="QString" value="0"/>
          <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
          <Option name="lineSymbol" type="QString" value="&lt;symbol name=&quot;symbol&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot;>&lt;layer enabled=&quot;1&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; locked=&quot;0&quot;>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
          <Option name="minLength" type="double" value="0"/>
          <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="minLengthUnit" type="QString" value="MM"/>
          <Option name="offsetFromAnchor" type="double" value="0"/>
          <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
          <Option name="offsetFromLabel" type="double" value="0"/>
          <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="COD_PONTO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_SETOR" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NOM_TOPONIMIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_CATEGORIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COD_OS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DAT_ATUALIZA" configurationFlags="None">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="IND_ALTERADO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="COD_PONTO" name="" index="0"/>
    <alias field="COD_SETOR" name="" index="1"/>
    <alias field="NOM_TOPONIMIA" name="" index="2"/>
    <alias field="COD_CATEGORIA" name="" index="3"/>
    <alias field="COD_OS" name="" index="4"/>
    <alias field="DAT_ATUALIZA" name="" index="5"/>
    <alias field="IND_ALTERADO" name="" index="6"/>
  </aliases>
  <defaults>
    <default field="COD_PONTO" expression="" applyOnUpdate="0"/>
    <default field="COD_SETOR" expression="" applyOnUpdate="0"/>
    <default field="NOM_TOPONIMIA" expression="" applyOnUpdate="0"/>
    <default field="COD_CATEGORIA" expression="" applyOnUpdate="0"/>
    <default field="COD_OS" expression="" applyOnUpdate="0"/>
    <default field="DAT_ATUALIZA" expression="" applyOnUpdate="0"/>
    <default field="IND_ALTERADO" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="COD_PONTO" constraints="3" exp_strength="0" unique_strength="1" notnull_strength="1"/>
    <constraint field="COD_SETOR" constraints="0" exp_strength="0" unique_strength="0" notnull_strength="0"/>
    <constraint field="NOM_TOPONIMIA" constraints="0" exp_strength="0" unique_strength="0" notnull_strength="0"/>
    <constraint field="COD_CATEGORIA" constraints="0" exp_strength="0" unique_strength="0" notnull_strength="0"/>
    <constraint field="COD_OS" constraints="0" exp_strength="0" unique_strength="0" notnull_strength="0"/>
    <constraint field="DAT_ATUALIZA" constraints="0" exp_strength="0" unique_strength="0" notnull_strength="0"/>
    <constraint field="IND_ALTERADO" constraints="0" exp_strength="0" unique_strength="0" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" field="COD_PONTO" exp=""/>
    <constraint desc="" field="COD_SETOR" exp=""/>
    <constraint desc="" field="NOM_TOPONIMIA" exp=""/>
    <constraint desc="" field="COD_CATEGORIA" exp=""/>
    <constraint desc="" field="COD_OS" exp=""/>
    <constraint desc="" field="DAT_ATUALIZA" exp=""/>
    <constraint desc="" field="IND_ALTERADO" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="&quot;fclass&quot;">
    <columns>
      <column hidden="1" width="-1" type="actions"/>
      <column hidden="0" name="COD_PONTO" width="-1" type="field"/>
      <column hidden="0" name="COD_SETOR" width="-1" type="field"/>
      <column hidden="0" name="NOM_TOPONIMIA" width="-1" type="field"/>
      <column hidden="0" name="COD_CATEGORIA" width="-1" type="field"/>
      <column hidden="0" name="COD_OS" width="-1" type="field"/>
      <column hidden="0" name="DAT_ATUALIZA" width="-1" type="field"/>
      <column hidden="0" name="IND_ALTERADO" width="-1" type="field"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1">.</editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath>.</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Formas QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra para seus formulários.

Digite o nome da função na "função Python Init"
campo.
Um exemplo a seguir:
"""
de qgis.PyQt.QtWidgets importar QWidget

def my_form_open(diálogo, camada, feição):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="COD_CATEGORIA" editable="1"/>
    <field name="COD_OS" editable="1"/>
    <field name="COD_PONTO" editable="1"/>
    <field name="COD_SETOR" editable="1"/>
    <field name="DAT_ATUALIZA" editable="1"/>
    <field name="IND_ALTERADO" editable="1"/>
    <field name="NOM_TOPONIMIA" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="COD_CATEGORIA" labelOnTop="0"/>
    <field name="COD_OS" labelOnTop="0"/>
    <field name="COD_PONTO" labelOnTop="0"/>
    <field name="COD_SETOR" labelOnTop="0"/>
    <field name="DAT_ATUALIZA" labelOnTop="0"/>
    <field name="IND_ALTERADO" labelOnTop="0"/>
    <field name="NOM_TOPONIMIA" labelOnTop="0"/>
  </labelOnTop>
  <dataDefinedFieldProperties/>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
