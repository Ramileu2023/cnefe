<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis minScale="0" labelsEnabled="1" maxScale="0" simplifyLocal="1" simplifyAlgorithm="0" simplifyMaxScale="1" simplifyDrawingHints="1" version="3.16.5-Hannover" hasScaleBasedVisibilityFlag="0" simplifyDrawingTol="1" readOnly="0" styleCategories="AllStyleCategories">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
  </flags>
  <temporal endField="" mode="0" durationUnit="min" accumulate="0" endExpression="" fixedDuration="0" enabled="0" startField="" startExpression="" durationField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <renderer-v2 enableorderby="0" type="invertedPolygonRenderer" preprocessing="0" forceraster="0">
    <renderer-v2 enableorderby="0" type="singleSymbol" symbollevels="0" forceraster="0">
      <symbols>
        <symbol clip_to_extent="1" alpha="1" type="fill" force_rhr="0" name="0">
          <layer class="SimpleFill" pass="0" enabled="1" locked="0">
            <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="color" v="194,194,194,102"/>
            <prop k="joinstyle" v="bevel"/>
            <prop k="offset" v="0,0"/>
            <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="offset_unit" v="MM"/>
            <prop k="outline_color" v="246,246,0,255"/>
            <prop k="outline_style" v="dot"/>
            <prop k="outline_width" v="0.66"/>
            <prop k="outline_width_unit" v="MM"/>
            <prop k="style" v="solid"/>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </symbols>
      <rotation/>
      <sizescale/>
    </renderer-v2>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontSizeUnit="Point" fontStrikeout="0" fontLetterSpacing="0" fieldName="'Microárea ' + &quot;cd_microar&quot;" textColor="0,0,0,255" fontWordSpacing="0" textOpacity="1" fontUnderline="0" capitalization="0" isExpression="1" fontWeight="50" textOrientation="horizontal" namedStyle="Normal" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" previewBkgrdColor="255,255,255,255" useSubstitutions="0" allowHtml="0" fontFamily="Arial" multilineHeight="1" blendMode="0" fontItalic="0" fontSize="11">
        <text-buffer bufferNoFill="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferDraw="1" bufferColor="235,232,139,255" bufferSizeUnits="MM" bufferJoinStyle="128" bufferBlendMode="0" bufferSize="1"/>
        <text-mask maskOpacity="0.45" maskType="0" maskSize="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskJoinStyle="128" maskEnabled="0" maskedSymbolLayers=""/>
        <background shapeBorderWidth="0" shapeType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSizeType="0" shapeDraw="0" shapeJoinStyle="64" shapeOpacity="1" shapeSVGFile="" shapeRadiiUnit="MM" shapeRotation="0" shapeOffsetY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeRadiiX="0" shapeBorderColor="128,128,128,255" shapeSizeY="0" shapeOffsetX="0" shapeFillColor="255,255,255,255" shapeBorderWidthUnit="MM" shapeSizeX="0" shapeSizeUnit="MM" shapeOffsetUnit="MM" shapeBlendMode="0">
          <symbol clip_to_extent="1" alpha="1" type="marker" force_rhr="0" name="markerSymbol">
            <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
              <prop k="angle" v="0"/>
              <prop k="color" v="229,182,54,255"/>
              <prop k="horizontal_anchor_point" v="1"/>
              <prop k="joinstyle" v="bevel"/>
              <prop k="name" v="circle"/>
              <prop k="offset" v="0,0"/>
              <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="outline_color" v="35,35,35,255"/>
              <prop k="outline_style" v="solid"/>
              <prop k="outline_width" v="0"/>
              <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="outline_width_unit" v="MM"/>
              <prop k="scale_method" v="diameter"/>
              <prop k="size" v="2"/>
              <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="size_unit" v="MM"/>
              <prop k="vertical_anchor_point" v="1"/>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name"/>
                  <Option name="properties"/>
                  <Option type="QString" value="collection" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5" shadowUnder="0" shadowOffsetDist="1" shadowDraw="0" shadowScale="100" shadowOpacity="0.7" shadowColor="0,0,0,255" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusAlphaOnly="0"/>
        <dd_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format rightDirectionSymbol=">" multilineAlign="3" plussign="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" decimals="3" placeDirectionSymbol="0" wrapChar="" autoWrapLength="0" leftDirectionSymbol="&lt;" formatNumbers="0" reverseDirectionSymbol="0"/>
      <placement preserveRotation="1" priority="5" offsetType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" lineAnchorType="0" geometryGenerator="" repeatDistance="0" xOffset="0" rotationAngle="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistance="0" centroidInside="0" quadOffset="4" centroidWhole="0" geometryGeneratorEnabled="0" distMapUnitScale="3x:0,0,0,0,0,0" placement="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" polygonPlacementFlags="2" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" lineAnchorPercent="0.5" layerType="PolygonGeometry" placementFlags="10" yOffset="0" dist="0" offsetUnits="MM" overrunDistanceUnit="MM" distUnits="MM" fitInPolygonOnly="0" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM"/>
      <rendering fontLimitPixelSize="0" zIndex="0" minFeatureSize="0" displayAll="0" labelPerPart="0" obstacle="1" maxNumLabels="2000" limitNumLabels="0" scaleVisibility="0" fontMinPixelSize="3" obstacleFactor="1" mergeLines="0" drawLabels="1" scaleMax="0" obstacleType="1" fontMaxPixelSize="10000" upsidedownLabels="0" scaleMin="0"/>
      <dd_properties>
        <Option type="Map">
          <Option type="QString" value="" name="name"/>
          <Option type="Map" name="properties">
            <Option type="Map" name="Show">
              <Option type="bool" value="true" name="active"/>
              <Option type="QString" value="if( concatenate(  attribute( 'setorSetor','SIT'),attribute( 'setorSetor','TIPO')) = '85' , &quot;cd_microar&quot; , &quot;&quot;)" name="expression"/>
              <Option type="int" value="3" name="type"/>
            </Option>
          </Option>
          <Option type="QString" value="collection" name="type"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
          <Option type="Map" name="ddProperties">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
          <Option type="bool" value="false" name="drawToAllParts"/>
          <Option type="QString" value="0" name="enabled"/>
          <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
          <Option type="QString" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot;>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
          <Option type="double" value="0" name="minLength"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
          <Option type="QString" value="MM" name="minLengthUnit"/>
          <Option type="double" value="0" name="offsetFromAnchor"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
          <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
          <Option type="double" value="0" name="offsetFromLabel"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
          <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <property key="dualview/previewExpressions" value="&quot;id&quot;"/>
    <property key="embeddedWidgets/count" value="0"/>
    <property key="variableNames"/>
    <property key="variableValues"/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory scaleDependency="Area" minimumSize="0" opacity="1" minScaleDenominator="0" penWidth="0" backgroundColor="#ffffff" scaleBasedVisibility="0" diagramOrientation="Up" width="15" labelPlacementMethod="XHeight" spacing="5" lineSizeScale="3x:0,0,0,0,0,0" penColor="#000000" showAxis="1" enabled="0" penAlpha="255" direction="0" sizeScale="3x:0,0,0,0,0,0" maxScaleDenominator="0" spacingUnitScale="3x:0,0,0,0,0,0" sizeType="MM" backgroundAlpha="255" barWidth="5" height="15" rotationOffset="270" spacingUnit="MM" lineSizeType="MM">
      <fontProperties style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0"/>
      <attribute field="" color="#000000" label=""/>
      <axisSymbol>
        <symbol clip_to_extent="1" alpha="1" type="line" force_rhr="0" name="">
          <layer class="SimpleLine" pass="0" enabled="1" locked="0">
            <prop k="align_dash_pattern" v="0"/>
            <prop k="capstyle" v="square"/>
            <prop k="customdash" v="5;2"/>
            <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="customdash_unit" v="MM"/>
            <prop k="dash_pattern_offset" v="0"/>
            <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="dash_pattern_offset_unit" v="MM"/>
            <prop k="draw_inside_polygon" v="0"/>
            <prop k="joinstyle" v="bevel"/>
            <prop k="line_color" v="35,35,35,255"/>
            <prop k="line_style" v="solid"/>
            <prop k="line_width" v="0.26"/>
            <prop k="line_width_unit" v="MM"/>
            <prop k="offset" v="0"/>
            <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="offset_unit" v="MM"/>
            <prop k="ring_filter" v="0"/>
            <prop k="tweak_dash_pattern_on_corners" v="0"/>
            <prop k="use_custom_dash" v="0"/>
            <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings linePlacementFlags="18" zIndex="0" showAll="1" placement="1" obstacle="0" priority="0" dist="0">
    <properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option type="Map" name="QgsGeometryGapCheck">
        <Option type="double" value="0" name="allowedGapsBuffer"/>
        <Option type="bool" value="false" name="allowedGapsEnabled"/>
        <Option type="QString" value="" name="allowedGapsLayer"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="id" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cd_mun" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="nm_mun" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="geocod" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cd_microar" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cd_ti" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="id" index="0" name=""/>
    <alias field="cd_mun" index="1" name=""/>
    <alias field="nm_mun" index="2" name=""/>
    <alias field="geocod" index="3" name=""/>
    <alias field="cd_microar" index="4" name=""/>
    <alias field="cd_ti" index="5" name=""/>
  </aliases>
  <defaults>
    <default field="id" expression="" applyOnUpdate="0"/>
    <default field="cd_mun" expression="" applyOnUpdate="0"/>
    <default field="nm_mun" expression="" applyOnUpdate="0"/>
    <default field="geocod" expression="" applyOnUpdate="0"/>
    <default field="cd_microar" expression="" applyOnUpdate="0"/>
    <default field="cd_ti" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="id" exp_strength="0" constraints="1" unique_strength="0" notnull_strength="1"/>
    <constraint field="cd_mun" exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint field="nm_mun" exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint field="geocod" exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint field="cd_microar" exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint field="cd_ti" exp_strength="0" constraints="0" unique_strength="0" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="id" exp="" desc=""/>
    <constraint field="cd_mun" exp="" desc=""/>
    <constraint field="nm_mun" exp="" desc=""/>
    <constraint field="geocod" exp="" desc=""/>
    <constraint field="cd_microar" exp="" desc=""/>
    <constraint field="cd_ti" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns>
      <column hidden="1" type="actions" width="-1"/>
      <column hidden="0" type="field" width="-1" name="id"/>
      <column hidden="0" type="field" width="-1" name="cd_mun"/>
      <column hidden="0" type="field" width="-1" name="nm_mun"/>
      <column hidden="0" type="field" width="-1" name="geocod"/>
      <column hidden="0" type="field" width="-1" name="cd_microar"/>
      <column hidden="0" type="field" width="-1" name="cd_ti"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>1</editforminitcodesource>
  <editforminitfilepath>./Originais/ValidaDlgSetores.py</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- codificação: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando
o formulário
 é aberto.

QGIS forms can have a Python function that is called when the form is
opened.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "Python Init function".
Un exemplo a seguir:
"""
a partir de PyQt4.QtGui importe QWidget

def my_form_open(diálogo, camada, feição):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="COD_DISTRITO"/>
    <field editable="1" name="COD_MUNICIPIO"/>
    <field editable="1" name="COD_OS"/>
    <field editable="1" name="COD_SETOR"/>
    <field editable="1" name="COD_SUBDISTRITO"/>
    <field editable="1" name="COD_UF"/>
    <field editable="1" name="DAT_ATUALIZA"/>
    <field editable="1" name="IND_ALTERADO"/>
    <field editable="1" name="VAL_SETOR"/>
    <field editable="1" name="cd_microar"/>
    <field editable="1" name="cd_mun"/>
    <field editable="1" name="cd_ti"/>
    <field editable="1" name="geocod"/>
    <field editable="1" name="id"/>
    <field editable="1" name="nm_mun"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="COD_DISTRITO"/>
    <field labelOnTop="0" name="COD_MUNICIPIO"/>
    <field labelOnTop="0" name="COD_OS"/>
    <field labelOnTop="0" name="COD_SETOR"/>
    <field labelOnTop="0" name="COD_SUBDISTRITO"/>
    <field labelOnTop="0" name="COD_UF"/>
    <field labelOnTop="0" name="DAT_ATUALIZA"/>
    <field labelOnTop="0" name="IND_ALTERADO"/>
    <field labelOnTop="0" name="VAL_SETOR"/>
    <field labelOnTop="0" name="cd_microar"/>
    <field labelOnTop="0" name="cd_mun"/>
    <field labelOnTop="0" name="cd_ti"/>
    <field labelOnTop="0" name="geocod"/>
    <field labelOnTop="0" name="id"/>
    <field labelOnTop="0" name="nm_mun"/>
  </labelOnTop>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"id"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
