class ExportLog:
    OK = "Exportação manual acionada"
    CANCEL = "Exportação cancelada pelo usuário"
    ERROR = "Erro durante exportação"
