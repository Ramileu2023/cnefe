class Analise:
    TRANSFERENCIAS = "Análise de Transferências"    
    FACES_DESASSOCIADAS = "Análise de faces desassociadas"
    AG_MUN_SUBORDINADOS = "Agências e municípios subordinados"
    QUANT_ESP_MUN = "Quantitativo de espécies por município"
    SETORES_ACIMA_400_DOM = "Setores que demandam divisão – Acima de 400 domicílios"    
    END_FORA_SETOR = "Endereços fora do limite do setor (Universo)"
    SYNC_SISMAP_CNEFE = "Sincronização entre OS-SISMAP e CNEFE"
    TRACKINGS_REJEITADOS = "Análise de trackings rejeitados"
    SETORES_END_TRANFERIDOS = "Setores com endereços transferidos no ciclo atual"
    SETORES_OS_ABERTA = "Ver setores em OS aberta"
    SETORES_POR_ATUALIZADOR = "Setores realizados por atualizador (DFT)"
    REL_BLOQ_DESBLOQ = "Relatório de operações de bloqueio e desbloqueio de setores"
    SETORES_COM_TRACKINGS = "Setores com trackings em período definido"
    BAIXAR_AMOSTRA = "Baixar Amostra UPAs do SIGC da Amostra Mestra"
    SETORES_ESGOTAMENTO = "Análise de setores da Amostra Mestra na margem de esgotamento"
    SETORES_PNAD_TRACK = "Setores PNAD/POF com trackings"
    SETORES_DIVIDIDOS = "Setores divididos na Amostra Mestra"
    SETORES_AGREGADOS = "Setores agregados na Amostra Mestra"
    LOGR_DIV_FACES = "Logradouro divergente em faces confrontantes"
    LOCAL_DIV_QUADRA = "Localidades divergentes em uma mesma quadra"
    PERCURSO_FACE = "Identificar percurso da face"
    
    
    


    # … continue conforme cresce
