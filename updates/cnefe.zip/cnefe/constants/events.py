class LogEvent:
    START = "Início da execução"
    FINISH = "Execução finalizada"
    CANCEL = "Execução cancelada pelo usuário"
    ERROR = "Erro durante execução"
