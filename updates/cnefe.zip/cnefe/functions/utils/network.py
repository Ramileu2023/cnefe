# -*- coding: utf-8 -*-

import traceback
import requests

from qgis.core import Qgis, QgsMessageLog


DEFAULT_TIMEOUT = (10, 60)


class NetworkError(Exception):
    """Erro de comunicação com mensagem adequada para a interface."""

    def __init__(self, mensagem, status_code=None):
        super().__init__(mensagem)
        self.mensagem = mensagem
        self.status_code = status_code


def _registrar_erro(
    contexto,
    erro,
    nivel=Qgis.Warning
):
    traceback_texto = traceback.format_exc()

    if traceback_texto.strip() == "NoneType: None":
        traceback_texto = "Traceback indisponível."

    QgsMessageLog.logMessage(
        f"{contexto}:\n"
        f"{erro}\n\n"
        f"{traceback_texto}",
        "CNEFE",
        nivel
    )


def get(
    url,
    session=None,
    **kwargs
):
    """
    Executa uma requisição GET.

    Quando uma sessão é informada, utiliza seus cookies,
    cabeçalhos e demais configurações persistentes.
    """ 
    
    kwargs.setdefault(
        "timeout",
        DEFAULT_TIMEOUT
    )

    cliente = (
        session
        if session is not None
        else requests
    )

    try:

        response = cliente.get(
            url,
            **kwargs
        )

        response.raise_for_status()

        return response

    except requests.exceptions.Timeout as e:
        _registrar_erro(
            "Tempo excedido em requisição GET",
            e
        )

        raise NetworkError(
            "O sistema não respondeu dentro do tempo esperado."
        ) from e

    except requests.exceptions.ConnectionError as e:
        _registrar_erro(
            "Falha de conexão em requisição GET",
            e
        )

        raise NetworkError(
            "Não foi possível acessar o sistema neste momento. "
            "Verifique sua conexão com a rede do IBGE."
        ) from e

    except requests.exceptions.HTTPError as e:
        status = (
            e.response.status_code
            if e.response is not None
            else None
        )

        _registrar_erro(
            f"Erro HTTP {status or 'desconhecido'} em requisição GET",
            e
        )

        raise NetworkError(
            (
                f"O sistema retornou uma resposta inesperada ({status})."
                if status is not None
                else "O sistema retornou uma resposta inesperada."
            ),
            status_code=status
        ) from e

    except requests.exceptions.RequestException as e:
        _registrar_erro(
            "Erro de comunicação em requisição GET",
            e,
            Qgis.Critical
        )

        raise NetworkError(
            "Não foi possível concluir a comunicação com o sistema."
        ) from e


def post(
    url,
    session=None,
    **kwargs
):
    """
    Executa uma requisição POST.

    Quando uma sessão é informada, utiliza seus cookies,
    cabeçalhos e demais configurações persistentes.
    """
    
    kwargs.setdefault(
        "timeout",
        DEFAULT_TIMEOUT
    )

    cliente = (
        session
        if session is not None
        else requests
    )

    try:

        response = cliente.post(
            url,
            **kwargs
        )

        response.raise_for_status()

        return response

    except requests.exceptions.Timeout as e:

        _registrar_erro(
            "Tempo excedido em requisição POST",
            e
        )

        raise NetworkError(
            "O sistema não respondeu dentro do tempo esperado."
        ) from e

    except requests.exceptions.ConnectionError as e:

        _registrar_erro(
            "Falha de conexão em requisição POST",
            e
        )

        raise NetworkError(
            "Não foi possível acessar o sistema neste momento. "
            "Verifique sua conexão com a rede do IBGE."
        ) from e

    except requests.exceptions.HTTPError as e:

        status = (
            e.response.status_code
            if e.response is not None
            else None
        )

        _registrar_erro(
            (
                f"Erro HTTP "
                f"{status or 'desconhecido'} "
                "em requisição POST"
            ),
            e
        )

        raise NetworkError(
            (
                f"O sistema retornou uma resposta "
                f"inesperada ({status})."
                if status is not None
                else (
                    "O sistema retornou uma "
                    "resposta inesperada."
                )
            ),
            status_code=status
        ) from e

    except requests.exceptions.RequestException as e:

        _registrar_erro(
            "Erro de comunicação em requisição POST",
            e,
            Qgis.Critical
        )

        raise NetworkError(
            "Não foi possível concluir a comunicação "
            "com o sistema."
        ) from e