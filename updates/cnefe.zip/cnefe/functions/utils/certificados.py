import ctypes
import hashlib
import platform
import subprocess
from pathlib import Path
import os

from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import Qgis, QgsApplication
from qgis.PyQt.QtCore import Qt
    
from qgis.PyQt.QtGui import QIcon

# ----------------------------------------------------------------------
# Caminhos e identificadores do certificado homologado
# ----------------------------------------------------------------------

PLUGIN_DIR = Path(__file__).resolve().parents[2]

CAMINHO_CA_IBGE = (
    PLUGIN_DIR
    / "certificados"
    / "CA-IBGE.cer"
)

CA_IBGE_SHA256 = (
    "64A07BB6D1F9367E04CFC884941FE110"
    "D43797543A5184E14E417B71B862FF1A"
)

CA_IBGE_THUMBPRINT_SHA1 = (
    "EE3EA3C9EEDE6F895175C9BACAB9BC0752CEE51F"
)


# ----------------------------------------------------------------------
# Funções auxiliares
# ----------------------------------------------------------------------

def normalizar_hash(valor):
    """
    Remove espaços, separadores e outros caracteres de um hash,
    preservando apenas os dígitos hexadecimais.
    """
    return "".join(
        caractere
        for caractere in str(valor).upper()
        if caractere in "0123456789ABCDEF"
    )


def validar_arquivo_ca_ibge(caminho_certificado=None):
    """
    Verifica se o certificado presente no plugin corresponde exatamente
    ao certificado homologado, usando o SHA-256 do arquivo.

    Retorna:
        tuple[bool, str]:
            (True, "") em caso de sucesso;
            (False, mensagem) em caso de falha.
    """
    caminho = Path(caminho_certificado or CAMINHO_CA_IBGE)

    if not caminho.is_file():
        return (
            False,
            f"O arquivo CA-IBGE.cer não foi encontrado em:\n{caminho}",
        )

    try:
        with caminho.open("rb") as arquivo:
            sha256_atual = hashlib.sha256(
                arquivo.read()
            ).hexdigest().upper()

    except OSError as erro:
        return (
            False,
            f"Não foi possível ler o certificado CA-IBGE:\n{erro}",
        )

    if sha256_atual != normalizar_hash(CA_IBGE_SHA256):
        return (
            False,
            (
                "O arquivo CA-IBGE.cer não corresponde ao certificado "
                "homologado pelo plugin."
            ),
        )

    return True, ""


def ca_ibge_instalada():
    """
    Verifica se o certificado homologado está instalado no repositório
    de Autoridades de Certificação Raiz Confiáveis do Computador Local.

    A identificação é feita pelo thumbprint SHA-1.
    """
    if platform.system() != "Windows":
        return False

    thumbprint_esperado = normalizar_hash(
        CA_IBGE_THUMBPRINT_SHA1
    )

    creationflags = getattr(
        subprocess,
        "CREATE_NO_WINDOW",
        0,
    )

    try:
        resultado = subprocess.run(
            [
                "certutil.exe",
                "-store",
                "Root",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="mbcs",
            errors="replace",
            creationflags=creationflags,
            timeout=20,
            check=False,
        )

        saida = (
            f"{resultado.stdout}\n{resultado.stderr}"
        )

        # Remove espaços, dois-pontos, quebras de linha etc.
        saida_normalizada = normalizar_hash(saida)

        return (
            resultado.returncode == 0
            and thumbprint_esperado in saida_normalizada
        )

    except (
        OSError,
        subprocess.TimeoutExpired,
        subprocess.SubprocessError,
    ):
        return False

def solicitar_instalacao_ca_ibge(parent=None):

    msg = QMessageBox(parent)

    msg.setWindowIcon(
        QIcon(os.path.normpath(os.path.join(QgsApplication.qgisSettingsDirPath(), 'python/plugins/cnefe/functions/interface/icons/cnefe.png'))) 
    ) 
  

    msg.setIcon(QMessageBox.Question)

    msg.setWindowTitle("Instalação de certificado")

    msg.setText(
        "Foi detectado que o certificado de segurança do IBGE "
        "(CA-IBGE) ainda não está instalado nesta máquina.\n\n"

        "Esse certificado é necessário para que o Google Earth "
        "abra automaticamente os arquivos KML enquanto o "
        "GlobalProtect estiver conectado.\n\n"

        "Deseja instalar agora o certificado oficial do IBGE?\n\n"

        "O Windows solicitará permissão de administrador."
    )

    btn_instalar = msg.addButton(
        "Instalar",
        QMessageBox.AcceptRole,
    )

    btn_agora_nao = msg.addButton(
        "Agora não",
        QMessageBox.RejectRole,
    )

    btn_instalar.setFixedHeight(20)
    btn_instalar.setCursor(Qt.PointingHandCursor)
    btn_instalar.setStyleSheet("""
    QPushButton {color: rgb(0, 0, 0) ; border: 1px solid #8f8f91;border-radius: 6px; background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #f6f7fa, stop: 1 #dadbde); min-width: 80px;}
    QPushButton:pressed {background-color: rgb(0, 255, 0);}
    QPushButton:hover {
        background-color: qlineargradient(
            x1:0, y1:0, x2:0, y2:1,
            stop:0 #B9E633,
            stop:1 #7FF743
        );
        border-radius: 6px;
        color: #000000;
        outline: none;
        box-shadow: 0 0 6px rgba(50, 50, 50, 80); /* glow (simulado) */
    }  
    """)     
    btn_agora_nao.setFixedHeight(20)
    btn_agora_nao.setCursor(Qt.PointingHandCursor)
    btn_agora_nao.setStyleSheet("""
    QPushButton {color: rgb(0, 0, 0) ; border: 1px solid #8f8f91;border-radius: 6px; background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #f6f7fa, stop: 1 #dadbde); min-width: 80px;}
    QPushButton:pressed {background-color: rgb(0, 255, 0);}
    QPushButton:hover {
        background-color: qlineargradient(
            x1:0, y1:0, x2:0, y2:1,
            stop:0 #B9E633,
            stop:1 #7FF743
        );
        border-radius: 6px;
        color: #000000;
        outline: none;
        box-shadow: 0 0 6px rgba(50, 50, 50, 80); /* glow (simulado) */
    }  
    """)  
    msg.setDefaultButton(btn_instalar)

    msg.exec()

    return msg.clickedButton() == btn_instalar


def iniciar_instalacao_elevada(caminho_certificado=None):
    """
    Solicita ao Windows a execução elevada do certutil.

    O UAC será exibido pelo próprio Windows.

    Retorna:
        bool: True quando a solicitação foi iniciada; False em caso
        de erro ou cancelamento imediato.
    """
    if platform.system() != "Windows":
        return False

    caminho = Path(caminho_certificado or CAMINHO_CA_IBGE)

    argumentos = f'-addstore -f Root "{caminho}"'

    try:
        retorno = ctypes.windll.shell32.ShellExecuteW(
            None,
            "runas",
            "certutil.exe",
            argumentos,
            None,
            0,
        )

        return retorno > 32

    except (AttributeError, OSError):
        return False


# ----------------------------------------------------------------------
# Fluxo principal
# ----------------------------------------------------------------------

def garantir_ca_ibge_instalada(iface, parent=None):
    """
    Garante que o certificado CA-IBGE esteja instalado.

    Fluxo:
        1. Verifica se o sistema é Windows.
        2. Verifica se o certificado já está instalado.
        3. Valida o arquivo embarcado pelo SHA-256.
        4. Solicita autorização do usuário.
        5. Inicia a instalação elevada pelo Windows.

    Retorna:
        True:
            o certificado já estava instalado.

        False:
            a instalação foi recusada, falhou ou acabou de ser iniciada.

    Após a primeira instalação, o usuário deverá executar novamente
    a funcionalidade que abre o KML.
    """
    if platform.system() != "Windows":
        return True

    if ca_ibge_instalada():
        return True

    valido, mensagem = validar_arquivo_ca_ibge()

    if not valido:
        iface.messageBar().pushMessage(
            "Certificado não instalado",
            mensagem,
            level=Qgis.Critical,
            duration=12,
        )
        return False

    if not solicitar_instalacao_ca_ibge(parent):
        iface.messageBar().pushMessage(
            "Instalação cancelada",
            "O certificado CA-IBGE não foi instalado.",
            level=Qgis.Info,
            duration=6,
        )
        return False

    if not iniciar_instalacao_elevada():
        iface.messageBar().pushMessage(
            "Instalação não iniciada",
            (
                "Não foi possível solicitar a instalação do certificado. "
                "A operação pode ter sido cancelada ou bloqueada pelo "
                "Windows."
            ),
            level=Qgis.Warning,
            duration=10,
        )
        return False

    QMessageBox.information(
        parent,
        "Instalação do certificado",
        (
            "A instalação da Autoridade Certificadora CA-IBGE foi "
            "solicitada ao Windows.\n\n"
            "Confirme a janela de administrador e, após a conclusão, "
            "execute novamente a funcionalidade para abrir o KML."
        ),
    )

    return False