modalidades = {

    "CARRO_IBGE": {

        "custo_medio_diario": 29.91,
        "usa_combustivel": True,
        "usa_manutencao": True,
        "usa_diaria": True,
        "usa_indenizacao": True

    },

    "APP": {

        "custo_medio_diario": 26.77,
        "usa_combustivel": False,
        "usa_manutencao": False,
        "usa_diaria": False,
        "usa_indenizacao": False

    },

    "ONIBUS": {

        "custo_medio_diario": 9.75,
        "usa_combustivel": False,
        "usa_manutencao": False,
        "usa_diaria": False,
        "usa_indenizacao": False

    },

    "METRO": {

        "custo_medio_diario": 9.55,
        "usa_combustivel": False,
        "usa_manutencao": False,
        "usa_diaria": False,
        "usa_indenizacao": False

    }

}