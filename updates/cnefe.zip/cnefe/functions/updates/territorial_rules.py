# territorial_rules.py

def is_terra_indigena(situacao, tipo):
    return situacao == 5 and tipo == 5