acessibilidade = {

    # =========================================
    # AMAZÔNIA
    # =========================================

    "13": {
        "fator": 1.35,
        "descricao": "Logística amazônica/fluvial"
    },

    # =========================================
    # PANTANAL
    # =========================================

    "50": {
        "fator": 1.20,
        "descricao": "Logística pantaneira"
    },

    # =========================================
    # SEMIÁRIDO
    # =========================================

    "26": {
        "fator": 1.08,
        "descricao": "Semiárido nordestino"
    },

    # =========================================
    # GRANDES METRÓPOLES
    # =========================================

    "33": {
        "fator": 1.15,
        "descricao": "Congestionamento metropolitano"
    },

    "35": {
        "fator": 1.20,
        "descricao": "Congestionamento metropolitano"
    }
}