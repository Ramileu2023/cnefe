risco_operacional = {

    # AMAZÔNIA
    "13": {
        "risco_base": 35,
        "descricao": "Área amazônica"
    },

    # RIO DE JANEIRO
    "33": {
        "risco_base": 20,
        "descricao": "Alta complexidade urbana"
    },

    # SÃO PAULO
    "35": {
        "risco_base": 18,
        "descricao": "Alta densidade operacional"
    },

    # PANTANAL
    "50": {
        "risco_base": 25,
        "descricao": "Área pantaneira"
    },

    # PADRÃO
    "DEFAULT": {
        "risco_base": 10,
        "descricao": "Operação padrão"
    }
}