tarifas_transporte = {

    # =========================================
    # REGIÕES METROPOLITANAS
    # =========================================

    "11": 6.00,   # Porto Velho
    "12": 5.50,   # Rio Branco
    "13": 6.00,   # Manaus
    "14": 5.50,   # Boa Vista
    "15": 5.00,   # Belém
    "16": 4.50,   # Macapá
    "17": 4.85,   # Palmas

    "21": 4.20,   # São Luís
    "22": 4.00,   # Teresina
    "23": 4.50,   # Fortaleza
    "24": 4.90,   # Natal
    "25": 4.90,   # João Pessoa
    "26": 4.30,   # Recife
    "27": 4.50,   # Maceió
    "28": 4.50,   # Aracaju
    "29": 5.20,   # Salvador

    "31": 5.75,   # Belo Horizonte
    "32": 4.90,   # Vitória
    "33": 4.70,   # Rio de Janeiro
    "35": 5.40,   # São Paulo

    "41": 6.00,   # Curitiba
    "42": 6.00,   # Florianópolis
    "43": 5.00,   # Porto Alegre

    "50": 4.95,   # Campo Grande
    "51": 4.95,   # Cuiabá
    "52": 4.30,   # Goiânia
    "53": 5.50,   # Brasília

}