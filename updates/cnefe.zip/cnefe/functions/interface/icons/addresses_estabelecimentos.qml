<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.9-Firenze" labelsEnabled="0" simplifyAlgorithm="0" simplifyMaxScale="1" readOnly="0" symbologyReferenceScale="-1" simplifyDrawingTol="1" hasScaleBasedVisibilityFlag="0" simplifyDrawingHints="0" minScale="100000000" maxScale="0" styleCategories="AllStyleCategories" simplifyLocal="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal durationUnit="min" fixedDuration="0" limitMode="0" startField="" durationField="" endField="" accumulate="0" enabled="0" endExpression="" startExpression="" mode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation respectLayerSymbol="1" zoffset="0" zscale="1" symbology="Line" extrusionEnabled="0" clamping="Terrain" extrusion="0" type="IndividualFeatures" binding="Centroid" showMarkerSymbolInSurfacePlots="0">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties"/>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" alpha="1" clip_to_extent="1" is_animated="0" type="line" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" value="0" type="QString"/>
            <Option name="capstyle" value="square" type="QString"/>
            <Option name="customdash" value="5;2" type="QString"/>
            <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="customdash_unit" value="MM" type="QString"/>
            <Option name="dash_pattern_offset" value="0" type="QString"/>
            <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
            <Option name="draw_inside_polygon" value="0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="line_color" value="225,89,137,255" type="QString"/>
            <Option name="line_style" value="solid" type="QString"/>
            <Option name="line_width" value="0.6" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="trim_distance_end" value="0" type="QString"/>
            <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_end_unit" value="MM" type="QString"/>
            <Option name="trim_distance_start" value="0" type="QString"/>
            <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_start_unit" value="MM" type="QString"/>
            <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
            <Option name="use_custom_dash" value="0" type="QString"/>
            <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" alpha="1" clip_to_extent="1" is_animated="0" type="fill" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="225,89,137,255" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="161,64,98,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol name="" alpha="1" clip_to_extent="1" is_animated="0" type="marker" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="225,89,137,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="diamond" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="161,64,98,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" referencescale="-1" forceraster="0" symbollevels="0" type="RuleRenderer">
    <rules key="{ca28a0fb-8716-483b-8a28-326b4f8d2ced}">
      <rule filter="CASE  &#xd;&#xa;    WHEN regexp_replace(&quot;ESPECIE&quot;, '\\s+-.*', '') IN ('EOFIN', 'DCCM') &#xd;&#xa;    THEN 1  -- Retorna 1 para &quot;Corresponde&quot;&#xd;&#xa;    ELSE 0  -- Retorna 0 para &quot;Não Corresponde&quot;&#xd;&#xa;END&#xd;&#xa;&#xd;&#xa;" label="OUTROS" symbol="0" key="{ece30a7c-8c41-4eb3-bf08-b2ce99e85821}"/>
      <rule filter="CASE  &#xd;&#xa;    WHEN regexp_replace( &quot;ESPECIE&quot; , '\\s+-.*', '') = 'ESAUDE'&#xd;&#xa;    THEN 1  -- Retorna 1 para &quot;Corresponde&quot;&#xd;&#xa;    ELSE 0  -- Retorna 0 para &quot;Não Corresponde&quot;&#xd;&#xa;END" label="ESAUDE" symbol="1" key="{78a239a4-7405-4be5-b6c1-e8d4e67c539d}"/>
      <rule filter="CASE  &#xd;&#xa;    WHEN regexp_replace( &quot;ESPECIE&quot; , '\\s+-.*', '') = 'EAGRO'&#xd;&#xa;    THEN 1  -- Retorna 1 para &quot;Corresponde&quot;&#xd;&#xa;    ELSE 0  -- Retorna 0 para &quot;Não Corresponde&quot;&#xd;&#xa;END" label="EAGRO" symbol="2" key="{89e845ae-c297-4627-b7fc-5e64c41b1b3f}"/>
      <rule filter="CASE  &#xd;&#xa;    WHEN regexp_replace( &quot;ESPECIE&quot; , '\\s+-.*', '') = 'EENSINO'&#xd;&#xa;    THEN 1  -- Retorna 1 para &quot;Corresponde&quot;&#xd;&#xa;    ELSE 0  -- Retorna 0 para &quot;Não Corresponde&quot;&#xd;&#xa;END" label="EENSINO" symbol="3" key="{8fd3568f-dedb-4d0f-885d-ca26d1d09638}"/>
      <rule filter="CASE  &#xd;&#xa;    WHEN regexp_replace( &quot;ESPECIE&quot; , '\\s+-.*', '') = 'ERELIG'&#xd;&#xa;    THEN 1  -- Retorna 1 para &quot;Corresponde&quot;&#xd;&#xa;    ELSE 0  -- Retorna 0 para &quot;Não Corresponde&quot;&#xd;&#xa;END" label="ERELIG" symbol="4" key="{3ab5b049-66aa-428c-a716-1ba06969a589}"/>
      <rule filter="CASE  &#xd;&#xa;    WHEN regexp_replace( &quot;ESPECIE&quot; , '\\s+-.*', '') = 'DCSM'&#xd;&#xa;    THEN 1  -- Retorna 1 para &quot;Corresponde&quot;&#xd;&#xa;    ELSE 0  -- Retorna 0 para &quot;Não Corresponde&quot;&#xd;&#xa;END" label="DCSM" symbol="5" key="{f75a2138-53df-40a0-b6b2-f6b180d6f737}"/>
    </rules>
    <symbols>
      <symbol name="0" alpha="1" clip_to_extent="1" is_animated="0" type="marker" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="0,255,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="1" alpha="1" clip_to_extent="1" is_animated="0" type="marker" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SvgMarker" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="190,178,151,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="svg_path_esaude" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="10" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="2" alpha="1" clip_to_extent="1" is_animated="0" type="marker" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SvgMarker" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="svg_path_eagro" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="10" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="3" alpha="1" clip_to_extent="1" is_animated="0" type="marker" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SvgMarker" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="svg_path_eensino" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="10" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="4" alpha="1" clip_to_extent="1" is_animated="0" type="marker" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SvgMarker" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="svg_path_erelig" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="10" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="5" alpha="1" clip_to_extent="1" is_animated="0" type="marker" force_rhr="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SvgMarker" enabled="1" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="145,82,45,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="svg_path_dcsm" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="10" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <customproperties>
    <Option type="Map">
      <Option name="OnConvertFormatRegeneratePrimaryKey" value="true" type="bool"/>
      <Option name="dualview/previewExpressions" type="List">
        <Option value="&quot;UV&quot;" type="QString"/>
      </Option>
      <Option name="embeddedWidgets/count" value="0" type="int"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory maxScaleDenominator="1e+08" height="15" penAlpha="255" enabled="0" width="15" scaleBasedVisibility="0" diagramOrientation="Up" backgroundColor="#ffffff" backgroundAlpha="255" rotationOffset="270" lineSizeType="MM" penWidth="0" minScaleDenominator="0" barWidth="5" spacingUnitScale="3x:0,0,0,0,0,0" spacingUnit="MM" penColor="#000000" sizeType="MM" spacing="5" minimumSize="0" direction="0" lineSizeScale="3x:0,0,0,0,0,0" scaleDependency="Area" labelPlacementMethod="XHeight" sizeScale="3x:0,0,0,0,0,0" opacity="1" showAxis="1">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" underline="0" italic="0" bold="0" style="" strikethrough="0"/>
      <attribute label="" field="" color="#000000" colorOpacity="1"/>
      <axisSymbol>
        <symbol name="" alpha="1" clip_to_extent="1" is_animated="0" type="line" force_rhr="0" frame_rate="10">
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <layer class="SimpleLine" enabled="1" locked="0" pass="0">
            <Option type="Map">
              <Option name="align_dash_pattern" value="0" type="QString"/>
              <Option name="capstyle" value="square" type="QString"/>
              <Option name="customdash" value="5;2" type="QString"/>
              <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="customdash_unit" value="MM" type="QString"/>
              <Option name="dash_pattern_offset" value="0" type="QString"/>
              <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
              <Option name="draw_inside_polygon" value="0" type="QString"/>
              <Option name="joinstyle" value="bevel" type="QString"/>
              <Option name="line_color" value="35,35,35,255" type="QString"/>
              <Option name="line_style" value="solid" type="QString"/>
              <Option name="line_width" value="0.26" type="QString"/>
              <Option name="line_width_unit" value="MM" type="QString"/>
              <Option name="offset" value="0" type="QString"/>
              <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="offset_unit" value="MM" type="QString"/>
              <Option name="ring_filter" value="0" type="QString"/>
              <Option name="trim_distance_end" value="0" type="QString"/>
              <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="trim_distance_end_unit" value="MM" type="QString"/>
              <Option name="trim_distance_start" value="0" type="QString"/>
              <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="trim_distance_start_unit" value="MM" type="QString"/>
              <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
              <Option name="use_custom_dash" value="0" type="QString"/>
              <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings showAll="1" linePlacementFlags="18" placement="0" priority="0" obstacle="0" zIndex="0" dist="0">
    <properties>
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties"/>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="CODIGO UNICO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="QUADRA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="FACE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="UV" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CODIGO ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LOGRADOURO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NUMERO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LOCALIDADE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PONTO_DE_REFERENCIA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CEP" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LATITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LONGITUDE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ESPECIE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NOME DO RESPONSAVEL" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TELEFONE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ESTABELECIMENTO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="STATUS_DO_ENDERECO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DATA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="SELECIONADO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" field="CODIGO UNICO" index="0"/>
    <alias name="" field="QUADRA" index="1"/>
    <alias name="" field="FACE" index="2"/>
    <alias name="" field="UV" index="3"/>
    <alias name="" field="CODIGO ENDERECO" index="4"/>
    <alias name="" field="LOGRADOURO" index="5"/>
    <alias name="" field="NUMERO" index="6"/>
    <alias name="" field="LOCALIDADE" index="7"/>
    <alias name="" field="PONTO_DE_REFERENCIA" index="8"/>
    <alias name="" field="CEP" index="9"/>
    <alias name="" field="LATITUDE" index="10"/>
    <alias name="" field="LONGITUDE" index="11"/>
    <alias name="" field="ESPECIE" index="12"/>
    <alias name="" field="NOME DO RESPONSAVEL" index="13"/>
    <alias name="" field="TELEFONE" index="14"/>
    <alias name="" field="ESTABELECIMENTO" index="15"/>
    <alias name="" field="STATUS_DO_ENDERECO" index="16"/>
    <alias name="" field="DATA" index="17"/>
    <alias name="" field="SELECIONADO" index="18"/>
  </aliases>
  <defaults>
    <default field="CODIGO UNICO" expression="" applyOnUpdate="0"/>
    <default field="QUADRA" expression="" applyOnUpdate="0"/>
    <default field="FACE" expression="" applyOnUpdate="0"/>
    <default field="UV" expression="" applyOnUpdate="0"/>
    <default field="CODIGO ENDERECO" expression="" applyOnUpdate="0"/>
    <default field="LOGRADOURO" expression="" applyOnUpdate="0"/>
    <default field="NUMERO" expression="" applyOnUpdate="0"/>
    <default field="LOCALIDADE" expression="" applyOnUpdate="0"/>
    <default field="PONTO_DE_REFERENCIA" expression="" applyOnUpdate="0"/>
    <default field="CEP" expression="" applyOnUpdate="0"/>
    <default field="LATITUDE" expression="" applyOnUpdate="0"/>
    <default field="LONGITUDE" expression="" applyOnUpdate="0"/>
    <default field="ESPECIE" expression="" applyOnUpdate="0"/>
    <default field="NOME DO RESPONSAVEL" expression="" applyOnUpdate="0"/>
    <default field="TELEFONE" expression="" applyOnUpdate="0"/>
    <default field="ESTABELECIMENTO" expression="" applyOnUpdate="0"/>
    <default field="STATUS_DO_ENDERECO" expression="" applyOnUpdate="0"/>
    <default field="DATA" expression="" applyOnUpdate="0"/>
    <default field="SELECIONADO" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="CODIGO UNICO" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="QUADRA" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="FACE" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="UV" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="CODIGO ENDERECO" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="LOGRADOURO" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="NUMERO" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="LOCALIDADE" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="PONTO_DE_REFERENCIA" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="CEP" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="LATITUDE" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="LONGITUDE" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="ESPECIE" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="NOME DO RESPONSAVEL" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="TELEFONE" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="ESTABELECIMENTO" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="STATUS_DO_ENDERECO" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="DATA" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="SELECIONADO" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="CODIGO UNICO" desc=""/>
    <constraint exp="" field="QUADRA" desc=""/>
    <constraint exp="" field="FACE" desc=""/>
    <constraint exp="" field="UV" desc=""/>
    <constraint exp="" field="CODIGO ENDERECO" desc=""/>
    <constraint exp="" field="LOGRADOURO" desc=""/>
    <constraint exp="" field="NUMERO" desc=""/>
    <constraint exp="" field="LOCALIDADE" desc=""/>
    <constraint exp="" field="PONTO_DE_REFERENCIA" desc=""/>
    <constraint exp="" field="CEP" desc=""/>
    <constraint exp="" field="LATITUDE" desc=""/>
    <constraint exp="" field="LONGITUDE" desc=""/>
    <constraint exp="" field="ESPECIE" desc=""/>
    <constraint exp="" field="NOME DO RESPONSAVEL" desc=""/>
    <constraint exp="" field="TELEFONE" desc=""/>
    <constraint exp="" field="ESTABELECIMENTO" desc=""/>
    <constraint exp="" field="STATUS_DO_ENDERECO" desc=""/>
    <constraint exp="" field="DATA" desc=""/>
    <constraint exp="" field="SELECIONADO" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" actionWidgetStyle="dropDown" sortExpression="&quot;ESPECIE&quot;">
    <columns>
      <column name="UV" hidden="0" type="field" width="-1"/>
      <column name="PONTO_DE_REFERENCIA" hidden="0" type="field" width="336"/>
      <column name="QUADRA" hidden="0" type="field" width="-1"/>
      <column name="FACE" hidden="0" type="field" width="-1"/>
      <column name="CEP" hidden="0" type="field" width="-1"/>
      <column name="LOCALIDADE" hidden="0" type="field" width="-1"/>
      <column name="LATITUDE" hidden="0" type="field" width="-1"/>
      <column name="LONGITUDE" hidden="0" type="field" width="-1"/>
      <column name="CODIGO UNICO" hidden="0" type="field" width="-1"/>
      <column name="CODIGO ENDERECO" hidden="0" type="field" width="-1"/>
      <column name="LOGRADOURO" hidden="0" type="field" width="-1"/>
      <column name="NUMERO" hidden="0" type="field" width="-1"/>
      <column name="ESPECIE" hidden="0" type="field" width="419"/>
      <column name="NOME DO RESPONSAVEL" hidden="0" type="field" width="-1"/>
      <column name="TELEFONE" hidden="0" type="field" width="-1"/>
      <column name="ESTABELECIMENTO" hidden="0" type="field" width="-1"/>
      <column name="STATUS_DO_ENDERECO" hidden="0" type="field" width="-1"/>
      <column name="DATA" hidden="0" type="field" width="-1"/>
      <column name="SELECIONADO" hidden="0" type="field" width="-1"/>
      <column hidden="1" type="actions" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- código: utf-8 -*-
"""
Os formulários do QGIS podem ter uma função Python que é chamada quando o formulário é
aberto.

Use esta função para adicionar lógica extra aos seus formulários.

Entre com o nome da função no campo "função Python Init
Segue um exemplo:
"""
de qgis.PyQt.QtWidgets import QWidget

def my_form_open(diálogo, camada, feição):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="CEP" editable="1"/>
    <field name="CODIGO ENDERECO" editable="1"/>
    <field name="CODIGO UNICO" editable="1"/>
    <field name="CODIGO_DO_ENDERECO" editable="1"/>
    <field name="DATA" editable="1"/>
    <field name="DATA_DE_CONFIRMACAO" editable="1"/>
    <field name="DISTANCE" editable="1"/>
    <field name="ENDERECO" editable="1"/>
    <field name="ESPECIE" editable="1"/>
    <field name="ESTABELECIMENTO" editable="1"/>
    <field name="FACE" editable="1"/>
    <field name="LATITUDE" editable="1"/>
    <field name="LOCALIDADE" editable="1"/>
    <field name="LOGRADOURO" editable="1"/>
    <field name="LONGITUDE" editable="1"/>
    <field name="NOME DO RESPONSAVEL" editable="1"/>
    <field name="NUMERO" editable="1"/>
    <field name="PONTO_DE_REFERENCIA" editable="1"/>
    <field name="QUADRA" editable="1"/>
    <field name="SELECIONADO" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="STATUS_DO_ENDERECO" editable="1"/>
    <field name="TELEFONE" editable="1"/>
    <field name="UV" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="CEP" labelOnTop="0"/>
    <field name="CODIGO ENDERECO" labelOnTop="0"/>
    <field name="CODIGO UNICO" labelOnTop="0"/>
    <field name="CODIGO_DO_ENDERECO" labelOnTop="0"/>
    <field name="DATA" labelOnTop="0"/>
    <field name="DATA_DE_CONFIRMACAO" labelOnTop="0"/>
    <field name="DISTANCE" labelOnTop="0"/>
    <field name="ENDERECO" labelOnTop="0"/>
    <field name="ESPECIE" labelOnTop="0"/>
    <field name="ESTABELECIMENTO" labelOnTop="0"/>
    <field name="FACE" labelOnTop="0"/>
    <field name="LATITUDE" labelOnTop="0"/>
    <field name="LOCALIDADE" labelOnTop="0"/>
    <field name="LOGRADOURO" labelOnTop="0"/>
    <field name="LONGITUDE" labelOnTop="0"/>
    <field name="NOME DO RESPONSAVEL" labelOnTop="0"/>
    <field name="NUMERO" labelOnTop="0"/>
    <field name="PONTO_DE_REFERENCIA" labelOnTop="0"/>
    <field name="QUADRA" labelOnTop="0"/>
    <field name="SELECIONADO" labelOnTop="0"/>
    <field name="STATUS" labelOnTop="0"/>
    <field name="STATUS_DO_ENDERECO" labelOnTop="0"/>
    <field name="TELEFONE" labelOnTop="0"/>
    <field name="UV" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CEP" reuseLastValue="0"/>
    <field name="CODIGO ENDERECO" reuseLastValue="0"/>
    <field name="CODIGO UNICO" reuseLastValue="0"/>
    <field name="CODIGO_DO_ENDERECO" reuseLastValue="0"/>
    <field name="DATA" reuseLastValue="0"/>
    <field name="DATA_DE_CONFIRMACAO" reuseLastValue="0"/>
    <field name="DISTANCE" reuseLastValue="0"/>
    <field name="ENDERECO" reuseLastValue="0"/>
    <field name="ESPECIE" reuseLastValue="0"/>
    <field name="ESTABELECIMENTO" reuseLastValue="0"/>
    <field name="FACE" reuseLastValue="0"/>
    <field name="LATITUDE" reuseLastValue="0"/>
    <field name="LOCALIDADE" reuseLastValue="0"/>
    <field name="LOGRADOURO" reuseLastValue="0"/>
    <field name="LONGITUDE" reuseLastValue="0"/>
    <field name="NOME DO RESPONSAVEL" reuseLastValue="0"/>
    <field name="NUMERO" reuseLastValue="0"/>
    <field name="PONTO_DE_REFERENCIA" reuseLastValue="0"/>
    <field name="QUADRA" reuseLastValue="0"/>
    <field name="SELECIONADO" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="STATUS_DO_ENDERECO" reuseLastValue="0"/>
    <field name="TELEFONE" reuseLastValue="0"/>
    <field name="UV" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"UV"</previewExpression>
  <mapTip>&lt;!DOCTYPE html>&#xd;&#xd;
						&lt;html>&#xd;&#xd;
						  &lt;head>&#xd;&#xd;
							&lt;meta http-equiv="content-type" content="text/html; charset=UTF-8">&#xd;&#xd;
							&lt;style>&#xd;&#xd;
								table.grey{&#xd;&#xd;
									border-style: none;&#xd;&#xd;
									width: auto;&#xd;&#xd;
									padding: 15px;&#xd;&#xd;
									border-collapse: collapse;&#xd;&#xd;
									border-left: 0;&#xd;&#xd;
									border-right: 0;&#xd;&#xd;
									border-radius: 10px;&#xd;&#xd;
									border-spacing: 0px;&#xd;&#xd;
									overflow:hidden; /* hide overflowing cells */&#xd;&#xd;
								}&#xd;&#xd;
							&lt;/style>					&#xd;&#xd;
						  &lt;/head>&#xd;&#xd;
						  &lt;body>&#xd;&#xd;
							&lt;table  class="grey">&#xd;&#xd;
								&lt;tbody>&#xd;&#xd;
									&lt;tr style="height: 18px; width: auto;">&#xd;&#xd;
										&lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">Atributo&lt;/span>&lt;/td>&#xd;&#xd;
										&lt;td style="height: 18px; background-color: #F9EE94; text-align: center;">&lt;span style="color: #000000;">valor&lt;/span>&lt;/td>&#xd;&#xd;
									&lt;/tr>&#xd;&#xd;
									&lt;tr style="font-size: 12px; width: auto;">&#xd;&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">QUADRA&lt;/span>&lt;/td>&#xd;&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%QUADRA%]&lt;/span>&lt;/strong>&lt;/td>&#xd;&#xd;
									&lt;/tr>									&#xd;&#xd;
									&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">FACE&lt;/span>&lt;/td>&#xd;&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%FACE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;&#xd;
									&lt;/tr>									&#xd;&#xd;
									&lt;tr style="font-size: 12px; width: auto;">&#xd;&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">LOGRADOURO&lt;/span>&lt;/td>&#xd;&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%LOGRADOURO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;&#xd;
									&lt;/tr>																		&#xd;&#xd;
									&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">NUMERO&lt;/span>&lt;/td>&#xd;&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%NUMERO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;&#xd;
									&lt;/tr>&#xd;&#xd;
									&lt;tr style="font-size: 12px; width: auto;">&#xd;&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">LOCALIDADE&lt;/span>&lt;/td>&#xd;&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%LOCALIDADE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;&#xd;
									&lt;/tr>&#xd;&#xd;
&#xd;&#xd;
									&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">PONTO DE REFERÊNCIA&lt;/span>&lt;/td>&#xd;&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%PONTO_DE_REFERENCIA%]&lt;/span>&lt;/strong>&lt;/td>&#xd;&#xd;
									&lt;/tr>&#xd;&#xd;
									&lt;tr style="font-size: 12px; width: auto;">&#xd;&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">STATUS DO ENDEREÇO&lt;/span>&lt;/td>&#xd;&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%STATUS_DO_ENDERECO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;&#xd;
									&lt;/tr>&#xd;&#xd;
&#xd;&#xd;
									&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">DATA&lt;/span>&lt;/td>&#xd;&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%DATA%]&lt;/span>&lt;/strong>&lt;/td>&#xd;&#xd;
									&lt;/tr>									&#xd;&#xd;
									&lt;tr style="font-size: 12px; width: auto;">&#xd;&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">ESPECIE&lt;/span>&lt;/td>&#xd;&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%ESPECIE%]&lt;/span>&lt;/strong>&lt;/td>&#xd;&#xd;
									&lt;/tr>									&#xd;&#xd;
									&lt;tr style="font-size: 12px; width: auto; background-color: #f2f2f2">&#xd;&#xd;
										&lt;td style="border-style: hidden;">&lt;span style="color: #800000; white-space: nowrap;">ESTABELECIMENTO&lt;/span>&lt;/td>&#xd;&#xd;
										&lt;td style="border-style: hidden; text-align: center;">&lt;strong>&lt;span style="color: #800000; white-space: nowrap;">[%ESTABELECIMENTO%]&lt;/span>&lt;/strong>&lt;/td>&#xd;&#xd;
									&lt;/tr>										&#xd;&#xd;
								&lt;/tbody>&#xd;&#xd;
							&lt;/table>	&#xd;&#xd;
						  &lt;/body>&#xd;&#xd;
						&lt;/html></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
