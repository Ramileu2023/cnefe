import os
import shutil
from qgis.PyQt.QtGui import QFontDatabase

def instalar_fonts_localmente():
    pasta_origem = os.path.join(os.path.dirname(__file__), "fonts")
    pasta_destino = os.path.join(os.getenv('APPDATA'), 'QGIS', 'QGIS3', 'profiles', 'default', 'fonts')

    if not os.path.exists(pasta_destino):
        os.makedirs(pasta_destino)

    arquivos_fontes = [
        "OpenSans-Regular.ttf",
        "OpenSans-Bold.ttf",
        "OpenSans-Italic.ttf",
        "OpenSans-BoldItalic.ttf"
    ]

    for nome_arquivo in arquivos_fontes:
        caminho_origem = os.path.join(pasta_origem, nome_arquivo)
        caminho_destino = os.path.join(pasta_destino, nome_arquivo)
        if not os.path.exists(caminho_destino):
            try:
                shutil.copy2(caminho_origem, caminho_destino)                
            except Exception as e:
                print(f"❌ Erro ao copiar {nome_arquivo}: {e}")

def registrar_fonts():
    pasta_fonts = os.path.join(os.getenv('APPDATA'), 'QGIS', 'QGIS3', 'profiles', 'default', 'fonts')

    fontes = [
        "OpenSans-Regular.ttf",
        "OpenSans-Bold.ttf",
        "OpenSans-Italic.ttf",
        "OpenSans-BoldItalic.ttf"
    ]

    for fonte in fontes:
        caminho_fonte = os.path.join(pasta_fonts, fonte)
        if os.path.exists(caminho_fonte):
            font_id = QFontDatabase.addApplicationFont(caminho_fonte)
            if font_id == -1:
                print(f"⚠️ Falha ao registrar a fonte {fonte}")
        else:
            print(f"❌ Fonte não encontrada: {fonte}")
